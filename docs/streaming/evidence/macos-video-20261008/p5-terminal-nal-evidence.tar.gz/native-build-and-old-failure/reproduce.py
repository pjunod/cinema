from pathlib import Path
import hashlib,json,struct,subprocess,time
ROOT=Path(__file__).resolve().parent
SOURCE=Path('<OWNED_WORK_ROOT>/remaining-native/crates/plurxd/fixtures/macos-processing/strict_p5_fresh.mp4')
FFMPEG=Path('<OWNED_WORK_ROOT>/dolby-live-bwdif-correct-package/ffmpeg')
def boxes(data):
 pos=0
 while pos<len(data):
  size,kind=struct.unpack_from('>I4s',data,pos)
  if size<8 or pos+size>len(data):raise ValueError('unsupported box layout')
  yield kind,data[pos+8:pos+size];pos+=size
CONTAINERS={b'moov',b'trak',b'mdia',b'minf',b'stbl'}
def tables(data):
 result={}
 def walk(data):
  for kind,payload in boxes(data):
   if kind in CONTAINERS:walk(payload)
   elif kind in {b'stsz',b'stco',b'stsc'}:
    if kind in result:raise ValueError('multiple tracks')
    result[kind]=payload
 walk(data);return result
raw=SOURCE.read_bytes();tab=tables(raw);uniform,count=struct.unpack_from('>II',tab[b'stsz'],4)
if uniform or count!=24 or struct.unpack_from('>IIII',tab[b'stsc'],4)!=(1,1,24,1):raise ValueError('unexpected samples')
sizes=list(struct.unpack_from('>24I',tab[b'stsz'],12));original=list(boxes(raw));mdat=next(payload for kind,payload in original if kind==b'mdat')
if sum(sizes)!=len(mdat) or [kind for kind,_ in original].index(b'mdat')>[kind for kind,_ in original].index(b'moov'):raise ValueError('noncontiguous or moov-first media')
def nals(sample):
 out=[];pos=0
 while pos<len(sample):
  length=struct.unpack_from('>I',sample,pos)[0];pos+=4
  if length<2 or pos+length>len(sample):raise ValueError('badNAL')
  out.append(sample[pos:pos+length]);pos+=length
 return out
def pack_nals(nals):return b''.join(struct.pack('>I',len(nal))+nal for nal in nals)
last=nals(mdat[sum(sizes[:-1]):]);types=[(nal[0]>>1)&63 for nal in last]
if types[-1]!=62:raise ValueError('source does not end withRPU')
def image(last_nals):
 changed=pack_nals(last_nals);new_sizes=sizes[:-1]+[len(changed)]
 def rebuild(data):
  output=b''
  for kind,payload in boxes(data):
   if kind in CONTAINERS:payload=rebuild(payload)
   elif kind==b'stsz':payload=payload[:12]+struct.pack('>24I',*new_sizes)
   elif kind==b'mdat':payload=payload[:sum(sizes[:-1])]+changed
   output+=struct.pack('>I4s',len(payload)+8,kind)+payload
  return output
 return rebuild(raw)
cases={'baseline':raw,'eos':image(last+[bytes([36<<1,1,128])]),'eob':image(last+[bytes([37<<1,1,128])]),'eos_eob':image(last+[bytes([36<<1,1,128]),bytes([37<<1,1,128])]),'true_missing':image(last[:-1]+[bytes([36<<1,1,128]),bytes([37<<1,1,128])])}
receipt={'scope':'bounded strict software decoder diagnostic, final AU only; original timing/config/source codes preserved; no GPU or performance claim','source_sha256':hashlib.sha256(raw).hexdigest(),'ffmpeg_sha256':hashlib.sha256(FFMPEG.read_bytes()).hexdigest(),'original_final_AU_nal_types':types,'cases':{}}
for name,data in cases.items():
 path=ROOT/(name+'.mp4');path.write_bytes(data)
 argv=[str(FFMPEG),'-hide_banner','-v','warning','-nostdin','-threads','1','-strict_dovi','1','-err_detect','explode','-xerror','-i',str(path),'-map','0:v:0','-an','-f','framemd5','-']
 began=time.monotonic();p=subprocess.run(argv,capture_output=True,timeout=20)
 (ROOT/(name+'.stdout')).write_bytes(p.stdout);(ROOT/(name+'.stderr')).write_bytes(p.stderr)
 frames=[line for line in p.stdout.decode(errors='replace').splitlines() if line and not line.startswith('#')]
 receipt['cases'][name]={'argv':argv,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'exit':p.returncode,'decoded_frames':len(frames),'elapsed_correctness_only':time.monotonic()-began,'stderr':p.stderr.decode(errors='replace')}
(ROOT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:{key:row[key] for key in ['exit','decoded_frames']} for k,row in receipt['cases'].items()}))
