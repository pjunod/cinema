import pathlib,json,hashlib
root=pathlib.Path(__file__).parent
scope={}
exec((root/'driver.py').read_text().split('rows=[]',1)[0],scope)
metadata=scope['selected_metadata']; colors=scope['colored_pixels']
log=(root/'vt-metal-variable.log').read_bytes(); raw=(root/'vt-metal-variable.decoded.yuv').read_bytes()
rows=[]
rows.append(dict(control='actual-selected-vt-metal-variable',passed=metadata(log,'vt-metal',True) and colors(raw)))
lines=log.decode().splitlines(keepends=True)
indexes=[i for i,line in enumerate(lines) if 'color metadata:' in line]
assert len(indexes)==24
stale=lines.copy()
for i in indexes: stale[i]=lines[indexes[0]]
shuffled=lines.copy(); shuffled[indexes[1]],shuffled[indexes[2]]=shuffled[indexes[2]],shuffled[indexes[1]]
missing=lines.copy(); missing[indexes[12]]=''
for name,mutated in [('first-dm-repeated',stale),('two-dm-signatures-shuffled',shuffled),('one-dm-absent',missing)]:
 data=''.join(mutated).encode(); (root/(name+'.log')).write_bytes(data)
 rows.append(dict(control=name,sha256=hashlib.sha256(data).hexdigest(),passed=not metadata(data,'vt-metal',True)))
for patch in range(6):
 for offset in (14400,18000):
  altered=bytearray(raw); x=(10+20*patch)//2; y=67//2
  for yy in range(y-1,y+2):
   for xx in range(x-1,x+2): altered[12*21600+offset+yy*80+xx]=255
  unchanged=altered[12*21600:12*21600+14400]==raw[12*21600:12*21600+14400]
  rows.append(dict(control=f'patch-{patch}-chroma-plane-{offset}-altered-gray-unchanged',sha256=hashlib.sha256(altered).hexdigest(),passed=unchanged and not colors(altered)))
receipt=dict(scope='observer corruption controls replayed against actual graph stderr/pixels, not Rust unit execution',runs=rows,passed=all(r['passed'] for r in rows))
(root/'observer-controls.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(receipt['passed'],len(rows),'observer controls')
