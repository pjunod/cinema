import json, subprocess, hashlib, pathlib, time, re
root=pathlib.Path('/experiment')
package=root/'dolby-live-bwdif-correct-package'
ffmpeg=package/'ffmpeg'; ffprobe=package/'ffprobe'
assets=root/'remaining-core/crates/plurxd/fixtures/macos-processing'
manifest=json.loads((assets/'strict-p5.json').read_text())
output=root/'routes-evidence/b1-p5-selected-graph-correct'; output.mkdir(exist_ok=True)
mapper='tonemapx=tonemap=bt2390:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=yuv420p:apply_dovi=1:require_dovi=1'
metal='tonemap_videotoolbox=tonemap=bt2390:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=1:require_dovi=1'
scale='scale_vt=w=160:h=90:format=nv12'
# Exact source-raster renderer and adapter order projected from Pipeline.
tuples=[('software-cpu-vt','sw','vt','format=yuv420p10le,'+mapper+',scale=160:90,format=yuv420p'),('software-cpu-software','sw','software','format=yuv420p10le,'+mapper+',scale=160:90,format=yuv420p'),('vt-cpu','vt','vt','hwdownload,format=p010le,setparams=colorspace=unknown,format=yuv420p10le,'+mapper+',scale=160:90,format=yuv420p'),('software-metal','sw','vt','format=yuv420p10le,setparams=colorspace=unknown,format=p010le,hwupload,'+metal+','+scale),('vt-metal','vt','vt',metal+','+scale)]
def selected_metadata(log, name, variable):
    expected_format='videotoolbox_vld' if 'metal' in name else 'yuv420p10le'
    frames=[]; configured=False
    def field(line,key):
        tokens=iter(line.split())
        for token in tokens:
            if token.startswith(key):
                value=token[len(key):] or next(tokens,None)
                return value.rstrip(';') if value else None
        return None
    try:
        for line in log.decode().splitlines():
            if not line.startswith('[showinfo@plurx_p5_contract @ '): continue
            body=line.split(']',1)[1].strip()
            if body.startswith('config in time_base:'):
                if configured or body!='config in time_base: 1/12288, frame_rate: 12/1': return False
                configured=True
            elif body.startswith('n:'):
                n=int(field(body,'n:')); pts=int(field(body,'pts:')); t=float(field(body,'pts_time:'))
                if not configured or n!=len(frames) or n>=24 or pts!=n*1024 or abs(t-n/12)>.00001 or field(body,'fmt:')!=expected_format or field(body,'sar:')!='1/1' or field(body,'s:')!='320x180' or field(body,'i:')!='P': return False
                frames.append(dict(header=False,mapping=False,signature=None))
            elif 'rpu_type=' in body:
                if not frames or frames[-1]['header']: return False
                if any(field(body,k)!=v for k,v in [('rpu_type=','2'),('vdr_rpu_profile=','0'),('bl_bit_depth=','10'),('disable_residual_flag=','1')]): return False
                frames[-1]['header']=True
            elif 'color metadata:' in body:
                if not frames or frames[-1]['mapping'] or body.count('channel ')!=3: return False
                if any(field(body,k)!=v for k,v in [('signal_eotf=','65535'),('signal_color_space=','2'),('signal_bit_depth=','12')]): return False
                dm=int(field(body,'dm_metadata_id=')); peak=int(field(body,'source_max_pq='))
                expected=manifest['variable_frame_metadata'][len(frames)-1] if variable else dict(dm_metadata_id=0,source_max_pq=3079)
                if dm!=expected['dm_metadata_id'] or peak!=expected['source_max_pq']: return False
                frames[-1].update(mapping=True,signature=(dm,peak))
        return len(frames)==24 and all(f['header'] and f['mapping'] and f['signature'] is not None for f in frames)
    except (ValueError,TypeError,IndexError,UnicodeDecodeError): return False

def colored_pixels(raw):
    if len(raw)!=24*21600: return False
    for patch,ranges in enumerate(manifest['color_interpretation_oracle']['yuv420p_ranges']):
        x=10+20*patch;y=67
        for c,(width,offset,cx,cy) in enumerate([(160,0,x,y),(80,14400,x//2,y//2),(80,18000,x//2,y//2)]):
            lo,hi=ranges[c]
            for frame in range(24):
                mean=sum(raw[frame*21600+offset+yy*width+xx] for yy in range(cy-1,cy+2) for xx in range(cx-1,cx+2))/9
                if not lo<=mean<=hi: return False
    return True

rows=[]
for name,decoder,encoder,filtergraph in tuples:
 for case in manifest['cases']:
  source=assets/case['path']; negative=case['negative_max_frames'] is not None
  argv=[str(ffmpeg),'-hide_banner','-loglevel','warning' if negative else 'info','-nostats','-nostdin','-xerror','-threads','1']
  if name=='software-metal': argv+=['-init_hw_device','videotoolbox=plurx_p5_vt','-filter_hw_device','plurx_p5_vt']
  argv+=['-c:v','hevc','-strict_dovi','1','-err_detect','explode','-hwaccel', 'videotoolbox' if decoder=='vt' else 'none']
  if decoder=='vt': argv+=['-hwaccel_output_format','videotoolbox_vld','-hwaccel_flags','+require_hardware']
  if case['seek_seconds']: argv+=['-ss',str(case['seek_seconds'])]
  observed=filtergraph if negative else filtergraph.replace('tonemap','showinfo@plurx_p5_contract=checksum=0,tonemap',1)
  argv+=['-i',str(source),'-map','0:v:0','-an','-sn','-dn','-vf',observed+(',hwdownload,format=nv12,format=yuv420p' if negative and 'metal' in name else '')]
  target=output/(name+'-'+case['id']+('.yuv' if negative else '.mp4'))
  if negative: argv+=['-frames:v','24','-fps_mode','passthrough','-pix_fmt','yuv420p','-f','rawvideo','pipe:1']
  else:
   argv+=['-c:v','h264_videotoolbox' if encoder=='vt' else 'libx264','-b:v','500k','-maxrate','750k','-bufsize','1000k']
   if encoder=='vt': argv+=['-allow_sw','0']
   else: argv+=['-preset','veryfast','-profile:v','high']
   argv+=['-bf','0','-frames:v','24','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv','-f','mp4','-movflags','frag_keyframe+empty_moov+default_base_moof','pipe:1']
  result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=12)
  target.write_bytes(result.stdout); target.with_suffix('.log').write_bytes(result.stderr)
  row=dict(tuple=name,case=case['id'],argv=argv,exit=result.returncode,bytes=len(result.stdout),sha256=hashlib.sha256(result.stdout).hexdigest(),passed=False)
  if negative:
   diagnostic=result.stderr.decode(errors='replace').lower()
   row['frames']=len(result.stdout)//21600
   row['passed']=result.returncode>0 and len(result.stdout)%21600==0 and row['frames']<=case['negative_max_frames'] and any(x in diagnostic for x in ['required current-access-unit dolby state missing','required effective dolby mapping/color state incomplete','required effective dolby metadata missing or unsupported','error parsing dovi nal unit'])
  elif result.returncode==0:
   p=subprocess.run([str(ffprobe),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(target)],capture_output=True,timeout=8)
   target.with_suffix('.json').write_bytes(p.stdout); doc=json.loads(p.stdout); frames=doc.get('frames',[]); stream=doc.get('streams',[{}])[0]
   d=subprocess.run([str(ffmpeg),'-v','error','-nostdin','-threads','1','-i',str(target),'-map','0:v:0','-an','-frames:v','25','-fps_mode','passthrough','-pix_fmt','yuv420p','-f','rawvideo','pipe:1'],capture_output=True,timeout=8)
   raw=d.stdout; target.with_suffix('.decoded.yuv').write_bytes(raw)
   row['frames']=len(frames); row['decoded_bytes']=len(raw)
   signal=all(stream.get(k)==v for k,v in {'codec_name':'h264','pix_fmt':'yuv420p','sample_aspect_ratio':'1:1','avg_frame_rate':'12/1','field_order':'progressive'}.items())
   signal=signal and all(f.get('width')==160 and f.get('height')==90 and all(f.get(k)==v for k,v in {'color_primaries':'bt709','color_transfer':'bt709','color_space':'bt709','color_range':'tv'}.items()) for f in [stream]+frames)
   pts=len(frames)==24 and all(abs(float(f['best_effort_timestamp_time'])-i/12)<.001 for i,f in enumerate(frames))
   pixels=len(raw)==24*21600
   if pixels:
    for i in range(24):
     gray=[raw[i*21600+23*160+10+20*j] for j in range(8)]
     pixels=pixels and abs(gray[0]-16)<=8 and gray[7]>=100 and all(a<=b+8 for a,b in zip(gray,gray[1:]))
     for j in range(8):
      uv=11*80+5+10*j
      pixels=pixels and abs(raw[i*21600+14400+uv]-128)<=8 and abs(raw[i*21600+18000+uv]-128)<=8
    row['first_gray']=[raw[23*160+10+20*j] for j in range(8)]
   selected=selected_metadata(result.stderr,name,case['id']=='variable'); colors=colored_pixels(raw)
   row.update(signal=signal,pts=pts,pixels=pixels,selected_metadata=selected,colored_pixels=colors,passed=p.returncode==0 and d.returncode==0 and signal and pts and pixels and selected and colors)
  rows.append(row)
  (output/'receipt.json').write_text(json.dumps(dict(ffmpeg_sha256=hashlib.sha256(ffmpeg.read_bytes()).hexdigest(),concurrent_build_load=True,qualification='selected-graph PTS/metadata transport and independent color interpretation only; no per-frame rendered RPU-influence or performance claim',runs=rows,passed=all(r['passed'] for r in rows)),indent=2)+'\n')
  print(name,case['id'],result.returncode,row.get('frames'),row['passed'],flush=True)
print('passed',all(row['passed'] for row in rows),flush=True)
