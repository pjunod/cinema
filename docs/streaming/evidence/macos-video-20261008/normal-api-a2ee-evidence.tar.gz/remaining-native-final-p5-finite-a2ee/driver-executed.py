#!/usr/bin/env python3
"""Actual packaged daemon on private loopback/state; operational qualification, no fixture mode.

Only normal APIs discover and admit the source. Decoder caps are controlled API
claims; HTTP delivery and native decode observations do not claim client presentation.
"""
import argparse, hashlib, json, os, re, secrets, shutil, signal, socket, subprocess, threading, time, urllib.error, urllib.parse, urllib.request, uuid
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--bundle',required=True,type=Path);p.add_argument('--source',required=True,type=Path);p.add_argument('--output',required=True,type=Path);p.add_argument('--source-head',required=True);p.add_argument('--qualification-purpose',choices=['correctness','performance'],default='correctness');p.add_argument('--seconds',type=int,default=2);p.add_argument('--software-budget',type=int,default=8);p.add_argument('--hardware-preference',choices=['auto','videotoolbox'],default='auto');p.add_argument('--analytical-generator',type=Path,default=Path('<OWNED_WORK_ROOT>/remaining-native/scripts/generate-macos-video-fixtures'));p.add_argument('--hevc-auto',action='store_true');p.add_argument('--hevc',action='store_true');p.add_argument('--require-native-graph',action='store_true');p.add_argument('--extended',action='store_true');p.add_argument('--soak-seconds',type=int,default=1800);a=p.parse_args()
if not 1<=a.software_budget<=32:raise ValueError('controlled normal software pool1..32 only')
if not 0<=a.soak_seconds<=1800:raise ValueError('bounded0..1800second soak only')
if not 1<=a.seconds<=120:raise ValueError('bounded1..120second delivery only')
for item in [a.bundle,a.source,a.output]:
 if not item.is_absolute():raise ValueError('explicit absolute paths required')
if a.output.exists():raise ValueError('new private output required')
a.output.mkdir(mode=0o700,parents=True);root=a.output
executed_driver=Path(__file__).read_bytes();(root/'driver-executed.py').write_bytes(executed_driver);(root/'driver-executed.py').chmod(0o400)
binary=a.bundle/'bin/plurxd';ffmpeg=a.bundle/'bin/ffmpeg';ffprobe=a.bundle/'bin/ffprobe';module=a.bundle/'bin/plurx-source-parser.wasm'
for item in [binary,ffmpeg,ffprobe,module]:
 if not item.is_file() or item.is_symlink():raise ValueError('actual regular packaged artifacts required')
ports=[]
for _ in range(3):
 with socket.socket() as s:s.bind(('127.0.0.1',0));ports.append(s.getsockname()[1])
if len(set(ports))!=3:raise RuntimeError('reserved ports collided')
config=root/'plurx.toml';config.write_text(f'[server]\nname="Isolated normalized qualification"\nbind="127.0.0.1:{ports[0]}"\njellyfin_port=0\n[storage]\ndata_dir="{root}/data"\ncache_dir="{root}/cache"\ntranscode_dir="{root}/scratch"\n[cluster]\nraft_bind="127.0.0.1:{ports[1]}"\napi_bind="127.0.0.1:{ports[2]}"\n');config.chmod(0o600)
media=root/'media';media.mkdir(mode=0o700);source=media/'Mac Normalized Qualification (2026).mp4';shutil.copyfile(a.source,source);source.chmod(0o444)
aliases={}
if a.extended:
 for phase,count in [('baseline',30),('candidate',30),('capacity',7),('soak',4)]:
  for index in range(count):
   label=f'{phase}-{index:02d}';name=f'Mac Source {phase.title()} Case{chr(65+index//26)}{chr(65+index%26)} (2026).mp4';copy=media/name;shutil.copyfile(a.source,copy);copy.chmod(0o444);aliases[label]=name
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ};env.update(PLURX_HWACCEL=a.hardware_preference,PLURX_MDNS_ADVERTISE='0',PLURX_LOG='info,plurxd=debug')
argv=[str(binary),'--config',str(config),'run'];base=f'http://127.0.0.1:{ports[0]}'
if hashlib.sha256(source.read_bytes()).hexdigest()!='d86402326c3ef3b88c455ac089c8b94aa27fcbade48eb349499043f54ba5d062':raise RuntimeError('expected exact retained strict_p5_fresh source')
receipt={'schema_version':1,'driver_sha256':hashlib.sha256(executed_driver).hexdigest(),'driver_argv':list(__import__('sys').argv),'kind':'actual_packaged_normal_p5_vod_loopback','source_head':a.source_head,'qualification_purpose':a.qualification_purpose,'performance_claim':'none; timings retained only as correctness diagnostics' if a.qualification_purpose=='correctness' else 'explicit coordinated sampling window; timer boundaries retained','binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'module_sha256':hashlib.sha256(module.read_bytes()).hexdigest(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'argv':argv,'configured_environment':{k:v for k,v in env.items() if k.startswith('PLURX_')},'observations':[],'limitations':['Controlled caps-v2 API decoder claims; no actual client capability measurement','HTTP media/timeline and native decoded-frame observations, not client-rendered/presented frames','No deployed service, production installation, notarization, concurrency or soak acceptance']}
child=None;log=None;token=None;sessions=[];record_lock=threading.RLock()

def safe(value):
 if isinstance(value,dict):return {k:('<redacted>' if k.lower() in ['token','password','authorization','signature','access_token','refresh_token'] else safe(v)) for k,v in value.items()}
 if isinstance(value,list):return [safe(v) for v in value]
 if isinstance(value,str) and ('://' in value or value.startswith('/')):
  u=urllib.parse.urlsplit(value);query=[(k,'<redacted>' if any(x in k.lower() for x in ['token','signature','credential','secret','key']) else v) for k,v in urllib.parse.parse_qsl(u.query,keep_blank_values=True)];return urllib.parse.urlunsplit((u.scheme,u.netloc,u.path,urllib.parse.urlencode(query),u.fragment))
 return value

def save():
 with record_lock:(root/'receipt.json').write_text(json.dumps(safe(receipt),indent=2)+'\n')
def observe(v):
 with record_lock:
  receipt['observations'].append(v);save();print(json.dumps(safe(v)),flush=True)
def url(path):
 u=path if '://' in path else urllib.parse.urljoin(base,path if path.startswith('/') else '/api/v1'+path);parsed=urllib.parse.urlsplit(u)
 if parsed.hostname!='127.0.0.1' or parsed.port!=ports[0]:raise ValueError('qualification never contacts another service')
 return u

def raw(path,method='GET',body=None,auth=True,timeout=30,limit=64*1024*1024):
 headers={'Content-Type':'application/json'}
 if auth and token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request(url(path),data=None if body is None else json.dumps(body).encode(),headers=headers,method=method)
 try:r=urllib.request.urlopen(req,timeout=timeout)
 except urllib.error.HTTPError as error:
  detail=error.read(4096).decode(errors='replace');error.add_note(f'HTTP detail: {detail}');raise
 with r:
  data=r.read(limit+1)
  if len(data)>limit:raise RuntimeError('response exceeds qualification bound')
  return r.status,data,dict(r.headers)

def api(path,method='GET',body=None,auth=True,timeout=30):
 status,data,_=raw('/api/v1'+path,method,body,auth,timeout,2*1024*1024)
 return status,json.loads(data) if data else None

def fact_metrics():
 _,data,_=raw('/metrics',auth=False,limit=2*1024*1024)
 text=data.decode();values={key:int(re.search(r'plurx_decode_facts_lookups_total\{result="'+key+r'"\} (\d+)',text).group(1)) for key in ['hit','miss_collected','refused']}
 return values

def fetch(path,deadline):
 while True:
  try:return raw(path,timeout=max(.1,min(30,deadline-time.monotonic())))
  except urllib.error.HTTPError as e:
   if e.code!=503 or time.monotonic()>=deadline:raise
   match=re.search(r'/api/v1/hls/([^/]+)/',urllib.parse.urlsplit(url(path)).path)
   if match:
    try:
     state=api('/hls/'+match.group(1)+'/status',timeout=3)[1];system=api('/system',timeout=3)[1]
     rows=[]
     for line in subprocess.run(['ps','-axo','pid,ppid,command'],capture_output=True,text=True,check=True,timeout=3).stdout.splitlines()[1:]:
      fields=line.split(None,2)
      if len(fields)==3:rows.append(fields)
     owned={str(child.pid)}
     for _ in range(4):owned.update(row[0] for row in rows if row[1] in owned)
     processes=[{'pid':row[0],'parent':row[1],'command':row[2]} for row in rows if row[0] in owned and row[0]!=str(child.pid)]
     observe({'pending_media_status':state,'hardware_admission':{key:system.get(key) for key in ['active_transcodes','hw_slots_in_use','hw_slots_max','encoder_selected','hwaccel_requested']},'owned_descendant_commands':processes,'scope':'diagnostic snapshot after normal503; no capacity/deadline/owner bypass'})
    except (OSError,ValueError,subprocess.SubprocessError) as error:observe({'pending_diagnostic_error':str(error)})
   time.sleep(min(.5,max(0,deadline-time.monotonic())))

def playlist(created,deadline):
 u=created['playlist_url'];status,data,_=fetch(u,deadline);text=data.decode();lines=text.splitlines()
 if '#EXT-X-STREAM-INF' in text:
  child_uri=next(lines[i+1] for i,line in enumerate(lines) if line.startswith('#EXT-X-STREAM-INF'))
  u=urllib.parse.urljoin(url(u),child_uri);_,data,_=fetch(u,deadline);text=data.decode();lines=text.splitlines()
 init_match=re.search(r'#EXT-X-MAP:URI="([^"]+)"',text)
 if not init_match:raise RuntimeError('expected actual fMP4 init map')
 init_uri=urllib.parse.urljoin(url(u),init_match.group(1));entries=[];duration=None
 for line in lines:
  if line.startswith('#EXTINF:'):duration=float(line[8:].split(',')[0])
  elif line and not line.startswith('#') and duration is not None:entries.append((duration,urllib.parse.urljoin(url(u),line)));duration=None
 if not entries:raise RuntimeError('actual playlist contains no media')
 observe({'playlist_status':status,'playlist_sha256':hashlib.sha256(data).hexdigest(),'planned_segments':len(entries),'declared_media_seconds':sum(d for d,_ in entries),'endlist':'#EXT-X-ENDLIST' in text})
 return init_uri,entries

caps={'v':2,'client':{'kind':'qualification','build':'owned-actual-api'},'video':[{'codec':'h264','profiles':['baseline','main','high'],'max_width':3840,'max_height':2160,'max_frame_rate':{'numerator':60,'denominator':1},'present':['sdr']}],'audio':['aac'],'audio_sinks':[{'codec':'aac','max_channels':2,'sample_rates_hz':[48000]}],'containers':['mp4'],'transports':['hls'],'display':{'presentation_target':{'width_px':2560,'height_px':1440,'revision':1}}}
selection={'quality':{'mode':'manual','height':144},'codec':'h264','dynamic_range':'sdr','audio_offset_ms':0,'subtitles':{'mode':'off'}}
playback='normalized-'+uuid.uuid4().hex;client_id=str(uuid.uuid4());sequence=0;last_control_at=0

def create(start, source_id=None, player=None, native_expected=True):
 player=player or playback
 body={'playback_id':player,'request_id':uuid.uuid4().hex,'height':144,'quality_auto':False,'copy':False,'aac':True,'start':start,'presentation':'vod','block_budget_secs':30,'caps':caps,'transport':'native','intent':{'lifetime_id':player,'recipe_revision':1,'destination_revision':1 if start==0 else 2,'transport_revision':1,'selection':selection}}
 log_offset=(root/'daemon-private.log').stat().st_size
 facts_before_create=fact_metrics()
 began=time.monotonic();status,created=api('/files/'+str(file_id if source_id is None else source_id)+'/hls/sessions','POST',body,timeout=30)
 create_elapsed=time.monotonic()-began;facts_after_create=fact_metrics()
 candidate=next((c for c in created.get('quality_candidates',[]) if c['id']==created.get('quality_candidate_id')),None)
 if status!=200:raise RuntimeError('normal finite P5 create was refused')
 if candidate and candidate['route']!='encode':raise RuntimeError('finite P5 canonical row is not Encode')
 if candidate and candidate['target_height']!=144:raise RuntimeError('wrong normalized target')
 with (root/'daemon-private.log').open('rb') as diagnostic:
  diagnostic.seek(log_offset);plan_lines=[line for line in diagnostic.read().decode(errors='replace').splitlines() if 'resolved Mac processing for new movie plan' in line]
 resolved=[{'selection':m.group(1),'pipeline':m.group(2)} for line in plan_lines if (m:=re.search(r'selection=\"([^\"]+)\" pipeline=\"([^\"]+)\"',line))]
 observe({'selected_recipe_digest':candidate['recipe_digest'] if candidate else None,'canonical_candidate_binding':candidate,'finite_manual_scope':'canonical binding may be absent on incumbent manual route; actual strict graph/identity and bytes required','response_encoder':created.get('encoder'),'resolved_plan_diagnostics':resolved,'diagnostic_scope':'new plans during this create, includes catalog alternatives; encoder response identifies selected delivery'})
 strict_pipelines={'dovi_strict_tonemapx':'p5_software_cpu','vt_dovi_tonemapx':'p5_vt_tonemapx','vt_dovi_metal':'p5_vt_metal','dovi_metal':'p5_software_metal'}
 selected=resolved[-1] if resolved else {}
 if a.require_native_graph and (selected.get('selection')!='selected' or selected.get('pipeline') not in strict_pipelines or 'videotoolbox' not in created.get('encoder','').lower()):raise RuntimeError('actual normal P5 producer did not select an authorized strict graph')
 identity_line=plan_lines[-1] if plan_lines else ''
 identity_match=re.search(r'macos_identity_digest=[\"]?([a-f0-9]{64})',identity_line)
 if a.require_native_graph and ('strict_dolby=true' not in identity_line or identity_match is None):raise RuntimeError('selected strict P5 plan did not expose its captured identity')
 if identity_match:
  current_report=api('/settings')[1]['macos_video_processing'];graph=strict_pipelines[selected['pipeline']]
  if dict(current_report['graphs']).get(graph,{}).get('availability')!='available':raise RuntimeError('selected strict production graph is not independently available')
  identity=current_report['identity'];identity_keys=['ffmpeg_sha256','ffprobe_sha256','patch_digest','linked_libraries_digest','os_build','architecture','hardware_class','graph_revision']
  observed_digest=hashlib.sha256(json.dumps({key:identity[key] for key in identity_keys},separators=(',',':')).encode()).hexdigest()
  if observed_digest!=identity_match.group(1):raise RuntimeError('strict plan captured a different processing identity from current immutable report')
  if identity['ffmpeg_sha256']!=hashlib.sha256(ffmpeg.read_bytes()).hexdigest() or identity['ffprobe_sha256']!=hashlib.sha256(ffprobe.read_bytes()).hexdigest():raise RuntimeError('strict captured implementation differs from packaged native tools')
  observe({'strict_selected_pipeline':selected['pipeline'],'strict_graph':graph,'captured_identity_digest':identity_match.group(1),'scope':'frozen semantic plan identity observed before producer and matched immutable runtime report/tools; real served-frame proof follows'})
 sessions.append(created['session_id']);observe({'actual_source_id':file_id if source_id is None else source_id,'actual_playback_id':player,'create_status':status,'create_seconds':create_elapsed,'timer_boundary':'starts immediately before ordinary POSTcreate; includes its source-facts/catalog/decision work; excludes prior daemon identity initialization, settings and normal library scan; ends at actual HTTP bytes for startup observations','source_facts_before_create':facts_before_create,'source_facts_after_create':facts_after_create,'identity_condition':'daemon identity initialized before this request; source aliases prevent encoded-cache sharing but do not claim cold parser identity','start':start,'response':created,'selected_candidate':candidate});return created,candidate,began

def control(created,demand,position,seek=None,record=True):
 global sequence,last_control_at
 time.sleep(max(0,.5-(time.monotonic()-last_control_at)))
 c=created.get('control')
 if not c:raise RuntimeError('ordinary control contract absent')
 sequence+=1;wire={**selection};wire['subtitle']=wire.pop('subtitles')
 body={'protocol':c['protocol'],'generation':c['generation'],'control_epoch':c['control_epoch'],'client_instance_id':client_id,'sequence':sequence,'demand':demand,'position_ms':position,'buffered_through_ms':position,'playback_rate':0 if demand=='hold' else 1,'render_state':'seeking' if seek is not None else 'waiting','seek_target_ms':seek,'selection':wire,'supported_actions':[],'capabilities':{'platform':'apple','max_height':2160,'codecs':['h264'],'dynamic_ranges':['sdr'],'dual_player_preparation':False,'presentation_target':caps['display']['presentation_target']}}
 status,result=api('/hls/'+created['session_id']+'/control','POST',body,timeout=10);last_control_at=time.monotonic()
 if record:observe({'control_demand':demand,'control_seek':seek,'http_status':status,'response':result})
 if result['accepted_sequence']!=sequence:raise RuntimeError('control sequence not accepted')
 return result

def release_session(created):
 status,_,_=raw('/api/v1/hls/'+created['session_id'],'DELETE');assert status==204

def compare_normalized_pixels(native_fragment,cpu_fragment,width,height):
 import runpy
 model=runpy.run_path(str(a.analytical_generator));expected_gray=[model['rgb_to_yuv']((n,n,n),'sdr',8) for n in model['GRAY_NITS']['sdr']];peak=100
 expected_color=[model['rgb_to_yuv'](rgb,'sdr',8) for rgb in [(peak,0,0),(0,peak,0),(0,0,peak),(peak,peak,0),(0,peak,peak),(peak,0,peak),(0,0,0),(peak,peak,peak)]]
 observations={};samples={};gray_y=height//3;color_y=height*5//6
 normalized_width,normalized_height=width,height
 for name,fragment in [('native',native_fragment),('cpu',cpu_fragment),('encoded_source',source)]:
  width,height=(3840,2160) if name=='encoded_source' else (normalized_width,normalized_height);gray_y=height//3;color_y=height*5//6
  graph=f'[0:v]split[a][b];[a]crop=iw:2:0:{gray_y}[g];[b]crop=iw:2:0:{color_y}[c];[g][c]vstack,format=yuv420p[v]'
  argv=[str(ffmpeg),'-v','error','-nostdin','-threads','1','-i',str(fragment),'-filter_complex_threads','1','-filter_complex',graph,'-map','[v]','-frames:v','48','-f','rawvideo','pipe:1']
  data=subprocess.run(argv,capture_output=True,check=True,timeout=30).stdout;frame_bytes=width*6
  if len(data)!=frame_bytes*48:raise RuntimeError('normalized analytical patch decode did not produce48 frames')
  frames=[];max_gray_y_error=0;max_neutral_chroma=0;max_color_error=0
  for frame in range(48):
   raw=data[frame*frame_bytes:(frame+1)*frame_bytes];patches=[]
   for band,expected in [(0,expected_gray),(1,expected_color)]:
    for i,target in enumerate(expected):
     x=width*(2*i+1)//16;y=band*2;sample=(raw[y*width+x],raw[width*4+band*(width//2)+x//2],raw[width*5+band*(width//2)+x//2]);patches.append(sample)
     if band==0:max_gray_y_error=max(max_gray_y_error,abs(sample[0]-target[0]));max_neutral_chroma=max(max_neutral_chroma,abs(sample[1]-128),abs(sample[2]-128))
     else:max_color_error=max(max_color_error,max(abs(observed-code) for observed,code in zip(sample,target)))
   frames.append(patches)
  samples[name]=frames;observations[name]={'decoded_patch_frames':48,'max_gray_y_absolute_error':max_gray_y_error,'max_neutral_chroma_distance_from128':max_neutral_chroma,'max_color_code_absolute_error':max_color_error,'argv':argv}
  if max_gray_y_error>12 or max_neutral_chroma>12:raise RuntimeError('normalized gray patches violate existing analytical smoke tolerance12')
 stats=root/'normalized-first48-psnr.log';argv=[str(ffmpeg),'-v','info','-nostdin','-threads','1','-i',str(native_fragment),'-threads','1','-i',str(cpu_fragment),'-filter_complex_threads','1','-filter_complex',f'[0:v]setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[a][b]psnr=stats_file={stats}', '-frames:v','48','-f','null','-'];result=subprocess.run(argv,capture_output=True,check=True,timeout=30);lines=stats.read_text().splitlines()
 if len(lines)!=48:raise RuntimeError('actual normalized pixel comparison did not cover48 frames')
 psnr=[float(re.search(r'psnr_avg:([0-9.inf]+)',line).group(1)) for line in lines]
 source_deltas={name:max(abs(left-right) for nf,sf in zip(samples[name],samples['encoded_source']) for np,sp in zip(nf,sf) for left,right in zip(np,sp)) for name in ['native','cpu']}
 max_pair_delta=max(abs(left-right) for nf,cf in zip(samples['native'],samples['cpu']) for np,cp in zip(nf,cf) for left,right in zip(np,cp))
 observe({'normalized_cpu_native_pixels':observations,'analytical_generator_sha256':hashlib.sha256(a.analytical_generator.read_bytes()).hexdigest(),'pair_patch_max_absolute_code_difference':max_pair_delta,'output_vs_encoded_source_patch_max_absolute_difference':source_deltas,'first48_pair_psnr_min_db':min(psnr) if min(psnr)!=float('inf') else 'infinite','first48_pair_psnr_mean_db':sum(psnr)/len(psnr) if max(psnr)!=float('inf') else 'infinite','exact_pixel_equal_frames':sum(value==float('inf') for value in psnr),'psnr_argv':argv,'psnr_scope':'actual decoded compressed CPU/native delivery frames with identical source geometry/rate controls; numeric observations, no invented universal PSNR threshold','gray_acceptance':'existing fixture tolerance12 for gray luma and neutral chroma; color deltas reported separately'})

def run_hevc():
 import copy
 global caps
 original_caps=copy.deepcopy(caps)
 try:
  caps['display']['hdr']=True;caps['hls_hevc_sample_entries']=['hvc1'];caps['video'].append({'codec':'hevc','profiles':['main10'],'present':['pq'],'max_width':3840,'max_height':2160,'max_frame_rate':{'numerator':60,'denominator':1},'max_bitrate_bps':40000000})
  api('/settings','PUT',{'macos_hevc_output_enabled':True,'macos_video_processing_enabled':True,'playback_sdr_master_codecs':True})
  deadline=time.monotonic()+90
  while True:
   report=api('/settings')[1]['macos_video_processing'];graphs=dict(report['graphs'])
   if any(graphs.get(name,{}).get('availability')=='available' for name in ['hevc_hdr10','hevc_hdr10_host']):break
   if time.monotonic()>deadline:raise RuntimeError('actual HEVC output graph unavailable')
   time.sleep(.5)
  bootstrap,_,_=create(0,player=uuid.uuid4().hex)
  row=next((c for c in bootstrap['quality_candidates'] if c.get('grade')=='hdr10' and c.get('planned_codec')=='hevc' and c['target_height']==1080 and c['route']=='encode' and c['decoder_compatible']),None)
  if row is None:raise RuntimeError('ordinary actual catalog offered no finite HEVC1080 candidate')
  release_session(bootstrap)
  player=uuid.uuid4().hex;selected={'quality':{'mode':'auto','height':1080,'candidate_id':row['id']},'codec':'hevc','dynamic_range':'hdr10','audio_offset_ms':0,'subtitles':{'mode':'off'}}
  body={'playback_id':player,'request_id':uuid.uuid4().hex,'height':1080,'hdr10':True,'quality_auto':True,'copy':False,'aac':True,'start':0,'presentation':'vod','block_budget_secs':30,'caps':caps,'transport':'native','intent':{'lifetime_id':player,'recipe_revision':1,'destination_revision':1,'transport_revision':1,'selection':selected}}
  began=time.monotonic();status,created=api('/files/'+str(file_id)+'/hls/sessions','POST',body,timeout=30);sessions.append(created['session_id'])
  accepted=next((c for c in created.get('quality_candidates',[]) if c['id']==created.get('quality_candidate_id')),None)
  if not accepted or accepted['id']!=row['id'] or accepted.get('planned_codec')!='hevc' or accepted['route']!='encode':raise RuntimeError('actual finite producer did not accept exact HEVC candidate')
  if 'videotoolbox' not in created.get('encoder','').lower():raise RuntimeError('finite HEVC did not use observed VideoToolbox encoder')
  init_uri,entries=playlist(created,began+30);_,init,_=fetch(init_uri,began+30);_,first,_=fetch(entries[0][1],began+30);fragment=root/'finite-hevc-first-fragment.mp4';fragment.write_bytes(init+first)
  first_http_seconds=time.monotonic()-began
  _,master_bytes,_=fetch('/api/v1/hls/'+created['session_id']+'/master.m3u8',time.monotonic()+30);master_codecs=re.findall(r'CODECS="([^"]+)"',master_bytes.decode())
  if not master_codecs or not any(codecs.startswith('hvc1.') for codecs in master_codecs):raise RuntimeError('actual HEVC master did not publish codec from served initialization')
  decoded=subprocess.run([str(ffprobe),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(fragment)],capture_output=True,timeout=30,check=True);facts=json.loads(decoded.stdout);stream=facts['streams'][0];frames=facts['frames']
  if accepted.get('grade')!='hdr10':raise RuntimeError('selected HEVC producer did not retain HDR10 grade')
  if len(frames)!=48 or stream['codec_name']!='hevc' or stream['codec_tag_string']!='hvc1' or stream['profile']!='Main 10':raise RuntimeError('served finite HEVC init/sample configuration or decoded frames failed')
  if any((f['width'],f['height'])!=(accepted['width'],accepted['height']) or f.get('color_space')!='bt2020nc' or f.get('color_transfer')!='smpte2084' or f.get('color_primaries')!='bt2020' for f in frames):raise RuntimeError('finite HEVC decoded canvas/color failed')
  (root/'finite-hevc-first48.json').write_text(json.dumps(facts,indent=2)+'\n')
  observe({'finite_hevc_actual_create_status':status,'accepted_candidate':accepted,'response_encoder':created['encoder'],'continuous_media':'absent in ordinary request','served_init_codec':stream['codec_name'],'served_init_sample_entry':stream['codec_tag_string'],'served_init_profile':stream['profile'],'first48_actual_decoded_frames':len(frames),'first_http_availability_upperbound_seconds':first_http_seconds,'master_codec_strings':master_codecs,'master_sha256':hashlib.sha256(master_bytes).hexdigest(),'served_init_sha256':hashlib.sha256(init).hexdigest(),'served_first_media_sha256':hashlib.sha256(first).hexdigest(),'client_presentation':'unmeasured'})
  release_session(created)
  if a.hevc_auto:
   caps['display']['presentation_target']={'width_px':1920,'height_px':1080,'revision':2}
   for entry in caps['video']:entry['max_width']=1920;entry['max_height']=1080
   for enabled,expected_codec in [(False,'h264'),(True,'hevc')]:
    api('/settings','PUT',{'macos_hevc_output_enabled':enabled,'playback_display_aware_auto':False})
    auto_body=copy.deepcopy(body);auto_body['playback_id']=uuid.uuid4().hex;auto_body['request_id']=uuid.uuid4().hex;auto_body['caps']=caps;auto_body['intent']['lifetime_id']=auto_body['playback_id'];auto_body['intent']['selection']['quality']={'mode':'auto','height':1080};auto_body['intent']['selection']['codec']='auto'
    began=time.monotonic();status,auto_created=api('/files/'+str(file_id)+'/hls/sessions','POST',auto_body,timeout=30);sessions.append(auto_created['session_id']);auto_candidate=next((c for c in auto_created.get('quality_candidates',[]) if c['id']==auto_created.get('quality_candidate_id')),None)
    if enabled and (not auto_candidate or auto_candidate.get('planned_codec')!='hevc' or auto_candidate['target_height']!=1080):raise RuntimeError('finite unbound Auto did not bind the enabled HEVC candidate')
    if auto_candidate and auto_candidate.get('planned_codec',expected_codec)!=expected_codec:raise RuntimeError('finite unbound Auto candidate disagreed with saved preference')
    init_uri,entries=playlist(auto_created,began+30);_,auto_init,_=fetch(init_uri,began+30);_,auto_first,_=fetch(entries[0][1],began+30);auto_fragment=root/f'finite-auto-{expected_codec}-first-fragment.mp4';auto_fragment.write_bytes(auto_init+auto_first)
    _,auto_master,_=fetch('/api/v1/hls/'+auto_created['session_id']+'/master.m3u8',time.monotonic()+30);auto_codecs=re.findall(r'CODECS="([^"]+)"',auto_master.decode());expected_prefix='hvc1.' if enabled else 'avc1.'
    if not any(value.startswith(expected_prefix) for value in auto_codecs):raise RuntimeError('finite unbound Auto master disagreed with codec preference')
    observed=subprocess.run([str(ffprobe),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(auto_fragment)],capture_output=True,check=True,timeout=30);auto_facts=json.loads(observed.stdout);auto_frames=auto_facts['frames'][:48]
    if len(auto_frames)!=48 or auto_facts['streams'][0]['codec_name']!=expected_codec or any((f['width'],f['height'])!=(1920,1080) or f.get('color_range')!='tv' or f.get('color_space')!='bt2020nc' or f.get('color_transfer')!='smpte2084' or f.get('color_primaries')!='bt2020' for f in auto_frames):raise RuntimeError('finite unbound Auto actual decoded output disagreed with preference')
    (root/f'finite-auto-{expected_codec}-first48.json').write_text(json.dumps(auto_facts,indent=2)+'\n');observe({'finite_auto_hevc_preference':enabled,'display_aware_auto_saved':False,'actual_create_status':status,'candidate_id_explicitly_requested':False,'accepted_candidate':auto_candidate,'actual_decoded_codec':auto_facts['streams'][0]['codec_name'],'actual_decoded_first48':len(auto_frames),'master_codec_strings':auto_codecs,'scope':'normal finite Auto output behavior; cached-byte reuse may occur; no startup-performance or client-presentation claim'})
    release_session(auto_created)
 finally:
  caps=original_caps;api('/settings','PUT',{'macos_hevc_output_enabled':False,'playback_sdr_master_codecs':False,'playback_display_aware_auto':True})

def run_extended(library_id):
 from concurrent.futures import ThreadPoolExecutor
 import math
 deadline=time.monotonic()+120;files={}
 while True:
  items=api('/libraries/'+str(library_id)+'/items?limit=200')[1]['items']
  for item in items:
   detail=api('/items/'+str(item['id']))[1]
   for f in detail['files']:files[f['filename']]=f['id']
  if all(name in files for name in aliases.values()):break
  if time.monotonic()>deadline:raise RuntimeError('normal scan did not discover independent aliases')
  time.sleep(.5)
 distinct=set();samples={'baseline':[],'candidate':[]}
 for index in range(30):
  order=['baseline','candidate'] if index%2==0 else ['candidate','baseline']
  for phase in order:
   api('/settings','PUT',{'macos_video_processing_enabled':phase=='candidate'})
   created,candidate,began=create(0,files[aliases[f'{phase}-{index:02d}']],uuid.uuid4().hex,native_expected=phase=='candidate')
   if candidate['id'] in distinct or candidate['complete_cache']:raise RuntimeError('startup sample reused a cached/shared recipe')
   distinct.add(candidate['id']);init,entries=playlist(created,began+30);_,_,_=fetch(init,began+30);_,data,_=fetch(entries[0][1],began+30)
   elapsed=time.monotonic()-began;samples[phase].append(elapsed);observe({'fresh_start_route':phase,'sample':index+1,'first_http_availability_upperbound_seconds':elapsed,'poll_interval_seconds':.5,'actual_candidate_id':candidate['id'],'complete_cache':candidate['complete_cache'],'first_media_bytes':len(data)})
   release_session(created)
 for phase,values in samples.items():
  ordered=sorted(values);observe({'startup_distribution_route':phase,'n':len(values),'p50_seconds':ordered[len(values)//2],'p95_seconds':ordered[math.ceil(.95*len(values))-1],'min_seconds':ordered[0],'max_seconds':ordered[-1],'classification':'distinct normal-scanned source identities, uncached candidate recipes; HTTP availability upperbounds, not presentation'})
 api('/settings','PUT',{'macos_video_processing_enabled':True})
 capacity_offset=0;supported=0
 for count in [1,2,4]:
  sources=[files[aliases[f'capacity-{i:02d}']] for i in range(capacity_offset,capacity_offset+count)];capacity_offset+=count
  began=time.monotonic()
  with ThreadPoolExecutor(max_workers=count) as pool:
   futures=[pool.submit(create,0,source_id,uuid.uuid4().hex) for source_id in sources]
   admitted=[];errors=[]
   for f in futures:
    try:admitted.append(f.result())
    except Exception as error:errors.append(str(error))
  ids=[candidate['id'] for _,candidate,_ in admitted]
  if len(ids)!=len(set(ids)):raise RuntimeError('capacity trial shared candidate recipes')
  results=[]
  def first_publication(row):
   created,candidate,start=row;init,entries=playlist(created,start+30);_,_,_=fetch(init,start+30);_,data,_=fetch(entries[0][1],start+30)
   return {'candidate_id':candidate['id'],'complete_cache':candidate['complete_cache'],'first_http_upperbound_seconds':time.monotonic()-start,'media_bytes':len(data)}
  with ThreadPoolExecutor(max_workers=count) as pool:
   futures=[pool.submit(first_publication,row) for row in admitted]
   for f in futures:
    try:results.append(f.result())
    except Exception as error:errors.append(str(error))
  for created,_,_ in admitted:release_session(created)
  okay=len(results)==count and not errors and all(not row['complete_cache'] for row in results)
  if okay:supported=count
  observe({'capacity_trial_sessions':count,'sources_independent':True,'first_http_results':results,'errors':errors,'admitted_and_published':okay,'capacity_claim':'short admission/publication observation only; no advertised realtime capacity'})
 if supported==0:raise RuntimeError('no candidate source admitted for soak')
 count=min(supported,4);soak=[]
 for index in range(count):
  created,candidate,_=create(0,files[aliases[f'soak-{index:02d}']],uuid.uuid4().hex)
  if candidate['complete_cache']:raise RuntimeError('soak unexpectedly began from completed cache')
  init,entries=playlist(created,time.monotonic()+30);_,_,_=fetch(init,time.monotonic()+30);soak.append((created,candidate,entries))
 if len({candidate['id'] for _,candidate,_ in soak})!=count:raise RuntimeError('soak shared recipes')
 began=time.monotonic();turn=0;bytes_total=0;statuses=[]
 while time.monotonic()-began<a.soak_seconds:
  for created,candidate,entries in soak:
   control(created,'active',0,record=False)
   d,u=entries[turn%len(entries)];_,data,_=fetch(u,time.monotonic()+30);bytes_total+=len(data)
   state=api('/hls/'+created['session_id']+'/status')[1]
   if state.get('producer_state')=='failed':raise RuntimeError('producer failed during soak')
   statuses.append({'candidate_id':candidate['id'],'status':state})
  turn+=1
  if turn==1 or turn%12==0:observe({'soak_seconds':time.monotonic()-began,'independent_sessions':count,'completed_http_objects':turn*count,'http_bytes':bytes_total,'latest_status':statuses[-count:],'client_presentation':'unmeasured; protocol demand and cached-object delivery loops'})
  time.sleep(min(5,max(0,a.soak_seconds-(time.monotonic()-began))))
 for created,_,_ in soak:release_session(created)
 observe({'soak_completed_seconds':time.monotonic()-began,'sessions':count,'objects':turn*count,'bytes':bytes_total,'limitations':['HTTP/control and producer state soak, not actual client presentation','After materialization, repeated cached objects do not prove sustained encoder concurrency','Process RSS/energy/copy instrumentation unmeasured unless separately retained']})

try:
 daemon_launch_began=time.monotonic();log=(root/'daemon-private.log').open('wb');child=subprocess.Popen(argv,env=env,cwd=root,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True);deadline=time.monotonic()+180
 while True:
  if child.poll() is not None:raise RuntimeError('isolated actual daemon exited during startup')
  try:api('/server',auth=False);break
  except (OSError,ValueError):
   if time.monotonic()>deadline:raise
   time.sleep(.25)
 observe({'daemon_api_ready_seconds_since_launch':time.monotonic()-daemon_launch_began,'scope':'first successful own server-info HTTP response, not client click-to-play'})
 token=api('/setup','POST',{'username':'qualification-admin','password':secrets.token_urlsafe(30)},False)[1]['token']
 api('/settings','PUT',{'macos_video_processing_enabled':True,'macos_hevc_output_enabled':False,'playback_display_aware_auto':True,'transcode_software_pool_threads':a.software_budget})
 deadline=time.monotonic()+90
 while True:
  settings=api('/settings')[1];report=settings['macos_video_processing']
  strict_graphs=dict(report['graphs'])
  if all(strict_graphs.get(name,{}).get('availability')=='available' for name in ['p5_software_cpu','p5_vt_tonemapx','p5_vt_metal','p5_software_metal']):break
  if time.monotonic()>deadline:
   observe({'actual_runtime_report_at_timeout':report})
   raise RuntimeError('actual strict P5 runtime inventory did not independently admit all4graphs')
  time.sleep(.5)
 before_facts=fact_metrics();observe({'bound_facts_before':before_facts})
 observe({'graph_readiness_seconds_since_daemon_launch':time.monotonic()-daemon_launch_began,'identity_condition':'compatibility report ready before POSTcreate timers; no per-route cold identity claim'})
 observe({'normal_saved_settings':{k:settings[k] for k in ['macos_video_processing_enabled','playback_display_aware_auto','transcode_max_hw_sessions','transcode_software_pool_threads']},'runtime_report':report})
 lib=api('/libraries','POST',{'name':'Owned normalized qualification','kind':'movies','paths':[str(media)]})[1];deadline=time.monotonic()+90
 while True:
  items=api('/libraries/'+str(lib['id'])+'/items?limit=200')[1]['items']
  if items:
   details=[api('/items/'+str(item['id']))[1] for item in items]
   detail=next((d for d in details if any(f['filename']==source.name for f in d['files'])),None)
   if detail:break
  if time.monotonic()>deadline:raise RuntimeError('normal source scan did not discover file')
  time.sleep(.5)
 file=next(f for f in detail['files'] if f['filename']==source.name);file_id=file['id'];observe({'normal_scanned_file':file})
 created,candidate,began=create(0);deadline=began+30;init_uri,entries=playlist(created,deadline);_,init,_=fetch(init_uri,deadline);duration,first_uri=entries[0];_,first,_=fetch(first_uri,deadline)
 first_delivery_seconds=time.monotonic()-began
 fragment=root/'first-fragment.mp4';fragment.write_bytes(init+first)
 observed=subprocess.run([str(ffprobe),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(fragment)],capture_output=True,timeout=20,check=True);facts=json.loads(observed.stdout);frames=facts['frames'][:48]
 if len(frames)!=24:raise RuntimeError('served P5 normal producer must decode all24 real frames')
 stream=facts['streams'][0]
 if stream.get('codec_name')!='h264' or stream.get('codec_tag_string')!='avc1' or stream.get('pix_fmt')!='yuv420p' or stream.get('color_range')!='tv':raise RuntimeError('strict P5 served output did not retain SDR AVC8 limited signaling')
 if any('dovi' in json.dumps(frame.get('side_data_list',[])).lower() or 'dolby' in json.dumps(frame.get('side_data_list',[])).lower() for frame in frames):raise RuntimeError('strict P5→SDR output retained Dolby frame signaling')
 if any((f['width'],f['height'])!=(256,144) for f in frames):raise RuntimeError('produced canvas disagrees with actual normalized candidate')
 if any(f.get('interlaced_frame')!=0 or any(f.get(key)!='bt709' for key in ['color_space','color_transfer','color_primaries']) for f in frames):raise RuntimeError('actual SDR frame color/progressive contract changed')
 stamps=[float(f['best_effort_timestamp_time']) for f in frames]
 if any(right<=left for left,right in zip(stamps,stamps[1:])):raise RuntimeError('decoded frame presentation timestamps did not advance')
 if any(abs(stamp-stamps[0]-index/12)>0.005 for index,stamp in enumerate(stamps)):raise RuntimeError('served P5 frame timeline differs from source24frames at12fps')
 (root/'all24-decoded-observations.json').write_text(json.dumps({'streams':facts['streams'],'frames':frames},indent=2)+'\n');observe({'first_object_startup_seconds':first_delivery_seconds,'startup_goal_seconds':30,'startup_goal_met':first_delivery_seconds<=30,'all24_actual_decoded_frames':24,'produced_canvas':[256,144],'first_init_sha256':hashlib.sha256(init).hexdigest(),'first_media_sha256':hashlib.sha256(first).hexdigest()})
 total_bytes=0;objects=0;duration=0
 for d,u in entries:
  _,data,_=fetch(u,time.monotonic()+30);total_bytes+=len(data);objects+=1;duration+=d
 observe({'strict_p5_sdr_http_objects':objects,'declared_media_seconds':duration,'http_bytes':total_bytes,'scope':'normal held-source-authorized strict P5→SDR AVC finite delivery; all24 actual served frames BT709/progressive; client presentation and calibrated display unmeasured'})
 release_session(created)
 after_facts=fact_metrics();observe({'bound_facts_after':after_facts});assert after_facts['miss_collected']>before_facts['miss_collected']
 if a.hevc or a.hevc_auto or a.extended:raise RuntimeError('bounded P5 case does not include HEVC or extended timing')
 receipt['result']='passed_actual_normal_p5_sdr24_source_owned_delivery'
except Exception as error:receipt['result']='failed';receipt['error']=str(error);raise
finally:
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGINT)
  try:child.wait(timeout=30)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
 if child is not None:receipt['shutdown_exit']=child.returncode
 if log is not None:log.close()
 token=None;save();print(json.dumps({'result':receipt.get('result'),'receipt':str(root/'receipt.json')}),flush=True)
