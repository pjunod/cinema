import subprocess,json,hashlib
from pathlib import Path
root=Path('/experiment');pkg=root/'dolby-live-bwdif-correct-package';fixtures=root/'remaining-dolby/crates/plurxd/fixtures/macos-processing';out=root/'dolby-hlg-burn-hdr-bwdif-controls';out.mkdir(exist_ok=False);rows=[]
metal='scale_vt=w=160:h=90:format=p010le,tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0'
for name,source,operation in [('hlg-text',fixtures/'hlg.mp4','text'),('hlg-bitmap',fixtures/'pgs-hlg.mkv','bitmap')]+[(family+'-'+parity,root/'dolby-hdr-woven-feasibility'/(family+'-'+parity+'.mp4'),'bwdif') for family in ['hdr10','hlg'] for parity in ['tff','bff']]:
 target=out/(name+'.mp4');argv=[str(pkg/'ffmpeg'),'-hide_banner','-loglevel','verbose','-nostdin','-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld','-i',str(source),'-an','-sn','-dn']
 if operation=='bitmap':argv+=['-filter_complex','[0:v]'+metal+',hwdownload,format=nv12[vburn];[0:s:0]scale=160:90[sburn];[vburn][sburn]overlay=eof_action=pass[o]','-map','[o]']
 else:
  filter=metal+",hwdownload,format=nv12,subtitles='"+str(fixtures/'burn.ass')+"'" if operation=='text' else 'bwdif_videotoolbox=mode=send_frame:parity=auto:deint=interlaced,'+metal
  argv+=['-map','0:v:0','-vf',filter]
 argv+=['-c:v','h264_videotoolbox','-b:v','500k','-maxrate','1000k','-bufsize','2000k','-allow_sw','0','-bf','0','-frames:v','12','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv','-f','mp4','-movflags','frag_keyframe+empty_moov+default_base_moof',str(target)];r=subprocess.run(argv,capture_output=True,timeout=20);(out/(name+'.log')).write_bytes(r.stderr);row={'name':name,'operation':operation,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'argv':argv,'exit':r.returncode,'output_bytes':target.stat().st_size if target.exists() else 0}
 if r.returncode==0:
  probe=[str(pkg/'ffprobe'),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(target)];doc=json.loads(subprocess.check_output(probe));(out/(name+'.json')).write_text(json.dumps(doc,indent=2));decode=[str(pkg/'ffmpeg'),'-v','error','-i',str(target),'-pix_fmt','yuv420p','-f','rawvideo','pipe:1'];raw=subprocess.check_output(decode);(out/(name+'.yuv')).write_bytes(raw);row.update(probe_argv=probe,decode_argv=decode,frames=len(doc['frames']),stream=doc['streams'][0],reference_white=[raw[i*21600+30*160+90] for i in range(12)])
  if operation=='text':
   change=[sum(abs(raw[i*21600+y*160+x]-raw[y*160+x]) for y in range(70,78) for x in range(60,100))/320 for i in range(12)];assert all(change[i]>=8 for i in [5,6,7]) and all(change[i]<=3 for i in [1,2,10,11]);row['cue_change']=change
  if operation=='bitmap':
   values=[[raw[i*21600+75*160+130],raw[i*21600+14400+37*80+65],raw[i*21600+18000+37*80+65]] for i in range(12)];assert all(all(abs(a-b)<=10 for a,b in zip(v,[39,115,185] if 3<=i<9 else [16,128,128])) for i,v in enumerate(values));row['pgs_samples']=values
  assert all(abs(n-156)<=12 for n in row['reference_white']);assert row['frames']==12 and row['stream']['sample_aspect_ratio']=='1:1'
 else:
  assert operation=='bwdif';row['classification']='testedHigh10interlacedVTdecoder_surface_tuple_unsupported';row['stderr_excerpt']=r.stderr.decode()[-5000:]
 rows.append(row)
(out/'receipt.json').write_text(json.dumps({'ffmpeg_sha256':hashlib.sha256((pkg/'ffmpeg').read_bytes()).hexdigest(),'observations':rows},indent=2)+'\n');print(json.dumps([{k:r.get(k) for k in ['name','exit','frames','output_bytes','classification']} for r in rows]))
