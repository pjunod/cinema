import runpy,json,subprocess,hashlib
from pathlib import Path
from array import array
root=Path('/experiment');repo=root/'remaining-dolby';pkg=root/'dolby-live-bwdif-correct-package';out=root/'dolby-hdr-woven-feasibility';out.mkdir(exist_ok=False);base=runpy.run_path(str(repo/'scripts/generate-macos-video-fixtures'));hlg=runpy.run_path(str(repo/'scripts/generate-macos-extension-fixtures'));records=[]
def pattern(family,index):
 if family=='hdr10':return base['pattern']('hdr10',10,index)
 gray=[hlg['codes']((n,n,n),'hlg') for n in (0,1,10,100,203,400,700,1000)];colors=[hlg['codes'](rgb,'hlg') for rgb in ((400,0,0),(0,400,0),(0,0,400),(400,400,0),(0,400,400),(400,0,400),(0,0,0),(400,400,400))];marker=hlg['codes']((400,400,400),'hlg');planes=[array('H'),array('H'),array('H')]
 for y in range(180):
  for x in range(320):
   pixel=(gray if y<120 else colors)[x//40]
   if 156<=y<172 and 8+24*index<=x<24+24*index:pixel=marker
   planes[0].append(pixel[0])
   if x%2==0 and y%2==0:planes[1].append(pixel[1]);planes[2].append(pixel[2])
 return b''.join(p.tobytes() for p in planes)
for family in ['hdr10','hlg']:
 for parity in ['tff','bff']:
  raw=out/'input.yuv';raw.write_bytes(b''.join(pattern(family,i%12) for i in range(24)));target=out/(family+'-'+parity+'.mp4');transfer='smpte2084' if family=='hdr10' else 'arib-std-b67';params='interlaced=1:'+parity+'=1:colorprim=bt2020:transfer='+transfer+':colormatrix=bt2020nc:range=tv'
  if family=='hdr10':params+=':mastering-display=G(8500,39850)B(6550,2300)R(35400,14600)WP(15635,16450)L(10000000,1):cll=1000,400'
  argv=[str(pkg/'ffmpeg'),'-v','error','-threads','1','-filter_threads','1','-f','rawvideo','-pix_fmt','yuv420p10le','-s','320x180','-r','24','-i',str(raw),'-vf','tinterlace=mode=interleave_'+('top' if parity=='tff' else 'bottom')+',setfield='+parity+',setsar=1','-frames:v','12','-c:v','libx264','-profile:v','high10','-preset','ultrafast','-crf','12','-flags','+ilme+ildct','-x264-params',params,'-color_primaries','bt2020','-color_trc',transfer,'-colorspace','bt2020nc','-color_range','tv',str(target)];r=subprocess.run(argv,capture_output=True,timeout=30);(out/(family+'-'+parity+'.encode.log')).write_bytes(r.stderr)
  if r.returncode:raise RuntimeError(r.stderr.decode())
  probe=[str(pkg/'ffprobe'),'-v','error','-show_streams','-show_frames','-of','json',str(target)];doc=json.loads(subprocess.check_output(probe));assert len(doc['frames'])==12 and all(f['interlaced_frame']==1 and f['top_field_first']==(parity=='tff') and f['sample_aspect_ratio']=='1:1' for f in doc['frames']);records.append({'family':family,'parity':parity,'argv':argv,'probe_argv':probe,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'stream':doc['streams'][0],'frames':doc['frames']})
raw.unlink();(out/'manifest.json').write_text(json.dumps({'provenance':'Original CC0 analytical10bitwovenfields; two temporallydistinct images per frame','fixtures':records},indent=2)+'\n');print('Generated four genuine wovenHigh10 PQ/HLG TFF/BFF controls; actualdecodedflags/SAR verified.')
