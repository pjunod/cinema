#!/usr/bin/env python3
"""Reproduce bounded CPU-only coded-SAR and decoded-plane controls."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--package',type=Path,required=True);p.add_argument('--old-corpus',type=Path,required=True);p.add_argument('--corpus',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();a.output.mkdir(exist_ok=False)
records=[]
for name in ['p5.mp4','p5-frame-bound.mp4']:
 probe_argv=[str(a.package/'ffprobe'),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(a.corpus/name)]
 doc=json.loads(subprocess.check_output(probe_argv,timeout=20));assert doc['streams'][0]['sample_aspect_ratio']=='1:1';assert len(doc['frames'])==24 and all(f['sample_aspect_ratio']=='1:1' for f in doc['frames'])
 raws=[];argvs=[]
 for corpus in [a.old_corpus,a.corpus]:
  argv=[str(a.package/'ffmpeg'),'-xerror','-v','error','-threads','1','-hwaccel','none','-strict_dovi','1','-err_detect','explode','-i',str(corpus/name),'-map','0:v:0','-an','-pix_fmt','yuv420p10le','-f','rawvideo','pipe:1'];argvs.append(argv);raws.append(subprocess.check_output(argv,timeout=20))
 assert raws[0]==raws[1]
 records.append({'fixture':name,'new_source_sha256':hashlib.sha256((a.corpus/name).read_bytes()).hexdigest(),'old_source_sha256':hashlib.sha256((a.old_corpus/name).read_bytes()).hexdigest(),'decoded_raw_sha256':hashlib.sha256(raws[1]).hexdigest(),'decoded_bytes':len(raws[1]),'planes_equal':True,'argv':argvs,'probe_argv':probe_argv,'stream_sar':doc['streams'][0]['sample_aspect_ratio'],'decoded_frame_sars':[f['sample_aspect_ratio'] for f in doc['frames']]})
(a.output/'receipt.json').write_text(json.dumps({'ffmpeg_sha256':hashlib.sha256((a.package/'ffmpeg').read_bytes()).hexdigest(),'controls':records},indent=2)+'\n')
