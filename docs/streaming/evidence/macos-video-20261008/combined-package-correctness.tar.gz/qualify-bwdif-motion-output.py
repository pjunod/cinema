import pathlib,subprocess,json,hashlib
root=pathlib.Path('/experiment');package=root/'dolby-live-bwdif-correct-package';media=root/'remaining-dolby/crates/plurxd/fixtures/macos-processing';out=root/'dolby-bwdif-motion-output-correct-controls';out.mkdir(exist_ok=False);receipts=[]
for transport in ['live_upload','vt_decode']:
 for codec in ['h264','mpeg2'] if transport=='live_upload' else ['h264']:
  for parity in ['tff','bff']:
   source=media/('live_'+codec+'_'+parity+('.mp4' if codec=='h264' else '.ts'))
   for mode in ['frame','field']:
    field=mode=='field';count=24 if field else 12;rate=24 if field else 12
    target=out/(transport+'-'+codec+'-'+parity+'-'+mode+'.mp4')
    prefix=[str(package/'ffmpeg'),'-hide_banner','-loglevel','info','-nostdin','-threads','1']
    if transport=='live_upload':
     prefix+=['-init_hw_device','videotoolbox=vt','-filter_hw_device','vt','-hwaccel','none'];filt='format=nv12,hwupload,'
    else:
     prefix+=['-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld'];filt=''
    filt+='bwdif_videotoolbox=mode=send_'+mode+':parity=auto:deint=interlaced,scale_vt=w=160:h=90:format=nv12'
    argv=prefix+['-i',str(source),'-an','-sn','-dn','-vf',filt,'-c:v','h264_videotoolbox','-allow_sw','0','-b:v','500k','-bf','0','-a53cc','0','-frames:v',str(count),'-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv',str(target)]
    result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20);assert result.returncode==0,result.stderr[-4096:];(out/(target.stem+'.stderr')).write_bytes(result.stderr)
    doc=json.loads(subprocess.check_output([str(package/'ffprobe'),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(target)]));frames=doc['frames'];pts=[float(f['best_effort_timestamp_time']) for f in frames];assert len(frames)==count;assert all(abs(t-i/rate)<=2e-5 for i,t in enumerate(pts));assert all(f['interlaced_frame']==0 for f in frames)
    raw=subprocess.check_output([str(package/'ffmpeg'),'-v','error','-threads','1','-i',str(target),'-an','-pix_fmt','yuv420p','-f','rawvideo','pipe:1']);stride=21600;assert len(raw)==count*stride
    means=[]
    for i in range(count):
     j=(i if field else 2*i)%12
     if j not in [0,1,2,3,4,8,9,10]:continue
     x=8+12*j;mean=sum(raw[i*stride+y*160+xx] for y in range(81,84) for xx in range(x-1,x+2))/9
     assert mean>=210,(transport,codec,parity,mode,i,j,mean);means.append({'output_frame':i,'source_field_pattern':j,'marker_y_mean':mean})
    receipts.append({'transport':transport,'codec':codec,'parity':parity,'mode':mode,'argv':argv,'exit':0,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'raw_sha256':hashlib.sha256(raw).hexdigest(),'pts':pts,'frame_count':count,'motion_samples':means})
(out/'receipt.json').write_text(json.dumps({'ffmpeg_sha256':hashlib.sha256((package/'ffmpeg').read_bytes()).hexdigest(),'controls':receipts,'claim':'actual moving-field association after encoded native BWDIF/scale; VT surfaces do not assert physical decoder'},indent=2)+'\n');print('passed',len(receipts),'encoded moving-field controls')
