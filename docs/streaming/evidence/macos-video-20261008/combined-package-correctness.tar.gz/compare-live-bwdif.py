import pathlib,subprocess,json,hashlib
root=pathlib.Path('/experiment');package=root/'dolby-live-bwdif-correct-package';media=root/'remaining-dolby/crates/plurxd/fixtures/macos-processing';out=root/'dolby-live-motion-repaired-raw-controls';out.mkdir(exist_ok=False);receipts=[]
for codec,parity in [('h264','tff'),('h264','bff'),('mpeg2','tff'),('mpeg2','bff')]:
 source=media/('live_'+codec+'_'+parity+('.mp4' if codec=='h264' else '.ts'))
 for mode in ['frame','field']:
  frames=24 if mode=='field' else 12; raws={};argvs={}
  for route in ['cpu','vt']:
   prefix=[str(package/'ffmpeg'),'-hide_banner','-loglevel','info','-nostdin','-threads','1','-filter_threads','1']
   if route=='vt':prefix+=['-init_hw_device','videotoolbox=vt','-filter_hw_device','vt']
   filt='bwdif=mode=send_'+mode+':parity=auto:deint=interlaced,format=yuv420p' if route=='cpu' else 'format=nv12,hwupload,bwdif_videotoolbox=mode=send_'+mode+':parity=auto:deint=interlaced,hwdownload,format=nv12,format=yuv420p'
   argv=prefix+['-hwaccel','none','-i',str(source),'-an','-sn','-dn','-vf',filt,'-frames:v',str(frames),'-fps_mode','passthrough','-pix_fmt','yuv420p','-f','rawvideo','pipe:1']
   result=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=20);assert result.returncode==0,result.stderr[-4096:]
   stem=codec+'-'+parity+'-'+mode+'-'+route;(out/(stem+'.raw')).write_bytes(result.stdout);(out/(stem+'.stderr')).write_bytes(result.stderr);raws[route]=result.stdout;argvs[route]=argv
  stride=320*180*3//2;assert all(len(raw)==frames*stride for raw in raws.values())
  diffs=[abs(a-b) for a,b in zip(raws['cpu'],raws['vt'])]
  known_rows={}
  for route,raw in raws.items():
   samples=[]
   for i in range(frames):
    j=(i if mode=='field' else 2*i)%12;x=16+24*j
    samples.append({'frame':i,'expected_marker_x':x,'even_y164':raw[i*stride+164*320+x],'odd_y165':raw[i*stride+165*320+x]})
   known_rows[route]=samples
  rec={'codec':codec,'parity':parity,'mode':mode,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'argv':argvs,'raw_sha256':{k:hashlib.sha256(v).hexdigest() for k,v in raws.items()},'differing_samples':sum(d!=0 for d in diffs),'mean_abs_diff':sum(diffs)/len(diffs),'max_abs_diff':max(diffs),'marker_samples':known_rows};receipts.append(rec);print(codec,parity,mode,rec['mean_abs_diff'],rec['max_abs_diff'],known_rows['cpu'][:3],known_rows['vt'][:3],flush=True)
(out/'receipt.json').write_text(json.dumps({'controls':receipts},indent=2)+'\n')
