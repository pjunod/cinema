import json,subprocess,pathlib,hashlib
root=pathlib.Path('/experiment/routes-evidence')
pkg=pathlib.Path('/experiment/native-candidate/final-package')
source=pathlib.Path('/source/crates/plurxd/fixtures/macos-processing')
ff=str(pkg/'ffmpeg'); fp=str(pkg/'ffprobe'); receipts=[]
def call(label,argv):
 p=subprocess.run(argv,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=25)
 (root/(label+'.stderr')).write_bytes(p.stderr)
 receipts.append(dict(label=label,argv=argv,returncode=p.returncode,concurrent_build_load=True,bound_seconds=25))
 if p.returncode: raise RuntimeError(label+': '+p.stderr[-1500:].decode(errors='replace'))
 return p.stdout
for family in ['sdr8','sdr10','hdr10']:
 hdr=family=='hdr10'; inp=source/(family+'.mp4')
 source_doc=json.loads(call(family+'-source',[fp,'-v','error','-show_streams','-show_frames','-of','json',str(inp)]))
 for transport in ['software','videotoolbox']:
  label=family+'-hevc-host-'+transport; out=root/(label+'.mp4')
  argv=[ff,'-hide_banner','-loglevel','error','-nostdin','-y','-hwaccel','none' if transport=='software' else 'videotoolbox','-i',str(inp),'-map','0:v:0','-an','-sn','-dn','-vf','scale=160:90,format='+('yuv420p10le' if hdr else 'yuv420p'),'-c:v','hevc_videotoolbox','-profile:v','main10' if hdr else 'main','-allow_sw','0','-tag:v','hvc1','-b:v','500k','-bf','0','-frames:v','12','-color_primaries','bt2020' if hdr else 'bt709','-color_trc','smpte2084' if hdr else 'bt709','-colorspace','bt2020nc' if hdr else 'bt709','-color_range','tv','-f','mp4','-movflags','frag_keyframe+empty_moov+default_base_moof',str(out)]
  call(label,argv)
  raw=call(label+'-probe',[fp,'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(out)])
  (root/(label+'.json')).write_bytes(raw); doc=json.loads(raw); st=doc['streams'][0]; frames=doc['frames']
  assert st['codec_name']=='hevc' and st['codec_tag_string']=='hvc1' and st['profile']==('Main 10' if hdr else 'Main') and st['pix_fmt']==('yuv420p10le' if hdr else 'yuv420p')
  assert len(frames)==12 and st['avg_frame_rate']=='12/1'
  for i,frame in enumerate(frames):
   assert abs(float(frame['best_effort_timestamp_time'])-i/12)<1e-5
   assert frame['color_transfer']==('smpte2084' if hdr else 'bt709')
  if hdr:
   sides=[v for v in source_doc['frames'][0]['side_data_list'] if v['side_data_type'] in ('Mastering display metadata','Content light level metadata')]
   assert len(sides)==2
   for frame in [st]+frames: assert all(v in frame['side_data_list'] for v in sides)
  pixels=call(label+'-pixels',[ff,'-v','error','-nostdin','-threads','1','-i',str(out),'-an','-frames:v','12','-fps_mode','passthrough','-pix_fmt','yuv420p','-f','rawvideo','pipe:1'])
  (root/(label+'.yuv')).write_bytes(pixels)
  assert len(pixels)==160*90*3//2*12
  receipts[-3]['assertions']='Main/Main10 hvc1; all 12 PTS and per-frame transfer; HDR10 static metadata equal source; decoded pixel length'
(root/'hevc-host-receipts.json').write_text(json.dumps(dict(program_sha256={name:hashlib.sha256((pkg/name).read_bytes()).hexdigest() for name in ['ffmpeg','ffprobe']},receipts=receipts),indent=2))
print('PASS: six host-memory HEVC graphs; timing diagnostics excluded')
