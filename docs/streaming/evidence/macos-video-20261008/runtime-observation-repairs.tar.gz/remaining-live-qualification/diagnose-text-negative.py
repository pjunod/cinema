import subprocess,json,hashlib
from pathlib import Path
root=Path('/experiment');pkg=root/'dolby-live-bwdif-correct-package';fixtures=root/'remaining-dolby/crates/plurxd/fixtures/macos-processing';out=root/'dolby-text-negative-diagnostic';out.mkdir(exist_ok=False);records=[]
for name in ['missing','stale']:
 source=fixtures/'sdr10.mp4';filter='scale_vt=w=160:h=90:format=nv12'
 if name=='hlg':filter='scale_vt=w=160:h=90:format=p010le,tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0'
 else:
  filter+=',hwdownload,format=nv12'
  if name=='stale':filter+=",subtitles='"+str(root/'remaining-live-qualification/stale.ass')+"'"
 target=out/(name+'.mp4');argv=[str(pkg/'ffmpeg'),'-hide_banner','-loglevel','error','-nostdin','-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld','-i',str(source),'-an','-sn','-dn','-map','0:v:0','-vf',filter,'-c:v','h264_videotoolbox','-b:v','500k','-maxrate','1000k','-bufsize','2000k','-allow_sw','0','-bf','0','-frames:v','12','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv','-f','mp4','-movflags','frag_keyframe+empty_moov+default_base_moof',str(target)]
 r=subprocess.run(argv,capture_output=True,timeout=20);(out/(name+'.log')).write_bytes(r.stderr)
 if r.returncode:records.append({'name':name,'argv':argv,'exit':r.returncode});continue
 probe=[str(pkg/'ffprobe'),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(target)];doc=json.loads(subprocess.check_output(probe));(out/(name+'.json')).write_text(json.dumps(doc,indent=2))
 decode=[str(pkg/'ffmpeg'),'-v','error','-i',str(target),'-pix_fmt','yuv420p','-f','rawvideo','pipe:1'];raw=subprocess.check_output(decode);(out/(name+'.yuv')).write_bytes(raw);stride=21600
 records.append({'name':name,'argv':argv,'exit':r.returncode,'probe_argv':probe,'decode_argv':decode,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'stream':doc['streams'][0],'frames':len(doc['frames']),'reference_white':[raw[i*stride+30*160+90] for i in range(12)],'burn_roi_peaks':[max(raw[i*stride+y*160+x] for y in range(70,88) for x in range(60,100)) for i in range(12)]})
(out/'receipt.json').write_text(json.dumps({'observations':records},indent=2)+'\n');print(json.dumps([{k:r.get(k) for k in ['name','exit','frames','reference_white','burn_roi_peaks']} for r in records]))
