import subprocess,pathlib,json,os
R=pathlib.Path('/experiment/routes-evidence'); S=pathlib.Path('/source/crates/plurxd/fixtures/macos-processing');P=pathlib.Path('/experiment/native-candidate/final-package');ff=str(P/'ffmpeg');fp=str(P/'ffprobe')
receipts=[]
def call(name,args,pass_fds=()):
 p=subprocess.run(args,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,pass_fds=pass_fds)
 (R/(name+'.stderr')).write_bytes(p.stderr);receipts.append({'name':name,'argv':args,'returncode':p.returncode,'concurrent_build_load':True})
 if p.returncode: print(name,p.returncode,p.stderr.decode()[-1000:]);return None
 return p.stdout
graphs=[]
for family in ['sdr','sdr10','hdr10']:
 g='scale_vt=w=160:h=90:format='+('p010le' if family=='hdr10' else 'nv12')
 if family=='hdr10':g+=',tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0'
 graphs.append((family+'-pgs',S/('pgs-'+family+'.mkv'),f'[0:v]{g},hwdownload,format=nv12[vburn];[0:s:0]scale=160:90[sburn];[vburn][sburn]overlay=eof_action=pass[o]',True,12))
for parity in []:
 for mode in ['frame','field']:
  graphs.append((parity+'-'+mode+'-vui',S/('interlaced-'+parity+'.mp4'),f'bwdif_videotoolbox=mode=send_{mode}:parity=auto:deint=interlaced,scale_vt=w=160:h=90:format=nv12',False,24 if mode=='field' else 12))
#graphs.append(('hlg-metal',S/'hlg.mp4','scale_vt=w=160:h=90:format=p010le,tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0',False,12))
for name,source,graph,bitmap,frames in graphs:
 out=R/(name+'.mp4');args=[ff,'-hide_banner','-v','error','-nostdin','-y','-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld','-i',str(source),'-an','-sn','-dn']
 args+=['-filter_complex',graph,'-map','[o]'] if bitmap else ['-vf',graph,'-map','0:v']
 args+=['-c:v','h264_videotoolbox','-allow_sw','0','-b:v','500k','-bf','0','-frames:v',str(frames),'-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv',str(out)]
 if call(name,args) is None:continue
 d=call(name+'-probe',[fp,'-v','error','-show_streams','-show_frames','-of','json',str(out)]);(R/(name+'.json')).write_bytes(d)
 y=call(name+'-raw',[ff,'-v','error','-i',str(out),'-an','-pix_fmt','yuv420p','-f','rawvideo','pipe:1']);(R/(name+'.yuv')).write_bytes(y)
 s=json.loads(d)['streams'][0];print(name,{k:s.get(k) for k in ['profile','avg_frame_rate','color_primaries','color_transfer','color_space','color_range','field_order']},'frames',len(json.loads(d)['frames']))
 if bitmap:
  stride=160*90*3//2;Y=160*90
  print('cue YUV',[[y[i*stride+75*160+130],y[i*stride+Y+37*80+65],y[i*stride+Y+Y//4+37*80+65]] for i in range(frames)])
 if name=='hlg-metal':print('HLG gray output codes',[y[30*160+10+i*20] for i in range(8)])
# Exact held ASS/source descriptor transport, one dup-all-before-dup2 subprocess owner as runtime.
source=open(S/'sdr8.mp4','rb');ass=open(S/'burn.ass','rb');name='ass-held-fds';out=R/(name+'.mp4')
a=[ff,'-v','error','-nostdin','-y','-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld','-i',f'/dev/fd/{source.fileno()}','-vf',f"scale_vt=w=160:h=90:format=nv12,hwdownload,format=nv12,subtitles='/dev/fd/{ass.fileno()}'",'-an','-frames:v','12','-c:v','h264_videotoolbox','-allow_sw','0','-bf','0',str(out)]
call(name,a,(source.fileno(),ass.fileno()));source.close();ass.close()
(R/'extensions-receipts.json').write_text(json.dumps(receipts,indent=2))
