import struct,pathlib,subprocess
p=pathlib.Path('/experiment/routes-evidence')
def seg(t,typ,b): return b'PG'+struct.pack('>IIBH',int(t*90000),0,typ,len(b))+b
# Original synthetic 40x15 red half-alpha cue at bottom right.
pc=struct.pack('>HHBHBBBB',320,180,0x10,1,0x80,0,0,1)+struct.pack('>HBBHH',1,0,0,220,140)
w=bytes([1,0])+struct.pack('>HHHH',220,140,80,30)
pal=bytes([0,0,1,81,240,90,128])
rle=(bytes([1])*80+b'\0\0')*30
o=struct.pack('>HBB',1,0,0xc0)+(len(rle)+4).to_bytes(3,'big')+struct.pack('>HH',80,30)+rle
clear=struct.pack('>HHBHBBBB',320,180,0x10,2,0,0,0,0)
b=b''.join([seg(.25,0x16,pc),seg(.25,0x17,w),seg(.25,0x14,pal),seg(.25,0x15,o),seg(.25,0x80,b''),seg(.75,0x16,clear),seg(.75,0x80,b'')])
(p/'cue.sup').write_bytes(b)
ff='/experiment/native-candidate/final-package/ffmpeg'
src='/source/crates/plurxd/fixtures/macos-processing/sdr8.mp4'
a=[ff,'-v','error','-y','-i',src,'-i',str(p/'cue.sup'),'-map','0:v','-map','1:s','-c','copy',str(p/'pgs-sdr.mkv')]
r=subprocess.run(a,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10);print(r.returncode,r.stderr.decode())
