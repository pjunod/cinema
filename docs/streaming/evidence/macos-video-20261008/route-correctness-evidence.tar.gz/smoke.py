import json,subprocess,pathlib,zlib,struct,time
ROOT=pathlib.Path('/experiment/routes-evidence')
PKG=pathlib.Path('/experiment/native-candidate/final-package')
SOURCE=pathlib.Path('/source/crates/plurxd/fixtures/macos-processing')
ff=str(PKG/'ffmpeg');fp=str(PKG/'ffprobe')
receipts=[]
def call(label,args):
    started=time.time(); p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30)
    (ROOT/(label+'.stderr')).write_bytes(p.stderr)
    r={'label':label,'argv':args,'returncode':p.returncode,'wall_seconds_diagnostic_only':time.time()-started,'concurrent_build_load':True}
    receipts.append(r)
    if p.returncode: return None
    return p.stdout
def chunk(t,b): return struct.pack('>I',len(b))+t+b+struct.pack('>I',zlib.crc32(t+b)&0xffffffff)
pix=b''.join(b'\0'+b''.join(bytes((255,0,0,128)) if 110<=x<150 and 70<=y<85 else bytes((0,0,0,0)) for x in range(160)) for y in range(90))
(ROOT/'overlay.png').write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',160,90,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(pix))+chunk(b'IEND',b''))
(ROOT/'burn.ass').write_text('''[Script Info]\nScriptType: v4.00+\nPlayResX: 160\nPlayResY: 90\n[V4+ Styles]\nFormat: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding\nStyle: Default,Arial,14,&H00FFFFFF,&H000000FF,&H00000000,&H00000000,0,0,0,0,100,100,0,0,1,1,0,2,0,0,2,1\n[Events]\nFormat: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text\nDialogue: 0,0:00:00.25,0:00:00.75,Default,,0,0,0,,{\\an2\\pos(80,86)\\fad(100,100)}burn\n''')
base=['-hide_banner','-loglevel','error','-nostdin','-y']
enc=['-c:v','h264_videotoolbox','-allow_sw','0','-b:v','500k','-bf','0','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv']
def observe(label,out):
    data=call(label+'-probe',[fp,'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(out)])
    if data: (ROOT/(label+'.json')).write_bytes(data)
    data=call(label+'-pixels',[ff,'-v','error','-i',str(out),'-an','-pix_fmt','yuv420p','-f','rawvideo','pipe:1'])
    if data: (ROOT/(label+'.yuv')).write_bytes(data)
for hdr in [False,True]:
    inp=SOURCE/('hdr10.mp4' if hdr else 'sdr8.mp4')
    graph='scale_vt=w=160:h=90:format='+('p010le' if hdr else 'nv12')
    if hdr: graph+=',tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0'
    for mode in ['plain','text','bitmap','hevc']:
        label=('hdr10' if hdr else 'sdr')+'-'+mode;out=ROOT/(label+'.mp4')
        args=[ff]+base+['-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld','-i',str(inp)]
        if mode=='bitmap':
            args+=['-loop','1','-i',str(ROOT/'overlay.png'),'-filter_complex',f'[0:v]{graph},hwdownload,format=nv12[v];[v][1:v]overlay=eof_action=pass:format=yuv420:shortest=1[o]','-map','[o]']
        elif mode=='text': args+=['-vf',graph+",hwdownload,format=nv12,subtitles='"+str(ROOT/'burn.ass')+"'"]
        elif mode=='hevc': args+=['-vf','scale_vt=w=160:h=90:format='+('p010le' if hdr else 'nv12')]
        else: args+=['-vf',graph]
        args+=['-an','-frames:v','12']
        if mode=='hevc': args+=['-c:v','hevc_videotoolbox','-allow_sw','0','-profile:v','main10' if hdr else 'main','-b:v','500k','-bf','0','-tag:v','hvc1']
        else: args+=enc
        args+=[str(out)]
        if call(label,args) is not None: observe(label,out)
for parity in ['tff','bff']:
    inp=ROOT/(parity+'.mp4')
    call('generate-'+parity,[ff]+base+['-f','lavfi','-i','testsrc2=size=320x180:rate=24:duration=1','-vf','tinterlace=mode=interleave_'+('top' if parity=='tff' else 'bottom')+',setfield='+parity,'-c:v','libx264','-preset','ultrafast','-flags','+ilme+ildct','-x264-params','interlaced=1:'+parity+'=1','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv',str(inp)])
    for mode in ['send_frame','send_field']:
        label=parity+'-'+mode;out=ROOT/(label+'.mp4')
        graph='bwdif_videotoolbox=mode='+mode+':parity=auto:deint=interlaced,scale_vt=w=160:h=90:format=nv12'
        if call(label,[ff]+base+['-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld','-i',str(inp),'-vf',graph,'-an']+enc+[str(out)]) is not None: observe(label,out)
(ROOT/'receipts.json').write_text(json.dumps(receipts,indent=2))
print(json.dumps([(r['label'],r['returncode']) for r in receipts]))
