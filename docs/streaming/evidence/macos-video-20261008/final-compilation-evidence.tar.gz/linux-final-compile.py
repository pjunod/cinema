import hashlib,json,os,pathlib,subprocess,time
repo=pathlib.Path('/source')
work=pathlib.Path('/experiment')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
if subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip():
 raise SystemExit('Refuse compile receipt for dirty integration source')
archive=work/'linux-final-source.tar'
subprocess.run(['git','archive','--format=tar','-o',str(archive),head],cwd=repo,check=True)
lima='/opt/homebrew/bin/limactl';vm='plurx-ci-arm';remote='/compiler-work'
source_dir='source-macos-completion-'+head[:12]
subprocess.run([lima,'copy',str(archive),vm+':'+remote+'/completion-source.tar'],check=True)
subprocess.run([lima,'shell',vm,'--','mkdir','-p',remote+'/'+source_dir],check=True)
subprocess.run([lima,'shell',vm,'--','tar','-xf',remote+'/completion-source.tar','-C',remote+'/'+source_dir],check=True)
base=[lima,'shell',vm,'--','/usr/bin/docker','run','--rm','--memory=12g','--cpus=2',
 '-v',remote+':/work', '-v','/compiler-user/.rustup/toolchains/1.97.1-aarch64-unknown-linux-gnu:/rust:ro',
 '-w','/work/'+source_dir,'-e','PATH=/rust/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
 '-e','CARGO_HOME=/work/cargo','-e','CARGO_TARGET_DIR=/work/target-fp16','-e','RUSTFLAGS=-C target-feature=+fullfp16',
 'codex-batch001-font-tooling:owned']
version=subprocess.check_output(base+['/rust/bin/rustc','--version'],text=True).strip()
assert version.startswith('rustc 1.97.1 '),version
receipt={'head':head,'source_archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'rustc':version,'tests_executed':False,'checks':[]}
for name,args in [('check',['cargo','check','--locked','--offline','--workspace','--all-targets','--features','plurx-core/hiqlite-store','-j1']),('clippy',['cargo','clippy','--locked','--offline','--workspace','--all-targets','--features','plurx-core/hiqlite-store','-j1','--','-D','warnings'])]:
 began=time.monotonic();log=work/('linux-final-'+name+'.log')
 with log.open('w') as out:r=subprocess.run(base+args,stdout=out,stderr=subprocess.STDOUT)
 receipt['checks'].append({'name':name,'argv':args,'exit_code':r.returncode,'seconds':time.monotonic()-began,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
 (work/'linux-final-compile-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
