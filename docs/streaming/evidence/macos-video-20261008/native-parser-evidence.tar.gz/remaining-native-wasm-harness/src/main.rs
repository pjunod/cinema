#[path="/experiment/remaining-native/crates/plurxd/src/decode_facts/macos_wasm.rs"]
mod parser;
fn main() {
 let mut args=std::env::args().skip(1);
 let module=args.next().unwrap();
 let source=args.next().unwrap();
 let began=std::time::Instant::now();
 let parser=parser::Parser::new(&std::fs::read(module).unwrap()).unwrap();
 eprintln!("compile_seconds={:.6}",began.elapsed().as_secs_f64());
 let source=if source=="-" {None} else {Some(std::sync::Arc::new(std::fs::File::open(source).unwrap()))};
 let began=std::time::Instant::now();
 let output=parser.run(source,args.collect(),(16*1024*1024,512*1024),std::time::Instant::now()+std::time::Duration::from_secs(20),std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false))).unwrap();
 eprintln!("parse_seconds={:.6}",began.elapsed().as_secs_f64());
 print!("{}",String::from_utf8_lossy(&output.stdout));
 eprint!("{}",String::from_utf8_lossy(&output.stderr));
 std::process::exit(output.status);
}
