#!/usr/bin/env python3
"""Bounded normal-API cache qualification of a task-owned packaged daemon."""
import argparse,hashlib,json,os,secrets,signal,socket,subprocess,time,urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--bundle',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--source-head',required=True);p.add_argument('--cache-volume',type=Path);p.add_argument('--capacity-only',action='store_true');a=p.parse_args()
if not a.output.is_absolute() or a.output.exists():raise ValueError('new private absolute output required')
a.output.mkdir(mode=0o700);root=a.output;bundle=a.bundle.resolve();binary=bundle/'bin/plurxd';ports=[]
for _ in range(3):
 with socket.socket() as s:s.bind(('127.0.0.1',0));ports.append(s.getsockname()[1])
if len(set(ports))!=3:raise ValueError('port collision')
name='Owned cache qualification '+secrets.token_hex(8);config=root/'plurx.toml'
cache=a.cache_volume.resolve()/'cache' if a.cache_volume else root/'cache'
if a.cache_volume:
 if not str(a.cache_volume.resolve()).startswith('/experiment/') or a.cache_volume.stat().st_dev==root.stat().st_dev:raise ValueError('ENOSPC needs a separate mounted task-owned disposable volume')
 if os.statvfs(a.cache_volume).f_blocks*os.statvfs(a.cache_volume).f_frsize>80*1024*1024:raise ValueError('disposable cache volume exceeds bounded allowance')
config.write_text(f'[server]\nname="{name}"\nbind="127.0.0.1:{ports[0]}"\njellyfin_port=0\n[storage]\ndata_dir="{root}/data"\ncache_dir="{cache}"\ntranscode_dir="{root}/scratch"\n[cluster]\nraft_bind="127.0.0.1:{ports[1]}"\napi_bind="127.0.0.1:{ports[2]}"\n');config.chmod(0o600)
env={k:os.environ[k] for k in ['PATH','HOME','TMPDIR'] if k in os.environ};env.update(PLURX_HWACCEL='videotoolbox',PLURX_MDNS_ADVERTISE='0',PLURX_LOG='info')
base=f'http://127.0.0.1:{ports[0]}/api/v1';token=None;child=None;log=None;restricted=None
receipt={'kind':'actual_isolated_cache_failure_recovery','source_head':a.source_head,'daemon_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'driver_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'observations':[],'limitations':['Task-owned installation, no production deployment','No network isolation claim: embedded corpus needs no external downloads','Read-only and corrupt-cache controls are not ENOSPC proof']}
(root/'driver-executed.py').write_bytes(Path(__file__).read_bytes())
def record(value):
 receipt['observations'].append(value);(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
def api(path,method='GET',body=None,auth=True):
 headers={'Content-Type':'application/json'}
 if token and auth:headers['Authorization']='Bearer '+token
 req=urllib.request.Request(base+path,data=None if body is None else json.dumps(body).encode(),headers=headers,method=method)
 with urllib.request.urlopen(req,timeout=15) as r:return r.status,json.load(r)
def stop():
 global child,log
 if child and child.poll() is None:
  os.killpg(child.pid,signal.SIGINT)
  try:child.wait(timeout=25)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
 if log:log.close()
 child=None;log=None
def launch(label):
 global child,log
 log=(root/(label+'.log')).open('wb');child=subprocess.Popen([str(binary),'--config',str(config),'run'],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 deadline=time.monotonic()+50
 while True:
  if child.poll() is not None:raise RuntimeError('owned daemon exited')
  try:
   value=api('/server',auth=False)[1]
   if value.get('name')!=name:raise RuntimeError('server identity mismatch')
   return value
  except OSError:
   if time.monotonic()>deadline:raise
   time.sleep(.25)
def report_after(generation=-1):
 deadline=time.monotonic()+260
 while True:
  s=api('/settings')[1];report=s['macos_video_processing'];graphs=[report.get('sdr_scale',{}),report.get('hdr10_metal',{})]+list(report.get('graphs',{}).values())
  complete = len(graphs)==22 and all(g.get('availability')!='pending' for g in graphs)
  preparation_refusal = not report.get('graphs') and report.get('implementation') is None and all(g.get('availability')=='unavailable' and g.get('reason')=='fixture_cache_unavailable' for g in graphs)
  if report.get('generation',-1)>generation and (complete or preparation_refusal):return report
  if time.monotonic()>deadline:record({'timeout_report':report});raise RuntimeError('bounded graph inventory deadline')
  time.sleep(.5)
def reprobe(old):
 code,value=api('/developer/macos-video-processing/reprobe','POST',{})
 if code!=202 or not value['accepted']:raise RuntimeError('normal reprobe refused')
 return report_after(old['generation'])
def assert_available(report):
 graphs={'sdr_scale':report['sdr_scale'],'hdr10_metal':report['hdr10_metal'],**report['graphs']}
 failures={k:v for k,v in graphs.items() if v['availability']!='available'}
 if len(graphs)!=22 or failures:record({'unavailable':failures});raise RuntimeError('complete independently observed graph inventory unavailable')
try:
 if not launch('first').get('setup_required'):raise RuntimeError('fresh private data was not fresh')
 token=api('/setup','POST',{'username':'cache-qualification','password':secrets.token_urlsafe(30)},False)[1]['token']
 api('/settings','PUT',{'macos_video_processing_enabled':True})
 initial=report_after();assert_available(initial);record({'empty_cache_rebuilt':True,'report':initial})
 fixture=next(x for x in cache.rglob('*.mp4') if 'macos-processing' in x.parts and len(x.stem)==64)
 original=fixture.read_bytes()
 if not a.capacity_only:
  fixture.write_bytes(b'owned corrupt cache control')
  repaired=reprobe(initial);assert_available(repaired)
  if fixture.read_bytes()!=original:raise RuntimeError('corrupt cache was not repaired exactly')
  record({'corrupt_cache_repaired':True,'fixture_sha256':hashlib.sha256(original).hexdigest(),'report':repaired})
  fixture.write_bytes(b'owned unwritable cache control');restricted=fixture.parent;restricted.chmod(0o500)
  refused=reprobe(repaired)
  if refused['sdr_scale']['availability']!='unavailable' or refused['sdr_scale'].get('reason')!='fixture_cache_unavailable':record({'unexpected_readonly_report':refused});raise RuntimeError('read-only cache did not report bounded explicit refusal')
  if api('/settings')[1]['macos_video_processing_enabled'] is not True:raise RuntimeError('cache refusal overrode saved choice')
  record({'read_only_cache_refusal':True,'saved_choice_preserved':True,'report':refused})
  restricted.chmod(0o700);restricted=None;restored=reprobe(refused);assert_available(restored)
  if fixture.read_bytes()!=original:raise RuntimeError('restored cache not repaired')
  record({'operator_permission_repair_recovers':True,'report':restored})
 else:restored=initial
 if a.cache_volume:
  import errno
  filler=a.cache_volume/'owned-capacity-control';filled=0;observed_errno=None
  fixture.unlink()
  try:
   with filler.open('wb',buffering=0) as f:
    for block_size in [1024*1024,4096,1]:
     while filled<=80*1024*1024:
      try:filled+=f.write(b'\0'*block_size)
      except OSError as e:
       if e.errno!=errno.ENOSPC:raise
       observed_errno=e.errno;break
    remaining=os.statvfs(a.cache_volume).f_bavail*os.statvfs(a.cache_volume).f_frsize
    record({'capacity_control_filler_bytes':filled,'available_bytes_before_reprobe':remaining,'smallest_failed_write_bytes':1})
   if observed_errno!=errno.ENOSPC:raise RuntimeError('bounded cache volume did not reach ENOSPC')
   full=reprobe(restored)
   if full['sdr_scale']['availability']!='unavailable' or full['sdr_scale'].get('reason')!='fixture_cache_unavailable':record({'unexpected_full_report':full});raise RuntimeError('full cache did not refuse explicitly')
   if api('/settings')[1]['macos_video_processing_enabled'] is not True:raise RuntimeError('full cache overrode saved choice')
   record({'owned_volume_enospc':True,'filler_bytes':filled,'errno':observed_errno,'saved_choice_preserved':True,'report':full})
  finally:filler.unlink(missing_ok=True)
  recovered=reprobe(full);assert_available(recovered)
  if fixture.read_bytes()!=original:raise RuntimeError('ENOSPC recovery did not restore exact fixture')
  record({'cache_space_restored_recovers':True,'report':recovered})
 stop();launch('restart');restarted=report_after();assert_available(restarted)
 if api('/settings')[1]['macos_video_processing_enabled'] is not True:raise RuntimeError('restart lost saved choice')
 record({'restart_saved_choice_and_inventory':True,'report':restarted});receipt['result']='passed'
except Exception as error:receipt['result']='failed';receipt['error']=str(error);raise
finally:
 if restricted:restricted.chmod(0o700)
 stop();(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'result':receipt.get('result'),'receipt':str(root/'receipt.json')}))
