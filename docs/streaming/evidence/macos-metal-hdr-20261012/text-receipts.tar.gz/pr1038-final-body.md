Progressive HEVC HDR10 files can omit FFprobe `field_order`, keeping forced SDR playback on CPU even after Metal passed its probe. Real playback through the repaired route then exposed a second defect: a 1,179-nit source received Metal's 117.9-nit curve because the explicit peak option used the CPU filter's units.

Collect only the selected video stream's configuration through the existing bound parser and held source descriptor. Require explicit progressive, non-interlaced, frame-only flags in hvcC and every included VPS/SPS before refining Unknown. Preserve explicit scan orders and conservative CPU fallback, bind the refinement into facts identity, and protect it from fresh source documents without binary evidence. Candidate selection now uses the same bound refinement before advertising encoded recipes; it publishes valid remux rows first and skips refinement when restoring a remux. A collection failure offers no unstable encoded recipe, while successfully collected missing or contradictory constraints retain the CPU route. This adds one bounded refinement on the first lookup for a source with missing HEVC scan metadata; successful facts are cached.

Translate absolute peak nits into Metal's tens-of-nits option, retain CUDA/OpenCL's hundreds-of-nits options, and bind the corrected Metal PQ option into rendition identity so the old bright/clipped output cannot be reused. HLG and other renderer keys retain their behavior. The boot fixture now uses a non-round 1,179-nit peak; its broad mean-channel threshold still accepts both old and corrected graphs, so this fixture is smoke evidence, not the regression proof. The authored neutral-PQ and real-source diagnostics expose the defect; absolute-unit and pre-fix-key regressions prevent recurrence.

Validation uses pinned Rust 1.97.1:

- Installed candidate `94dee81da` builds and installs through the standard Mac installer, retaining the LaunchAgent unchanged. Its explicit VideoToolbox Metal probe passes at 2.25× and records Vulkan unavailable.
- Physical Air Chrome plays American Gangster HDR10 to 1920×1080 SDR. Metal starts in 2.363 seconds and plays five minutes with zero interruptions and zero dropped frames out of 7,810; switch-off CPU starts in 4.027 seconds. Both paused 300,000 ms captures have independent presented-frame receipts (39 ms Metal; 36 ms CPU). The running producer proves Hable/max/desat 0/peak 117.9. Excess brightness/clipping from the old units is gone; corrected Metal remains slightly darker than CPU. Raw-source luma MAE improves 13.75→5.15, p95 23→9. Pixel equality and calibrated fidelity are not claimed.
- Main `607d3577c` is integrated. The sole conflict is additive ownership census: main's 1,735 plus two test-only bounds gives 1,737. Integrated source `5010b0516` passes 25 ownership/documentation checks, 101 decoder-selection, 21 pipeline, 29 HEVC daemon and 62 probe tests (one probe ignored). The probe tests use the installed full FFmpeg. Source-only Linux workspace check (8m 20s) and Clippy (5m 44s) pass.
- Final candidate `33d57cdf9` changes only two documents after that integration. Its Mac workspace check (2m 58s), Clippy (39.80s) and normal format/catalog/JavaScript hook pass. Exact-head Main promotion run 4863 / API 4889 passes; its complete Python receipt records 1,376 passes with no fixture or preflight errors. Landed as `0da656d3a3e7d7f0c52387543571d2ff4a265340` with all six regression anchors below.
- User-requested independent Astra review has no remaining blockers. Earlier catalog findings and the ownership census discrepancy are addressed.

Temporary settings are restored: preferred backend Auto applied by service restart, Mac processing on, quality Auto, resume position zero and Chrome profile Default after relaunch. The test player is closed. The laptop's warmed forced-SDR Heretic session starts.

Retained limits: VOD INFO logs omit argv, so the actual producer command supplies graph proof; cached playback metadata omits renderer/frame rows. Earlier unbuffered paused seeks stalled, a replicated-store self-fence recovered after a 503, and a quality switch lost alignment. An abandoned own preparation held VOD capacity and caused two 500 refusals; stopping only that session resolved it before the successful continuous Metal run. Broader playback reliability and the laptop's cold-start reliability remain unqualified. Main deliberately removed Windows compile gates in `ee668d0b4`; no Windows pass is claimed.

Focused commands:

```sh
cargo +1.97.1 test -p plurx-core --test decoder_selection --features hiqlite-store --locked
cargo +1.97.1 test -p plurx-core --lib transcode::pipeline --features hiqlite-store --locked
cargo +1.97.1 test -p plurxd --bin plurxd hevc --locked
```

Regression-Test: crates/plurx-core/tests/decoder_selection.rs::hevc_scan_evidence_unlocks_metal_without_defaulting_missing_field_order
Regression-Test: crates/plurxd/src/decode_facts.rs::unknown_hevc_scan_is_refined_once_without_fresh_document_cache_downgrade
Regression-Test: crates/plurxd/src/transcode/manager/candidates.rs::hevc_catalog_and_prepared_source_share_refined_scan_recipe
Regression-Test: crates/plurx-core/src/transcode/pipeline.rs::metal_explicit_peak_preserves_absolute_nits_across_the_fallback_boundary
Regression-Test: crates/plurx-core/tests/decoder_selection.rs::the_metal_pq_plan_is_keyed_by_the_curve_it_runs
Regression-Test: crates/plurxd/src/pipeprobe.rs::the_reference_command_is_the_production_cpu_chain
