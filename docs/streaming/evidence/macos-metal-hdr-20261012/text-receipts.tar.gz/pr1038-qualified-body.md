Progressive HEVC HDR10 files can omit FFprobe `field_order`, keeping forced SDR playback on CPU even after Metal passed its probe. Real playback through the repaired route then exposed a second defect: a 1,179-nit source received Metal's 117.9-nit curve because the explicit peak option used the CPU filter's units.

Collect only the selected video stream's configuration through the existing bound parser and held source descriptor. Require explicit progressive, non-interlaced, frame-only flags in hvcC and every included VPS/SPS before refining Unknown. Preserve explicit scan orders and conservative CPU fallback, bind the refinement into facts identity, and protect it from fresh source documents without binary evidence. Candidate selection now uses the same bound refinement before advertising encoded recipes; it publishes valid remux rows first and skips refinement when restoring a remux. A collection failure offers no unstable encoded recipe, while successfully collected missing or contradictory constraints retain the CPU route. This adds one bounded refinement on the first lookup for a source with missing HEVC scan metadata; successful facts are cached.

Translate absolute peak nits into Metal's tens-of-nits option, retain CUDA/OpenCL's hundreds-of-nits options, and bind the corrected Metal PQ option into rendition identity so the old bright/clipped output cannot be reused. HLG and other renderer keys retain their behavior. The boot fixture now uses a non-round 1,179-nit peak; its broad mean-channel threshold still accepts both old and corrected graphs, so this fixture is smoke evidence, not the regression proof. The authored neutral-PQ and real-source diagnostics expose the defect; absolute-unit and pre-fix-key regressions prevent recurrence.

Hardware acceptance on `94dee81da` and integrated-source validation with pinned Rust 1.97.1:

- Standard Mac installer deploys the corrected release to the Air, retains the launch-agent file unchanged and binds the packaged parser. Fresh explicit-VideoToolbox Metal probe passes at 2.25×; Vulkan is explicitly unavailable.
- Physical Air Chrome plays American Gangster (HDR10, 1,179-nit peak) to 1920×1080 SDR. Metal first frame is 2.363s, followed by five uninterrupted minutes with 0/7,810 dropped frames. CPU starts in 4.027s. Paused 300,000ms frames have independent presented-frame receipts: 39ms Metal and 36ms CPU. Actual Metal producer argv has Hable/max/desat0/peak117.9; VOD INFO logs omit argv. Cached playback metadata omits renderer/frame rows, so the actual producer and browser intrinsic dimensions provide the routing/raster proof.
- The preceding build's excess brightness and clipping are gone. Corrected Metal is slightly darker than CPU; pixel equality/display calibration are not claimed. Raw-source luma MAE falls13.75→5.15 and p9523→9. The broad synthetic boot threshold accepts old and corrected options, so absolute-unit and old-key regressions are the enforcement evidence.
- Temporary preferred backend restored to Auto and applied by service restart; Mac processing restored on, Chrome profile Default, playback quality Auto, resume0, test player closed. The laptop's warmed forced-SDR Heretic session starts; cold-start reliability remains unqualified.
- Earlier unbuffered paused seeks stalled, one self-fence caused a recovered503, a quality switch lost alignment, and two startup500capacity refusals followed an abandoned preparation. Stopping only this test's abandoned session resolved capacity; the continuous corrected Metal comparison then passed. These playback limitations are retained.
- Candidate94 passes all-target Mac workspace Clippy, normal hook, 101 decoder-selection,21pipeline,46probe regressions with full FFmpeg, release build, exact-source Linux workspace check/Clippy, and Main promotion gate (logical4860/actual4886, Python receipt1,376passes). User-requested Astra review has no remaining blockers.
- Currentmain607d3577c merged for integration; sole conflict is additive ownershipcensus (main1735 plus2test-onlytimeout bounds=1737). On integrated5010b0516 (followed only by two documentation edits in33d57cdf9), pinnedMacworkspaceClippy/normalhook,25ownership/doccontracts,101decoder,21pipeline,29HEVCdaemon and62probe tests pass (oneprobe ignored). Final committed33d57cdf9 also passes pinnedMacworkspacecheck(2m58s) andClippy(39.80s). Integrated5010 Linuxworkspacecheckpasses(8m20s); LinuxClippyisrunning. The currenthead gate must pass before landing.
- Main deliberately removed Windows compile gates inee668d0b4; no Windows pass claimed. Broader Mac processing and calibrated fidelity qualification remain separate.

Focused commands:

```sh
cargo +1.97.1 test -p plurx-core --lib hevc_scan --features hiqlite-store --locked
cargo +1.97.1 test -p plurx-core --test decoder_selection --features hiqlite-store --locked
cargo +1.97.1 test -p plurxd --bin plurxd unknown_hevc_scan_is_refined_once_without_fresh_document_cache_downgrade --locked
```

Regression-Test: crates/plurx-core/tests/decoder_selection.rs::hevc_scan_evidence_unlocks_metal_without_defaulting_missing_field_order
Regression-Test: crates/plurxd/src/decode_facts.rs::unknown_hevc_scan_is_refined_once_without_fresh_document_cache_downgrade
Regression-Test: crates/plurxd/src/transcode/manager/candidates.rs::hevc_catalog_and_prepared_source_share_refined_scan_recipe

Regression-Test: crates/plurx-core/src/transcode/pipeline.rs::metal_explicit_peak_preserves_absolute_nits_across_the_fallback_boundary
Regression-Test: crates/plurx-core/tests/decoder_selection.rs::the_metal_pq_plan_is_keyed_by_the_curve_it_runs
Regression-Test: crates/plurxd/src/pipeprobe.rs::the_reference_command_is_the_production_cpu_chain
