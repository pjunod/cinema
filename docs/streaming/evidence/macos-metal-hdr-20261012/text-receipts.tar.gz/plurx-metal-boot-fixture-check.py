from pathlib import Path
import json,subprocess,time
root=Path('/tmp/plurx-metal-boot-fixture-check');root.mkdir(exist_ok=True)
ff='/opt/homebrew/libexec/plurx/jellyfin-ffmpeg-8.1.3-1/ffmpeg';fp=ff.replace('/ffmpeg','/ffprobe')
def run(args):
 t=time.monotonic();r=subprocess.run(args,capture_output=True,timeout=120)
 if r.returncode: raise RuntimeError(r.stderr.decode())
 return r.stdout.decode(),time.monotonic()-t
src=root/'hdr10-probe.mkv'
run([ff,'-hide_banner','-loglevel','error','-y','-f','lavfi','-i','testsrc2=size=3840x2160:rate=24:duration=1.5,format=yuv420p10le','-c:v','libx265','-preset','ultrafast','-x265-params','pools=none:frame-threads=1:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc:master-display=G(13250,34500)B(7500,3000)R(34000,16000)WP(15635,16450)L(11790000,1):max-cll=1179,400','-pix_fmt','yuv420p10le',str(src)])
report={'fixture':'production testsrc2 3840x2160 24fps 1.5s, MaxCLL1179','qualification':'pipeprobe mean-channel correctness only; offline timings are diagnostic','variants':{}}
for name,option in [('cpu',11.79),('metal-old-units',11.79),('metal-corrected-units',117.9)]:
 if name=='cpu':
  graph=f'zscale=tin=smpte2084:min=bt2020nc:pin=bt2020:t=linear:p=bt709:npl=100,format=gbrpf32le,tonemap=tonemap=hable:desat=0:peak={option},zscale=t=bt709:m=bt709:r=tv:dither=error_diffusion,format=yuv420p,scale=-2:min(1080\\,ih),format=nv12,hwupload';inp=['-init_hw_device','videotoolbox=vt','-filter_hw_device','vt']
 else:
  graph=f'scale_vt=w=-1:h=1080:format=p010le,tonemap_videotoolbox=tonemap=hable:tonemap_mode=max:desat=0:peak={option}:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0';inp=['-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld']
 target=root/f'{name}.mp4'
 _,elapsed=run([ff,'-hide_banner','-loglevel','error','-y',*inp,'-i',str(src),'-vf',graph,'-c:v','h264_videotoolbox','-b:v','4000k','-maxrate','6000k','-bufsize','8000k',str(target)])
 text,_=run([fp,'-v','quiet','-f','lavfi','-i',f'movie={target},signalstats','-show_entries','frame_tags=lavfi.signalstats.YAVG,lavfi.signalstats.UAVG,lavfi.signalstats.VAVG','-of','csv=p=0'])
 rows=[[float(x) for x in l.split(',') if x] for l in text.splitlines()]; rows=[r for r in rows if len(r)>=3]
 vals=[sum(r[i] for r in rows)/len(rows) for i in range(3)]
 report['variants'][name]={'mean_yuv':vals,'frames':len(rows),'elapsed':elapsed,'graph':graph}
 if name!='cpu':
  delta=max(abs(a-b) for a,b in zip(vals,report['variants']['cpu']['mean_yuv']));report['variants'][name].update({'max_mean_channel_delta':delta,'picture_pass_at_24_levels':delta<=24})
(root/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
