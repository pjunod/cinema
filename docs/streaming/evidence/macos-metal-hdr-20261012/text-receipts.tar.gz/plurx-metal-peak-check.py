from pathlib import Path
from array import array
import math,json,runpy,subprocess,hashlib
repo=Path('~/code/plurx-agent/metal-acceptance-rerun-20261011-src')
c=runpy.run_path(str(repo/'scripts/tone-map-calibration'))
ff='/opt/homebrew/libexec/plurx/jellyfin-ffmpeg-8.1.3-1/ffmpeg'
out=Path('/tmp/plurx-metal-peak-check');out.mkdir(exist_ok=True)
w,h=512,128
report={'kind':'neutral PQ diagnostic; no real-title/display qualification','ffmpeg_sha256':hashlib.sha256(Path(ff).read_bytes()).hexdigest(),'cases':[]}
def run(args):
 r=subprocess.run([ff,'-hide_banner','-loglevel','error','-nostdin','-threads','1','-filter_threads','1',*args],capture_output=True,timeout=90)
 if r.returncode: raise RuntimeError(r.stderr.decode())
for peak in [1000,1179]:
 raw=out/f'{peak}-source.yuv';src=out/f'{peak}-source.mkv'
 values=array('H',[c['pq_code'](peak*x/(w-1)) if y<43 else c['pq_code'](10*x/(w-1) if y<86 else 20+x/(w-1)) for y in range(h) for x in range(w)]+[512]*(w*h//2))
 raw.write_bytes(values.tobytes()*8)
 run(['-y','-f','rawvideo','-pixel_format','yuv420p10le','-video_size','512x128','-framerate','4','-i',str(raw),'-c:v','libx265','-x265-params',f'lossless=1:pools=none:frame-threads=1:log-level=error:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc:range=limited:max-cll={peak},100','-color_range','tv','-colorspace','bt2020nc','-color_primaries','bt2020','-color_trc','smpte2084',str(src)])
 case={'peak_nits':peak,'variants':{}};report['cases'].append(case)
 for name,option in [('cpu',peak/100),('metal-current',peak/100),('metal-corrected-units',peak/10)]:
  if name=='cpu':
   graph=f'zscale=tin=smpte2084:min=bt2020nc:pin=bt2020:t=linear:p=bt709:npl=100,format=gbrpf32le,tonemap=tonemap=hable:desat=0:peak={option},zscale=t=bt709:m=bt709:r=tv:dither=error_diffusion,format=yuv420p'
   inp=[]
  else:
   graph=f'scale_vt=w=512:h=128:format=p010le,tonemap_videotoolbox=tonemap=hable:tonemap_mode=max:desat=0:peak={option}:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0,hwdownload,format=nv12,format=yuv420p'
   inp=['-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld']
  target=out/f'{peak}-{name}.yuv'
  run(['-y',*inp,'-i',str(src),'-vf',graph,'-frames:v','8','-pix_fmt','yuv420p','-f','rawvideo',str(target)])
  data=target.read_bytes();assert len(data)==w*h*3//2*8
  case['variants'][name]={'graph':graph,'mean_y':sum(data[:w*h])/(w*h),'rows':[[data[y*w+x] for x in [0,64,128,256,384,511]] for y in [21,64,107]]}
  if name!='cpu':
   ref=(out/f'{peak}-cpu.yuv').read_bytes()
   case['variants'][name]['max_y_delta']=max(abs(a-b) for a,b in zip(data[:w*h],ref[:w*h]))
   case['variants'][name]['mean_y_abs_delta']=sum(abs(a-b) for a,b in zip(data[:w*h],ref[:w*h]))/(w*h)
(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
