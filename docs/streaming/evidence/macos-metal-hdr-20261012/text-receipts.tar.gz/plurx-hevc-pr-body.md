Real progressive HEVC HDR10 files can omit FFprobe `field_order`. Plurx then preserves Unknown and routes forced SDR playback to CPU even when the Mac Metal probe passed.

Collect the selected stream's HEVC configuration through the existing bound parser and held source descriptor. Require explicit progressive, non-interlaced, frame-only flags in hvcC and every included VPS/SPS before refining Unknown; preserve explicit scan orders and conservative CPU fallback. Bind the refinement into facts identity and retain it when a fresh source document lacks binary evidence.

Validation: pinned Rust 1.97.1; four captured-configuration parser tests and all 101 decoder-selection tests pass. The new daemon probe/cache test and five existing descriptor/refinement/cancellation/identity regressions pass on the current base. Workspace all-target Clippy and the normal commit hook pass. The committed-source Linux check and actual Air release acceptance are pending. Independent user-requested Astra review of the six code/fixture files found no blockers; it reviewed flags, ownership, identity, cache, deadline/cancellation and offset fences. Documentation contracts pass (18 tests). Real Metal/CPU paused-frame comparison remains open.

Regression-Test: crates/plurx-core/tests/decoder_selection.rs::hevc_scan_evidence_unlocks_metal_without_defaulting_missing_field_order
Regression-Test: crates/plurxd/src/decode_facts.rs::unknown_hevc_scan_is_refined_once_without_fresh_document_cache_downgrade
