from pathlib import Path
import json,subprocess,hashlib
ff='/opt/homebrew/libexec/plurx/jellyfin-ffmpeg-8.1.3-1/ffmpeg'
src='~/mnt/nas/20t/movies/American Gangster (2007)/American Gangster (2007) [Remux 2160p].mkv'
out=Path('/tmp/plurx-metal-real-frame-check');out.mkdir(exist_ok=True)
w,h=1920,1080
report={'kind':'same source timestamp 300s, unencoded raw output, diagnostic only','ffmpeg_sha256':hashlib.sha256(Path(ff).read_bytes()).hexdigest(),'variants':{}}
for name,option in [('cpu',11.79),('metal-current',11.79),('metal-corrected-units',117.9)]:
 if name=='cpu':
  graph=f'scale=1920:1080,setsar=1,zscale=tin=smpte2084:min=bt2020nc:pin=bt2020:t=linear:p=bt709:npl=100,format=gbrpf32le,tonemap=tonemap=hable:desat=0:peak={option},zscale=t=bt709:m=bt709:r=tv:dither=error_diffusion,format=yuv420p';inp=['-hwaccel','videotoolbox']
 else:
  graph=f'scale_vt=w=1920:h=1080:format=p010le,tonemap_videotoolbox=tonemap=hable:tonemap_mode=max:desat=0:peak={option}:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0,hwdownload,format=nv12,format=yuv420p';inp=['-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld']
 p=out/f'{name}.yuv'
 args=[ff,'-hide_banner','-loglevel','error','-nostdin','-threads','1','-y',*inp,'-ss','300','-noautorotate','-i',src,'-map','0:0','-an','-vf',graph,'-frames:v','1','-pix_fmt','yuv420p','-f','rawvideo',str(p)]
 r=subprocess.run(args,capture_output=True,timeout=90)
 if r.returncode: raise RuntimeError(r.stderr.decode())
 data=p.read_bytes();assert len(data)==w*h*3//2
 report['variants'][name]={'graph':graph,'mean_y':sum(data[:w*h])/(w*h),'raw_sha256':hashlib.sha256(data).hexdigest()}
 if name!='cpu':
  ref=(out/'cpu.yuv').read_bytes();d=sorted(abs(a-b) for a,b in zip(data[:w*h],ref[:w*h]));report['variants'][name].update({'max_y_delta':d[-1],'p95_y_delta':d[int(.95*len(d))],'mean_y_abs_delta':sum(d)/len(d)})
(out/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
