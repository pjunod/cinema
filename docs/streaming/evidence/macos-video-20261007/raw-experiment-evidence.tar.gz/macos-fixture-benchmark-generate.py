#!/usr/bin/env python3
"""Task-local synthetic benchmark construction; not runtime or quality evidence."""
import argparse
from array import array
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys
import threading
import time

p=argparse.ArgumentParser()
p.add_argument('--ffmpeg',required=True,type=Path)
p.add_argument('--ffprobe',required=True,type=Path)
p.add_argument('--smoke-generator',required=True,type=Path)
p.add_argument('--output',required=True,type=Path)
p.add_argument('--seconds',type=int,default=60)
p.add_argument('--deadline-seconds',type=int,default=600)
a=p.parse_args()
for executable in (a.ffmpeg,a.ffprobe):
    if not executable.is_absolute() or not executable.is_file(): raise ValueError('Explicit absolute binary path required')
if a.seconds < 1 or a.seconds > 120: raise ValueError('Bounded1..120seconds only')
if a.output.exists() and any(a.output.iterdir()): raise ValueError('New/empty task-owned directory required')
a.output.mkdir(parents=True,exist_ok=True)
m=runpy.run_path(str(a.smoke_generator))
W,H,FPS=3840,2160,24
FRAMES=a.seconds*FPS

def packed(values,bits):
    if bits==8: return bytes(values)
    words=array('H',values)
    if sys.byteorder!='little': words.byteswap()
    return words.tobytes()

def row(values,columns,bits):
    return b''.join(packed([v],bits)*columns for v in values)

def base(family,bits,scene):
    gain=1 if scene==0 else .25
    levels=[n*gain for n in m['GRAY_NITS'][family]]
    peak=(400 if family=='hdr10' else 100)*gain
    rgbs=[(peak,0,0),(0,peak,0),(0,0,peak),(peak,peak,0),(0,peak,peak),(peak,0,peak),(0,0,0),(peak,peak,peak)]
    gray=[m['rgb_to_yuv']((n,n,n),family,bits) for n in levels]
    color=[m['rgb_to_yuv'](v,family,bits) for v in rgbs]
    if scene: gray.reverse(); color.reverse()
    planes=[]
    for plane in range(3):
        col=W//8 if plane==0 else W//16
        top=1440 if plane==0 else 720
        bottom=720 if plane==0 else 360
        planes.append(row([v[plane] for v in gray],col,bits)*top+row([v[plane] for v in color],col,bits)*bottom)
    marker=m['rgb_to_yuv']((peak,peak,peak),family,bits)
    return b''.join(planes),marker

def frame(data,marker,bits,index):
    raw=bytearray(data)
    bytes_per=1 if bits==8 else 2
    x=(32*(index%120))%(W-128)
    y=1920
    offset=0
    for plane in range(3):
        width,height,px,py,edge=(W,H,x,y,128) if plane==0 else (W//2,H//2,x//2,y//2,64)
        patch=packed([marker[plane]],bits)*edge
        for line in range(py,py+edge):
            pos=(offset+line*width+px)*bytes_per
            raw[pos:pos+len(patch)]=patch
        offset+=width*height
    return raw

fixtures=[]
for family,bits,identity in (('sdr',8,'sdr2160p24'),('hdr10',10,'hdr2160p24')):
    spec=m['fixture_spec']('sdr8' if bits==8 else 'hdr10')
    e=spec['expected']
    params='pools=2:frame-threads=1:wpp=1:keyint=48:min-keyint=48:scenecut=0:bframes=2:repeat-headers=1:info=0'
    params+=f":colorprim={e['color_primaries']}:transfer={e['color_transfer']}:colormatrix={e['color_space']}:range=limited"
    if family=='hdr10': params+=':hdr10=1:hdr10-opt=0:master-display=G(8500,39850)B(6550,2300)R(35400,14600)WP(15635,16450)L(10000000,1):max-cll=1000,400'
    video=a.output/(identity+'.mp4')
    argv=[str(a.ffmpeg),'-hide_banner','-loglevel','error','-nostdin','-y','-threads','2','-f','rawvideo','-pixel_format',e['pix_fmt'],'-video_size',f'{W}x{H}','-framerate',str(FPS),'-i','pipe:0','-map','0:v:0','-an','-frames:v',str(FRAMES),'-vf','setsar=1','-c:v','libx265','-preset','ultrafast','-crf','18','-profile:v','main' if bits==8 else 'main10','-x265-params',params,'-pix_fmt',e['pix_fmt'],'-color_primaries',e['color_primaries'],'-color_trc',e['color_transfer'],'-colorspace',e['color_space'],'-color_range','tv','-tag:v','hvc1','-map_metadata','-1','-fflags','+bitexact','-flags:v','+bitexact','-movflags','+faststart',str(video)]
    scenes=[base(family,bits,s) for s in range(2)]
    writer_errors=[]
    start=time.monotonic()
    with (a.output/(identity+'.encode.log')).open('wb') as log:
        proc=subprocess.Popen(argv,stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=log)
        def write():
            try:
                for index in range(FRAMES):
                    data,marker=scenes[(index//(5*FPS))%2]
                    proc.stdin.write(frame(data,marker,bits,index))
                proc.stdin.close()
            except (OSError,ValueError) as error: writer_errors.append(str(error))
        producer=threading.Thread(target=write,daemon=True)
        producer.start()
        try: code=proc.wait(timeout=a.deadline_seconds)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(); producer.join(timeout=5)
            raise RuntimeError(f'{identity}: generation deadline exceeded')
        producer.join(timeout=5)
    elapsed=time.monotonic()-start
    if code or writer_errors or producer.is_alive(): raise RuntimeError(f'{identity}: encoder/write failed: {code},{writer_errors}')
    probe=json.loads(subprocess.run([str(a.ffprobe),'-v','error','-count_frames','-show_streams','-of','json',str(video)],check=True,capture_output=True,timeout=180).stdout)
    stream=probe['streams'][0]
    expected={**e,'width':W,'height':H,'frame_count':FRAMES,'avg_frame_rate':f'{FPS}/1'}
    for key,value in expected.items():
        actual=int(stream['nb_read_frames']) if key=='frame_count' else stream.get(key)
        if actual!=value: raise RuntimeError(f'{identity}: {key}: {actual} != {value}')
    if abs(float(stream['duration'])-a.seconds)>.00002: raise RuntimeError('Unexpected duration')
    entry={'id':identity,'path':video.name,'sha256':m['sha256'](video),'byte_length':video.stat().st_size,'class':family,'role':'sustained','available':True,'duration_seconds':a.seconds,'expected':expected,'provenance':{'source':'Own analytic RGB patches; ST2084 inverse EOTF for PQ, BT709 OETF for SDR, known limited-range matrix conversion before encoding','license':'CC0-1.0','generator_recipe_version':1,'scene_cut_seconds':5,'scene_gain_cycle':[1,.25],'motion':'128x128 white rectangle stepping32pixels/frame on aligned2x2blocks','generator':'task-local macos-fixture-benchmark-generate.py; uses committed smoke generator transfer/matrix functions'},'construction':{'encode_wall_seconds':elapsed,'decoded_frame_count':int(stream['nb_read_frames']),'ffmpeg_sha256':m['sha256'](a.ffmpeg),'ffprobe_sha256':m['sha256'](a.ffprobe),'argv':['$FFMPEG']+argv[1:-1]+['$OUTPUT']}}
    fixtures.append(entry)
    print(json.dumps({'id':identity,'seconds':a.seconds,'encode_wall_seconds':elapsed,'decoded_frame_count':int(stream['nb_read_frames']),'byte_length':entry['byte_length'],'sha256':entry['sha256']}),flush=True)
    manifest={'schema_version':1,'fixtures':fixtures,'limitations':['Synthetic benchmark inputs only; no private footage, no Dolby Vision RPU, no full perceptual qualification','Generation wall time is encoder construction cost, not production graph performance','Gray patches/colors/cuts/motion are intentionally simple and not representative of compressed movie complexity']}
    (a.output/'manifest.json').write_bytes(m['json_bytes'](manifest))
(a.output/'LICENSE.txt').write_text(m['LICENSE'])
