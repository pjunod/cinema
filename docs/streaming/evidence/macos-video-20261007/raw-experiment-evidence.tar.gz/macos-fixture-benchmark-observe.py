#!/usr/bin/env python3
"""Decode known source patches before treating synthetic PQ as benchmark input."""
from array import array
import json
from pathlib import Path
import runpy
import subprocess
import sys

root=Path('/experiment')
corpus=root/'macos-fixture-sustained'
m=runpy.run_path(str(root/'fixtures/scripts/generate-macos-video-fixtures'))
ffmpeg=root/'native-candidate/package/ffmpeg'
ffprobe=root/'native-candidate/package/ffprobe'
manifest=json.loads((corpus/'manifest.json').read_text())
observations=[]
for fixture in manifest['fixtures']:
    family=fixture['class']
    bits=8 if family=='sdr' else 10
    video=corpus/fixture['path']
    times=[]
    for seconds,scene in ((0,0),(5.5,1)):
        argv=[str(ffmpeg),'-v','error','-nostdin','-threads','2','-ss',str(seconds),'-i',str(video),'-frames:v','1','-an','-pix_fmt',fixture['expected']['pix_fmt'],'-f','rawvideo','pipe:1']
        raw=subprocess.run(argv,capture_output=True,timeout=30,check=True).stdout
        if len(raw)!=3840*2160*3//2*(1 if bits==8 else 2): raise RuntimeError('Source frame length differs')
        samples=raw
        if bits==10:
            samples=array('H'); samples.frombytes(raw)
            if sys.byteorder!='little': samples.byteswap()
        levels=[n*(1 if scene==0 else .25) for n in m['GRAY_NITS'][family]]
        if scene: levels.reverse()
        observed=[]
        expected=[]
        for i,nits in enumerate(levels):
            value=samples[720*3840+240+480*i]
            reference=m['rgb_to_yuv']((nits,nits,nits),family,bits)[0]
            observed.append(value);expected.append(reference)
            if abs(value-reference)>(8 if bits==8 else 32): raise RuntimeError(f'{fixture["id"]}: source gray patch differs')
        times.append({'seconds':seconds,'scene':scene,'decoded_y_codes':observed,'analytic_y_codes':expected,'result':'passed'})
    metadata=json.loads(subprocess.run([str(ffprobe),'-v','error','-select_streams','v:0','-read_intervals','0%+0.1','-show_frames','-of','json',str(video)],capture_output=True,timeout=30,check=True).stdout)
    sides={s['side_data_type'] for f in metadata['frames'] for s in f.get('side_data_list',[])}
    if family=='hdr10' and not {'Mastering display metadata','Content light level metadata'}.issubset(sides): raise RuntimeError('PQ source staticHDRmetadata missing')
    if any('dovi' in s.lower() or 'dolby' in s.lower() for s in sides): raise RuntimeError('Unexpected Dolby metadata')
    observations.append({'id':fixture['id'],'sha256':fixture['sha256'],'source_observations':times,'side_data_types':sorted(sides)})
report={'schema_version':1,'result':'verified_synthetic_source_patches','fixtures':observations,'limitations':['No hardware graph, performance or perceptual qualification; analytic source decode observations only']}
(corpus/'source-observations.json').write_bytes(m['json_bytes'](report))
print(json.dumps(report,indent=2))
