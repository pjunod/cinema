#!/usr/bin/env python3
"""Isolated loopback production-daemon experiment; not a unit test runner."""
import argparse, hashlib, json, os, secrets, signal, socket, subprocess, time, urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--binary',required=True);p.add_argument('--package',required=True);p.add_argument('--output',required=True);a=p.parse_args()
root=Path(a.output);root.mkdir(mode=0o700,exist_ok=False)
ports=[]
for _ in range(3):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));ports.append(sock.getsockname()[1])
if len(set(ports))!=3: raise RuntimeError('ports collided; rerun with new empty output')
config=root/'plurx.toml'
config.write_text(f'[server]\nname="Mac isolated experiment"\nbind="127.0.0.1:{ports[0]}"\njellyfin_port=0\n[storage]\ndata_dir="{root}/data"\ncache_dir="{root}/cache"\ntranscode_dir="{root}/scratch"\n[cluster]\nraft_bind="127.0.0.1:{ports[1]}"\napi_bind="127.0.0.1:{ports[2]}"\n')
config.chmod(0o600)
env={key:os.environ[key] for key in ['PATH','HOME','TMPDIR'] if key in os.environ}
env.update(PLURX_FFMPEG=str(Path(a.package)/'ffmpeg'),PLURX_FFPROBE=str(Path(a.package)/'ffprobe'),PLURX_MDNS_ADVERTISE='0',PLURX_LOG='info')
argv=[a.binary,'--config',str(config),'run'];base=f'http://127.0.0.1:{ports[0]}'
receipt={'schema_version':1,'kind':'isolated_daemon_integration','commands':[argv], 'configured_environment':{k:v for k,v in env.items() if k.startswith('PLURX_')},'binary_sha256':hashlib.sha256(Path(a.binary).read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'observations':[],'limitations':['No deployed-daemon claim','No rolling HLS or VOD client exercise','Visual/client/concurrency/soak qualification unmeasured']}
child=None;log=None;token=None

def request(path,method='GET',body=None,authenticated=True):
    headers={'Content-Type':'application/json'}
    if authenticated and token: headers['Authorization']='Bearer '+token
    req=urllib.request.Request(base+'/api/v1'+path,data=None if body is None else json.dumps(body).encode(),headers=headers,method=method)
    with urllib.request.urlopen(req,timeout=10) as resp: return resp.status,json.load(resp)

def launch(name):
    global child,log
    log=(root/name).open('wb');child=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    deadline=time.monotonic()+180
    while time.monotonic()<deadline:
        if child.poll() is not None: raise RuntimeError(f'daemon exited {child.returncode}; inspect private log')
        try: return request('/server',authenticated=False)[1]
        except (OSError,ValueError): time.sleep(.25)
    raise RuntimeError('isolated startup deadline exceeded')

def stop():
    global child,log
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGINT)
        try:child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
    if child is not None:receipt['observations'].append({'shutdown_exit':child.returncode})
    if log is not None:log.close()
    child=None;log=None

def observe_report():
    return request('/settings')[1]['macos_video_processing']

try:
    launch('first.log')
    password=secrets.token_urlsafe(30)
    token=request('/setup','POST',{'username':'experiment-admin','password':password},False)[1]['token']
    del password
    initial=request('/settings')[1]
    assert initial['macos_video_processing_enabled'] is False
    receipt['observations'].append({'initial_default':False,'report':initial['macos_video_processing']})
    for value in [True,False,True]:
        status,saved=request('/settings','PUT',{'macos_video_processing_enabled':value})
        assert status==200 and saved['macos_video_processing_enabled']==value
        assert request('/settings')[1]['macos_video_processing_enabled']==value
        receipt['observations'].append({'saved_choice_roundtrip':value,'report':saved['macos_video_processing']})
    deadline=time.monotonic()+65
    while time.monotonic()<deadline:
        old=observe_report()
        if all(old[g]['availability']!='pending' for g in ['sdr_scale','hdr10_metal']):break
        time.sleep(.5)
    receipt['observations'].append({'startup_probe':old})
    status,accepted=request('/developer/macos-video-processing/reprobe','POST',{})
    assert status==202 and accepted['accepted'] is True
    deadline=time.monotonic()+65;final=old
    while time.monotonic()<deadline:
        final=observe_report()
        graphs=[final.get('sdr_scale',{}),final.get('hdr10_metal',{})]
        if final.get('generation',0)>old.get('generation',0) and all(g.get('availability')!='pending' for g in graphs):break
        time.sleep(.5)
    assert final.get('generation',0)>old.get('generation',0), 'explicit generation did not advance'
    assert all(final[g]['availability']!='pending' for g in ['sdr_scale','hdr10_metal']), 'explicit generation remained pending'
    assert request('/settings')[1]['macos_video_processing_enabled'] is True
    receipt['observations'].append({'admin_reprobe_status':status,'before':old,'after':final,'saved_choice_preserved':True})
    cached=[path for path in root.rglob('*.mp4') if len(path.stem)==64 and 'macos-processing' in path.parts]
    if cached and all(final[g]['availability']=='available' for g in ['sdr_scale','hdr10_metal']):
        source=cached[0];expected=hashlib.sha256(source.read_bytes()).hexdigest()
        source.write_bytes(b'corrupted task-owned cached fixture')
        request('/developer/macos-video-processing/reprobe','POST',{})
        deadline=time.monotonic()+65
        while time.monotonic()<deadline:
            repaired=observe_report()
            if repaired['generation']>final['generation'] and all(repaired[g]['availability']!='pending' for g in ['sdr_scale','hdr10_metal']):break
            time.sleep(.5)
        actual=hashlib.sha256(source.read_bytes()).hexdigest()
        assert actual==expected, 'task-owned cached fixture was not repaired'
        receipt['observations'].append({'corrupt_cache_repaired':True,'source_sha256':actual,'report':repaired})
    readiness=request('/developer/readiness')[1]
    receipt['observations'].append({'readiness':next(i for i in readiness['items'] if i['id']=='macos_video_processing')})
    stop();launch('restart.log')
    restarted=request('/settings')[1]
    assert restarted['macos_video_processing_enabled'] is True
    receipt['observations'].append({'restart_saved_choice':True,'report':restarted['macos_video_processing']})
    receipt['result']='passed_setting_and_probe_wiring'
except Exception as error:
    receipt['result']='failed';receipt['error']=str(error);raise
finally:
    stop();(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({'result':receipt.get('result'),'receipt':str(root/'receipt.json')}))
