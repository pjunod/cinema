#!/usr/bin/env python3
"""Isolated loopback production-daemon experiment; not a unit test runner."""
import argparse, hashlib, json, os, secrets, signal, socket, subprocess, time, urllib.request
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--binary',required=True);p.add_argument('--package',required=True);p.add_argument('--output',required=True);p.add_argument('--source',default='/experiment/macos-fixture-sustained/sdr2160p24.mp4');a=p.parse_args()
root=Path(a.output);root.mkdir(mode=0o700,exist_ok=False)
ports=[]
for _ in range(3):
    with socket.socket() as sock:
        sock.bind(('127.0.0.1',0));ports.append(sock.getsockname()[1])
if len(set(ports))!=3: raise RuntimeError('ports collided; rerun with new empty output')
config=root/'plurx.toml'
config.write_text(f'[server]\nname="Mac isolated experiment"\nbind="127.0.0.1:{ports[0]}"\njellyfin_port=0\n[storage]\ndata_dir="{root}/data"\ncache_dir="{root}/cache"\ntranscode_dir="{root}/scratch"\n[cluster]\nraft_bind="127.0.0.1:{ports[1]}"\napi_bind="127.0.0.1:{ports[2]}"\n')
config.chmod(0o600)
env={key:os.environ[key] for key in ['PATH','HOME','TMPDIR'] if key in os.environ}
env.update(PLURX_FFMPEG=str(Path(a.package)/'ffmpeg'),PLURX_FFPROBE=str(Path(a.package)/'ffprobe'),PLURX_MDNS_ADVERTISE='0',PLURX_LOG='info,plurxd::transcode=debug,plurxd::vodencode=debug')
argv=[a.binary,'--config',str(config),'run'];base=f'http://127.0.0.1:{ports[0]}'
receipt={'schema_version':1,'kind':'isolated_daemon_integration','commands':[argv], 'configured_environment':{k:v for k,v in env.items() if k.startswith('PLURX_')},'binary_sha256':hashlib.sha256(Path(a.binary).read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'observations':[],'limitations':['No deployed-daemon claim','No rolling HLS or VOD client exercise','Visual/client/concurrency/soak qualification unmeasured']}
child=None;log=None;token=None

def request(path,method='GET',body=None,authenticated=True):
    headers={'Content-Type':'application/json'}
    if authenticated and token: headers['Authorization']='Bearer '+token
    req=urllib.request.Request(base+'/api/v1'+path,data=None if body is None else json.dumps(body).encode(),headers=headers,method=method)
    with urllib.request.urlopen(req,timeout=10) as resp: return resp.status,json.load(resp)

def launch(name):
    global child,log
    log=(root/name).open('wb');child=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    deadline=time.monotonic()+180
    while time.monotonic()<deadline:
        if child.poll() is not None: raise RuntimeError(f'daemon exited {child.returncode}; inspect private log')
        try: return request('/server',authenticated=False)[1]
        except (OSError,ValueError): time.sleep(.25)
    raise RuntimeError('isolated startup deadline exceeded')

def stop():
    global child,log
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGINT)
        try:child.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGKILL);child.wait(timeout=10)
    if child is not None:receipt['observations'].append({'shutdown_exit':child.returncode})
    if log is not None:log.close()
    child=None;log=None

def observe_report():
    return request('/settings')[1]['macos_video_processing']

import shutil,urllib.error
source=root/'media';source.mkdir(mode=0o700)
shutil.copyfile(a.source,source/'Mac Processing Experiment (2026).mp4')
receipt['kind']='isolated_daemon_source_delivery'
receipt['source_sha256']=hashlib.sha256(next(source.iterdir()).read_bytes()).hexdigest()
try:
    launch('delivery.log')
    token=request('/setup','POST',{'username':'experiment-admin','password':secrets.token_urlsafe(30)},False)[1]['token']
    request('/settings','PUT',{'macos_video_processing_enabled':True})
    deadline=time.monotonic()+65
    while time.monotonic()<deadline:
        report=observe_report()
        if all(report[g]['availability']!='pending' for g in ['sdr_scale','hdr10_metal']):break
        time.sleep(.5)
    receipt['observations'].append({'runtime_report':report})
    lib=request('/libraries','POST',{'name':'Synthetic isolated experiment','kind':'movies','paths':[str(source)]})[1]
    deadline=time.monotonic()+90
    while time.monotonic()<deadline:
        items=request(f"/libraries/{lib['id']}/items")[1]['items']
        if items:
            detail=request(f"/items/{items[0]['id']}")[1]
            if detail['files']:break
        time.sleep(.5)
    file_id=detail['files'][0]['id']
    receipt['observations'].append({'scanned_file':{k:v for k,v in detail['files'][0].items() if k in ['id','width','height','codec','hdr','video_codec','video_profile','bit_depth']}})
    for presentation in [None,'live']:
        body={'playback_id':'isolated-source-'+str(presentation),'request_id':secrets.token_hex(8),'height':1080,'quality_auto':False,'copy':False,'start':0}
        if presentation:body['presentation']=presentation
        try:
            status,created=request(f'/files/{file_id}/hls/sessions','POST',body)
            receipt['observations'].append({'presentation':presentation,'create_status':status,'created':created})
            session=created.get('session_id')
            if session:
                receipt['observations'].append({'session_status':request(f'/hls/{session}/status')[1]})
                url=created.get('playlist_url') or f'/api/v1/hls/{session}/index.m3u8'
                req=urllib.request.Request(base+url,headers={'Authorization':'Bearer '+token})
                with urllib.request.urlopen(req,timeout=15) as resp:
                    playlist=resp.read();receipt['observations'].append({'playlist_status':resp.status,'playlist_bytes':len(playlist),'playlist_sha256':hashlib.sha256(playlist).hexdigest(),'playlist_head':playlist[:500].decode(errors='replace')})
                media=[]
                for name in ['init.mp4','seg00000.m4s']:
                    req=urllib.request.Request(base+f'/api/v1/hls/{session}/{name}',headers={'Authorization':'Bearer '+token})
                    with urllib.request.urlopen(req,timeout=25) as resp:
                        data=resp.read(32*1024*1024)
                        assert data, 'empty produced object'
                        (root/name).write_bytes(data);media.append(data)
                        receipt['observations'].append({'produced_object':name,'http_status':resp.status,'byte_length':len(data),'sha256':hashlib.sha256(data).hexdigest()})
                joined=root/'first-fragment.mp4';joined.write_bytes(b''.join(media))
                observed=subprocess.run([str(Path(a.package)/'ffprobe'),'-v','error','-select_streams','v:0','-show_streams','-show_frames','-of','json',str(joined)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=True)
                facts=json.loads(observed.stdout);(root/'first-fragment-observations.json').write_text(json.dumps(facts,indent=2)+'\n')
                receipt['observations'].append({'decoded_fragment_frame_count':len(facts['frames']),'stream':facts['streams'][0]})
                req=urllib.request.Request(base+f'/api/v1/hls/{session}',headers={'Authorization':'Bearer '+token},method='DELETE')
                with urllib.request.urlopen(req,timeout=10) as resp:receipt['observations'].append({'stop_status':resp.status})
        except urllib.error.HTTPError as error:
            receipt['observations'].append({'presentation':presentation,'http_status':error.code,'body':error.read().decode(errors='replace')})
    receipt['result']='completed_actual_source_delivery_observations'
except Exception as error:
    receipt['result']='failed';receipt['error']=str(error);raise
finally:
    stop();(root/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'result':receipt.get('result'),'receipt':str(root/'receipt.json')}))
