import hashlib, json, pathlib, re, subprocess

root = pathlib.Path('/experiment')
out = root / 'p5-feasibility'
binary = root / 'native-candidate/final-package/ffmpeg'
source = out / 'fate-dovi-p5.mp4'
assert hashlib.sha256(source.read_bytes()).hexdigest() == '11fe599fd77e31e26fbf855bae1cd9931df9f261a0a7b1dce9fad9b236677c4b'
cpu = 'tonemapx=tonemap=bt2390:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=yuv420p:apply_dovi=1,scale=160:90,format=yuv420p'
metal = 'tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=1,scale_vt=w=160:h=90:format=nv12'
for decoder in ('software', 'videotoolbox'):
    for renderer in ('tonemapx', 'metal'):
        label = f'{decoder}-{renderer}'
        initial = ['-init_hw_device', 'videotoolbox=vt', '-filter_hw_device', 'vt'] if decoder == 'software' and renderer == 'metal' else []
        decode = ['-hwaccel', 'videotoolbox', '-hwaccel_output_format', 'videotoolbox_vld'] if decoder == 'videotoolbox' else ['-hwaccel', 'none']
        bridge = 'hwdownload,format=p010le,' if decoder == 'videotoolbox' and renderer == 'tonemapx' else 'format=p010le,hwupload,' if decoder == 'software' and renderer == 'metal' else ''
        graph = bridge + 'showinfo@before,' + (cpu if renderer == 'tonemapx' else metal) + ',showinfo@after'
        output = out / f'{label}.mp4'
        argv = [str(binary), '-hide_banner', '-loglevel', 'debug', '-nostdin', '-y'] + initial + decode + [
            '-i', str(source), '-an', '-vf', graph, '-frames:v', '10', '-c:v', 'h264_videotoolbox', '-allow_sw', '0',
            '-b:v', '2000k', '-bf', '0', '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-color_range', 'tv', str(output)]
        r = subprocess.run(argv, capture_output=True, timeout=30)
        log = r.stderr.decode(errors='replace')
        (out / f'{label}.log').write_text(log)
        stages = {'before': [], 'after': []}
        for line in log.splitlines():
            stage = next((stage for stage in stages if f'showinfo@{stage} ' in line), None)
            if stage is None:
                continue
            if re.search(r'\bn:\s*\d+\s+pts:', line):
                stages[stage].append({'frame': line, 'parsed_dovi_metadata': False, 'metadata_lines': []})
            elif stages[stage] and ('rpu_type=' in line or 'side data -' in line):
                stages[stage][-1]['metadata_lines'].append(line)
                if 'rpu_type=' in line:
                    stages[stage][-1]['parsed_dovi_metadata'] = True
        receipt = {'argv': argv, 'exit_code': r.returncode, 'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'stages': stages,
                   'limitations': ['Artificial FATE fixture; transport/wiring diagnostic only', 'No genuine P5 visual or sustained performance qualification', 'HEVC physical hardware decode property unavailable', 'No production P5 enablement']}
        if r.returncode == 0:
            q = subprocess.run([str(binary.with_name('ffprobe')), '-v', 'error', '-count_frames', '-show_streams', '-show_frames', '-of', 'json', str(output)], capture_output=True, check=True, timeout=15)
            j = json.loads(q.stdout)
            (out / f'{label}-probe.json').write_bytes(q.stdout)
            s = j['streams'][0]
            receipt['stream'] = {k: s.get(k) for k in ['codec_name', 'width', 'height', 'pix_fmt', 'color_space', 'color_transfer', 'color_primaries', 'color_range', 'nb_read_frames', 'side_data_list']}
            receipt['frame_side_data'] = [f.get('side_data_list', []) for f in j['frames']]
        (out / f'{label}-receipt.json').write_text(json.dumps(receipt, indent=2))
        print(label, 'exit', r.returncode, {stage: (len(frames), sum(f['parsed_dovi_metadata'] for f in frames)) for stage, frames in stages.items()}, receipt.get('stream'))
        if r.returncode:
            print(log[-2000:])
