import hashlib, json, pathlib, subprocess

root = pathlib.Path('/experiment')
out = root / 'native-evidence'
binary = root / 'native-candidate/final-package/ffmpeg'
probe = binary.with_name('ffprobe')
for kind in ('sdr', 'hdr'):
    source = root / f'macos-fixture-sustained/{kind}2160p24.mp4'
    renderer = ('scale_vt=w=1920:h=1080:format=nv12' if kind == 'sdr' else
                'scale_vt=w=1920:h=1080:format=p010le,tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0')
    graph = ('trim=start=0.000000000,fps=24/1:start_time=0.000000000,' + renderer +
             ',setsar=1,tpad=stop_mode=clone:stop_duration=60.000000000,trim=end_frame=1440,setpts=PTS-0.000000000/TB,setparams=range=limited:color_primaries=bt709:color_trc=bt709:colorspace=bt709')
    path = out / f'continuous-{kind}-high50.mp4'
    argv = [str(binary), '-hide_banner', '-loglevel', 'debug', '-nostdin', '-y', '-copyts', '-noaccurate_seek',
            '-hwaccel', 'videotoolbox', '-hwaccel_output_format', 'videotoolbox_vld', '-i', str(source),
            '-map', '0:v:0', '-an', '-vf', graph, '-frames:v', '3', '-c:v', 'h264_videotoolbox', '-allow_sw', '0',
            '-b:v', '8000k', '-maxrate', '12000k', '-bufsize', '16000k', '-profile:v', 'high', '-level:v', '5.0',
            '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', '-color_range', 'tv',
            '-force_key_frames', 'expr:eq(mod(n,48),0)', '-map_chapters', '-1', '-bf', '0', '-flags', '+cgop',
            '-g', '48', '-keyint_min', '48', '-sc_threshold', '0', '-fps_mode:v', 'passthrough',
            '-enc_time_base:v', '1:24', '-avoid_negative_ts', 'disabled', '-use_editlist', '0',
            '-movflags', '+empty_moov+delay_moov+default_base_moof+frag_keyframe+write_colr',
            '-video_track_timescale', '24', '-f', 'mp4', str(path)]
    r = subprocess.run(argv, capture_output=True, timeout=30)
    (out / f'continuous-{kind}-high50.log').write_bytes(r.stderr + r.stdout)
    receipt = {'argv': argv, 'exit_code': r.returncode, 'input_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
               'limitations': ['Three-frame correctness smoke only; no throughput evidence', 'No temporal/seek/fragment publication qualification', 'HEVC physical hardware decode property not observed']}
    if r.returncode == 0:
        q = subprocess.run([str(probe), '-v', 'error', '-count_frames', '-show_streams', '-show_frames', '-of', 'json', str(path)], capture_output=True, check=True, timeout=15)
        j = json.loads(q.stdout)
        (out / f'continuous-{kind}-high50-probe.json').write_bytes(q.stdout)
        s = j['streams'][0]
        receipt['stream'] = {k: s.get(k) for k in ['codec_name', 'profile', 'level', 'width', 'height', 'pix_fmt', 'sample_aspect_ratio', 'color_space', 'color_transfer', 'color_primaries', 'color_range', 'nb_read_frames', 'time_base']}
        receipt['frame_side_data'] = [f.get('side_data_list', []) for f in j['frames']]
        receipt['pts'] = [f.get('pts') for f in j['frames']]
    (out / f'continuous-{kind}-high50-receipt.json').write_text(json.dumps(receipt, indent=2))
    print(kind, r.returncode, receipt.get('stream'), receipt.get('pts'))
    if r.returncode:
        print(r.stderr.decode(errors='replace')[-2000:])
