import json,subprocess,pathlib
p=pathlib.Path('/experiment/native-evidence')
b='/experiment/native-candidate/verified-package/ffmpeg'
f='/experiment/fixtures/crates/plurxd/fixtures/macos-processing'
for name,fixture,graph in [('sdr','sdr8.mp4','scale_vt=w=160:h=90:format=nv12'),('hdr-native','hdr10.mp4','scale_vt=w=160:h=90:color_matrix=bt709:color_primaries=bt709:color_transfer=bt709:format=nv12'),('hdr-metal','hdr10.mp4','tonemap_videotoolbox=tonemap=bt2390:tonemap_mode=itp:transfer=bt709:matrix=bt709:primaries=bt709:range=tv:format=nv12:apply_dovi=0,scale_vt=w=160:h=90:format=nv12')]:
 argv=[b,'-hide_banner','-loglevel','debug','-nostdin','-y','-hwaccel','videotoolbox','-hwaccel_output_format','videotoolbox_vld','-i',f+'/'+fixture,'-an','-vf',graph,'-frames:v','3','-c:v','h264_videotoolbox','-allow_sw','0','-b:v','1000k','-bf','0','-color_primaries','bt709','-color_trc','bt709','-colorspace','bt709','-color_range','tv',str(p/(name+'.mp4'))]
 r=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=25)
 (p/(name+'.log')).write_bytes(r.stdout)
 receipt={'argv':argv,'exit_code':r.returncode,'log':str(p/(name+'.log'))}
 if r.returncode==0:
  probe=subprocess.run([b.replace('ffmpeg','ffprobe'),'-v','error','-count_frames','-show_streams','-show_frames','-of','json',str(p/(name+'.mp4'))],capture_output=True,timeout=10)
  (p/(name+'-probe.json')).write_bytes(probe.stdout)
  receipt['probe_exit_code']=probe.returncode
 (p/(name+'-receipt.json')).write_text(json.dumps(receipt,indent=2))
 print(name,r.returncode,r.stdout.decode(errors='replace')[-1800:])
