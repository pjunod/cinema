import pathlib,json,subprocess
p=pathlib.Path('/experiment/native-evidence');a=json.loads((p/'native-setparams-argv.json').read_text());r=subprocess.run(a,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=25);(p/'hdr-native-setparams.log').write_bytes(r.stdout);print(r.returncode,r.stdout.decode(errors='replace')[-1500:])
