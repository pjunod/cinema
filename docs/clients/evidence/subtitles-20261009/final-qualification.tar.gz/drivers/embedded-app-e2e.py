#!/usr/bin/env python3
"""Prepared opt-in one-title real app/server caption acceptance; no stubs."""
import argparse
import importlib.machinery
import importlib.util
import json
import os
import pathlib
import subprocess
import time
from types import SimpleNamespace
from urllib.parse import urlparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', type=pathlib.Path, required=True)
parser.add_argument('--server-bin', type=pathlib.Path, required=True)
parser.add_argument('--ffmpeg', type=pathlib.Path, required=True)
parser.add_argument('--browser', type=pathlib.Path, required=True)
parser.add_argument('--out', type=pathlib.Path, required=True)
args = parser.parse_args()
root = args.source_root.resolve()
os.environ["PLURX_FFMPEG"] = str(args.ffmpeg.resolve())
ffprobe = args.ffmpeg.resolve().with_name("ffprobe")
if ffprobe.is_file():
    os.environ["PLURX_FFPROBE"] = str(ffprobe)
out = args.out.resolve()
if out.exists():
    parser.error('--out must be fresh')
out.mkdir(parents=True)
loader = importlib.machinery.SourceFileLoader('subtitle_baseline', str(root / 'scripts/ui-baseline'))
spec = importlib.util.spec_from_loader(loader.name, loader)
baseline = importlib.util.module_from_spec(spec)
loader.exec_module(baseline)

# Reuse SelfHost's actual activation/recovery/seed/freeze lifecycle. Only the
# synthetic corpus and seed are narrowed; there is no golden capture sweep.
def media(directory, ffmpeg):
    movie = directory / 'movies' / 'Subtitle Acceptance (2026).mkv'
    movie.parent.mkdir(parents=True)
    srt = directory / 'authored.srt'
    srt.write_text('1\n00:00:00,000 --> 00:00:10,000\nAPP INITIAL CAPTION\n\n2\n00:00:10,000 --> 00:00:20,000\nAPP SEEK CAPTION\n\n3\n00:00:20,000 --> 00:00:30,000\nAPP LATE CAPTION\n\n4\n00:00:30,000 --> 00:00:40,000\nAPP END CAPTION\n')
    subprocess.run([str(ffmpeg), '-hide_banner', '-loglevel', 'error', '-nostdin', '-y',
                    '-f', 'lavfi', '-i', 'color=c=black:s=320x180:r=24:d=40',
                    '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=48000:duration=40',
                    '-i', str(srt), '-map', '0:v', '-map', '1:a', '-map', '2:s',
                    '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p',
                    '-g', '48', '-c:a', 'aac', '-c:s', 'srt', '-metadata:s:s:0', 'language=eng',
                    '-metadata:s:s:0', 'title=Authored acceptance captions', '-t', '40', str(movie)], check=True)
baseline.generate_media = media

class CaptionHost(baseline.SelfHost):
    def seed(self):
        self.token = baseline.api(self.base_url, '/setup', method='POST',
                                  body={'username': 'caption-fixture', 'password': 'caption-fixture-local'})['token']
        baseline.api(self.base_url, '/settings', self.token, 'PUT',
                     {'vod_index_mins': 0, 'cinema_remote_control': True})
        library = baseline.api(self.base_url, '/libraries', self.token, 'POST',
                               {'name': 'Caption fixture', 'kind': 'movies',
                                'paths': [str(self.media_dir / 'movies')], 'anime': False})
        self.libs = [library]
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            state = baseline.api(self.base_url, '/scan/status', self.token).get(str(library['id']))
            if state and not state['running'] and state.get('last_scan'):
                return
            time.sleep(.2)
        raise RuntimeError('single caption fixture did not scan')
    def discover(self):
        items = baseline.api(self.base_url, f"/libraries/{self.libs[0]['id']}/items?limit=10", self.token)['items']
        if len(items) != 1:
            raise RuntimeError(f'expected one synthetic title, got {len(items)}')
        self.item = items[0]

host = CaptionHost(SimpleNamespace(out=str(out), server_bin=str(args.server_bin.resolve()),
                                   ffmpeg=str(args.ffmpeg.resolve()), port=39327))
receipt = {'source_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip(),
           'subtitle_responses': [], 'page_errors': [], 'observations': []}
active = """() => {const v=document.getElementById('video'); return Array.from(v.textTracks).flatMap(t => t.mode==='showing' ? Array.from(t.activeCues||[]).map(c=>c.text) : []);} """
state = """() => {const v=document.getElementById('video'); return {file_id:PLAYER.fileId, method:PLAYER.method, session:PLAYER.sessionId, sub:PLAYER.curSub, time:(PLAYER.offset||0)+v.currentTime, tracks:Array.from(v.textTracks).map(t=>({mode:t.mode,cues:Array.from(t.activeCues||[]).map(c=>c.text)})), ready:v.readyState, error:v.error&&v.error.code};}"""
try:
    host.start()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=str(args.browser), headless=True,
                                     args=['--autoplay-policy=no-user-gesture-required'])
        context = browser.new_context(viewport={'width': 1280, 'height': 800})
        context.add_init_script('localStorage.setItem("plurx_token", '+json.dumps(host.token)+');localStorage.setItem("plurx_getapp_dismissed","1");localStorage.setItem("plurx_autoskip","0");')
        page = context.new_page()
        page.on('pageerror', lambda error: receipt['page_errors'].append(str(error)))
        def response(r):
            path = urlparse(r.url).path
            if '/subs/' in path or path.endswith('.vtt'):
                try:
                    body = r.text()
                    receipt['subtitle_responses'].append({'path': path, 'status': r.status,
                                                          'webvtt': body.startswith('WEBVTT'),
                                                          'authored_cues': 'APP ' in body})
                except Exception as error:
                    receipt['subtitle_responses'].append({'path': path, 'status': r.status, 'body_error': str(error)})
        page.on('response', response)
        page.goto(host.base_url + f"/#/item/{host.item['id']}")
        page.click('#main button.btnplay', timeout=45000)
        page.wait_for_function("() => {const v=document.getElementById('video');return v&&v.readyState>=3&&v.currentTime>0.5;}", timeout=45000)
        page.evaluate("() => { window.__captionVideo=document.getElementById('video');window.__captionFile=PLAYER.fileId; }")
        def select(index):
            page.click('#pbsubs')
            page.click(f'#pmenu button[data-remote-track="{index}"]')
        select(-1)
        index = page.evaluate('() => PLAYER.subs[0].index')
        select(index)
        page.wait_for_function("() => "+'('+active+')()'+".includes('APP INITIAL CAPTION')", timeout=30000)
        receipt['observations'].append({'phase':'selected', **page.evaluate(state)})
        page.screenshot(path=str(out / 'selected.png'))
        select(-1)
        page.wait_for_function("() => PLAYER.curSub===-1 && "+'('+active+')()'+'.length===0', timeout=15000)
        page.wait_for_timeout(1000)
        receipt['observations'].append({'phase':'off', **page.evaluate(state)})
        page.screenshot(path=str(out / 'off.png'))
        page.click('#pbforward')
        page.wait_for_function("() => (PLAYER.offset||0)+document.getElementById('video').currentTime>=10", timeout=30000)
        select(index)
        page.wait_for_function("() => "+'('+active+')()'+".includes('APP SEEK CAPTION')", timeout=30000)
        receipt['observations'].append({'phase':'seek-reselect', **page.evaluate(state)})
        page.screenshot(path=str(out / 'seek-reselect.png'))
        assert page.evaluate("() => document.getElementById('video')===window.__captionVideo && PLAYER.fileId===window.__captionFile")
        assert any(r.get('webvtt') and r.get('authored_cues') and r['status']==200 for r in receipt['subtitle_responses']), receipt
        assert not receipt['page_errors'], receipt['page_errors']
        page.click('#pbclose')
        context.close()
        browser.close()
    receipt['pass'] = True
finally:
    host.stop()
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
