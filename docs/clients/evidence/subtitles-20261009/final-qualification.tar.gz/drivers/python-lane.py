#!/usr/bin/env python3
"""Local unittest lane: persist each outcome and never replay a recorded pass."""
import argparse, hashlib, json, os, pathlib, subprocess, sys, time, unittest
p=argparse.ArgumentParser();p.add_argument('--suite',choices=['validation','operations'],required=True);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--only-failed',action='store_true');a=p.parse_args()
root=pathlib.Path('$SOURCE');os.chdir(root);sys.path.insert(0,str(root))
a.out.mkdir(parents=True,exist_ok=True);journal=a.out/'outcomes.jsonl'
ledger=json.loads(pathlib.Path('$EVIDENCE').read_text())
passed=set(ledger['no_repeat_selectors']['python'])
if journal.exists():
 for line in journal.read_text().splitlines():
  row=json.loads(line)
  if row['outcome']=='passed':passed.add(row['id'])
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
loader=unittest.TestLoader(); discovered=loader.discover(str(root/'tests'/a.suite))
def flatten(s):
 for x in s:
  if isinstance(x,unittest.TestSuite):yield from flatten(x)
  else:yield x
all_tests=list(flatten(discovered));todo=[x for x in all_tests if x.id() not in passed]
if a.only_failed:
 previous=json.loads((a.out/'summary.json').read_text())
 failures={name.split(' (',1)[0] for name in previous['failures']+previous['errors']}
 todo=[x for x in todo if x.id() in failures]
print(json.dumps({'source':source,'python':sys.version,'suite':a.suite,'discovered':len(all_tests),'retained':len(all_tests)-len(todo),'pending':len(todo)}),flush=True)
class Result(unittest.TextTestResult):
 def startTest(self,test):self.started=time.monotonic();super().startTest(test)
 def record(self,t,outcome):
  module=sys.modules.get(type(t).__module__);f=pathlib.Path(module.__file__) if module and getattr(module,'__file__',None) else None
  row={'id':t.id(),'suite':a.suite,'source_commit':source,'outcome':outcome,'elapsed':time.monotonic()-getattr(self,'started',time.monotonic()),'test_file':str(f.relative_to(root)) if f and f.is_relative_to(root) else str(f),'test_file_sha256':hashlib.sha256(f.read_bytes()).hexdigest() if f and f.is_file() else None}
  with journal.open('a') as out:out.write(json.dumps(row,sort_keys=True)+'\n');out.flush();os.fsync(out.fileno())
 def addSuccess(self,t):super().addSuccess(t);self.record(t,'passed')
 def addFailure(self,t,e):super().addFailure(t,e);self.record(t,'failed')
 def addError(self,t,e):super().addError(t,e);self.record(t,'error')
 def addSkip(self,t,r):super().addSkip(t,r);self.record(t,'skipped')
 def addExpectedFailure(self,t,e):super().addExpectedFailure(t,e);self.record(t,'expected_failure')
 def addUnexpectedSuccess(self,t):super().addUnexpectedSuccess(t);self.record(t,'unexpected_success')
result=unittest.TextTestRunner(verbosity=2,resultclass=Result).run(unittest.TestSuite(todo))
(a.out/'summary.json').write_text(json.dumps({'source_commit':source,'suite':a.suite,'run':result.testsRun,'inherited':len(all_tests)-len(todo),'failures':[t.id() for t,_ in result.failures],'errors':[t.id() for t,_ in result.errors],'skipped':[(t.id(),r) for t,r in result.skipped]},indent=2)+'\n')
sys.exit(0 if result.wasSuccessful() else 1)
