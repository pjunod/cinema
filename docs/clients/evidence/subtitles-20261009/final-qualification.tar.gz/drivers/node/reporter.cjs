'use strict';
const fs=require('node:fs');
module.exports=async function*(events){
 for await(const event of events){
  const line=JSON.stringify(event,(key,value)=>value instanceof Error?{name:value.name,message:value.message,stack:value.stack,cause:value.cause}:value);
  fs.appendFileSync(process.env.PLURX_NODE_NATIVE_EVENTS,line+'\n');
  if(event.type==='test:stdout'||event.type==='test:stderr')yield event.data.message;
  else if(event.type==='test:pass'||event.type==='test:fail')yield `${event.type} ${event.data.name}${event.data.skip?' (skipped)':''}\n`;
 }
};
