import argparse,fcntl,hashlib,json,os,re,subprocess,time
from pathlib import Path
here=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--review-addressed',action='store_true');p.add_argument('--entry',action='append');args=p.parse_args()
if not args.review_addressed: raise SystemExit('Execution blocked: root must confirm review addressed first.')
lock=(here/'runner.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX)
manifest=json.loads((here/'manifest.json').read_text());root=Path(manifest['root'])
# This is a source receipt refresh, not a test discovery execution.
manifest['candidate_at_execution']=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
manifest['files']={f:{**meta,'sha256':hashlib.sha256(root.joinpath(f).read_bytes()).hexdigest()} for f,meta in manifest['files'].items()}
manifest_path=here/'executing-manifest.json';manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
state_path=here/'state.json';state=json.loads(state_path.read_text()) if state_path.exists() else {'passes':[],'complete_entries':[],'attempts':[]}
for entry in args.entry or manifest['entries']:
 if entry in state['complete_entries']:continue
 if entry not in manifest['entries']:raise SystemExit('Not an inventory entry: '+entry)
 n=len(state['attempts'])+1;run=here/f'{n:03d}-{Path(entry).stem}';run.mkdir()
 closure={entry};changed=True
 while changed:
  old=len(closure);closure|={x for f in list(closure) for x in manifest['imports'].get(f,[])};changed=len(closure)!=old
 excluded=set(manifest['excluded_prior_names'])|{x['name'] for x in state['passes'] if x['file'] in closure}
 pattern='^(?!.*(?:'+'|'.join(re.escape(x) for x in sorted(excluded))+')$).*'
 passed=run/'prior-passes.json';passed.write_text(json.dumps(state['passes']))
 native=run/'native-events.jsonl';custom=run/'custom-events.jsonl';native.touch();custom.touch()
 env={**os.environ,'PLURX_NODE_MANIFEST':str(manifest_path),'PLURX_NODE_PASSED':str(passed),'PLURX_NODE_NATIVE_EVENTS':str(native),'PLURX_NODE_CUSTOM_EVENTS':str(custom)}
 cmd=[manifest['node'],'--test','--test-concurrency=1','--test-name-pattern='+pattern,'--require',str(here/'preload.cjs'),'--test-reporter='+str(here/'reporter.cjs'),entry]
 meta={'entry':entry,'command':cmd,'source_commit':manifest['candidate_at_execution'],'platform':manifest['platform'],'started_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
 (run/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
 print('RUN '+entry,flush=True)
 with (run/'stdout.log').open('w') as out:result=subprocess.run(cmd,cwd=root,env=env,stdout=out,stderr=subprocess.STDOUT)
 for event in [json.loads(line) for f in [native,custom] for line in f.read_text().splitlines()]:
  if event['type']=='custom:pass':file,name=event['file'],event['name']
  elif event['type']=='test:pass' and not event.get('data',{}).get('skip'):
   data=event['data'];file=data.get('file');name=data['name']
   if not file:continue
   file=os.path.relpath(file,root) if Path(file).is_absolute() else str(Path(file))
  else:continue
  if file not in manifest['files']:continue
  case={'file':file,'name':name,'source_sha256':manifest['files'][file]['sha256'],'source_commit':manifest['candidate_at_execution'],'receipt':str(run),'runner':event['type']}
  if not any(x['file']==file and x['name']==name for x in state['passes']):state['passes'].append(case)
 meta['exit_code']=result.returncode;meta['completed_at']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());(run/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n');state['attempts'].append(meta)
 if result.returncode==0:state['complete_entries'].append(entry)
 state_path.write_text(json.dumps(state,indent=2)+'\n')
 print(f'EXIT {result.returncode} {entry}; retained passes={len(state["passes"])}',flush=True)
 if result.returncode:print('Continue untouched entries; retry only this failed entry with retained passes suppressed.',flush=True)
raise SystemExit(0 if len(state['complete_entries'])==len(manifest['entries']) else 1)
