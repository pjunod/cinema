'use strict';
const fs=require('node:fs'),path=require('node:path'),Module=require('node:module');
const manifest=JSON.parse(fs.readFileSync(process.env.PLURX_NODE_MANIFEST,'utf8'));
const prior=new Set(manifest.excluded_prior_names);
const passed=new Set(JSON.parse(fs.readFileSync(process.env.PLURX_NODE_PASSED,'utf8')).map(x=>x.file+'\0'+x.name));
const append=event=>fs.appendFileSync(process.env.PLURX_NODE_CUSTOM_EVENTS,JSON.stringify({...event,at:new Date().toISOString(),pid:process.pid})+'\n');
const shouldRun=(file,name)=>!prior.has(String(name))&&!passed.has(file+'\0'+String(name));
const wrap=(file,name,fn)=>function(...args){
 append({type:'custom:start',file,name:String(name)});
 const pass=value=>{append({type:'custom:pass',file,name:String(name)});return value;};
 const fail=error=>{append({type:'custom:fail',file,name:String(name),message:String(error&&error.stack||error)});throw error;};
 try{const value=fn.apply(this,args);return value&&typeof value.then==='function'?value.then(pass,fail):pass(value);}catch(error){return fail(error);}
};
const native=(file,api)=>{
 const select=original=>{
  function selected(...args){
   if(typeof args[0]==='string'&&!shouldRun(file,args[0]))return original.skip(...args);
   return original(...args);
  }
  Object.assign(selected,original);
  selected.only=function(...args){if(typeof args[0]==='string'&&!shouldRun(file,args[0]))return original.skip(...args);return original.only(...args);};
  return selected;
 };
 const result=select(api);
 for(const key of ['test','it','describe','suite'])if(typeof api[key]==='function')result[key]=api[key]===api?result:select(api[key]);
 return result;
};
global.__plurxSelectiveCases={shouldRun,wrap,native};
const acorn=require(path.join(manifest.root,'tests/vendor/acorn.js'));
const original=Module._extensions['.js'];
Module._extensions['.js']=function(mod,filename){
 const file=path.relative(manifest.root,filename);
 if(!manifest.files[file]||(!manifest.files[file].custom_harness&&!manifest.files[file].uses_node_test))return original(mod,filename);
 let source=fs.readFileSync(filename,'utf8');
 const ast=acorn.parse(source,{ecmaVersion:'latest',sourceType:'script'}),changes=[];
 const visit=node=>{
  if(!node||typeof node!=='object')return;
  if(node.type==='CallExpression'&&node.callee.type==='Identifier'&&node.callee.name==='require'&&node.arguments[0]&&node.arguments[0].value==='node:test'){
   changes.push([node.start,node.end,`global.__plurxSelectiveCases.native(${JSON.stringify(file)},${source.slice(node.start,node.end)})`]);
  }
  if(node.type==='FunctionDeclaration'&&['test','asyncTest'].includes(node.id&&node.id.name)&&node.params.length===2&&node.params[0].name==='name'&&['fn','run'].includes(node.params[1].name)){
   const arg=node.params[1].name;
   changes.push([node.body.start+1,node.body.start+1,`\nif(!global.__plurxSelectiveCases.shouldRun(${JSON.stringify(file)},name))return;${arg}=global.__plurxSelectiveCases.wrap(${JSON.stringify(file)},name,${arg});\n`]);
  }
  for(const value of Object.values(node)){if(Array.isArray(value))value.forEach(visit);else if(value&&typeof value==='object')visit(value);}
 };
 visit(ast);
 if(manifest.files[file].custom_harness&&!changes.length)throw new Error('No selective custom harness found: '+file);
 for(const [at,end,text] of changes.sort((a,b)=>b[0]-a[0]))source=source.slice(0,at)+text+source.slice(end);
 mod._compile(source,filename);
};
