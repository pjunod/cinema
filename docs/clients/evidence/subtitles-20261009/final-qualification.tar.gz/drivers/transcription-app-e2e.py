#!/usr/bin/env python3
"""Prepared opt-in real daemon transcription queue/publication/render acceptance; no stubs."""
import argparse
import importlib.machinery
import importlib.util
import json
import os
import pathlib
import subprocess
import time
from types import SimpleNamespace
from urllib.parse import urlparse

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root', type=pathlib.Path, required=True)
parser.add_argument('--server-bin', type=pathlib.Path, required=True)
parser.add_argument('--ffmpeg', type=pathlib.Path, required=True)
parser.add_argument('--browser', type=pathlib.Path, required=True)
parser.add_argument('--out', type=pathlib.Path, required=True)
parser.add_argument('--whisper', type=pathlib.Path, required=True)
parser.add_argument('--model', type=pathlib.Path, required=True)
args = parser.parse_args()
root = args.source_root.resolve()
os.environ["PLURX_FFMPEG"] = str(args.ffmpeg.resolve())
ffprobe = args.ffmpeg.resolve().with_name("ffprobe")
if ffprobe.is_file():
    os.environ["PLURX_FFPROBE"] = str(ffprobe)
out = args.out.resolve()
if out.exists():
    parser.error('--out must be fresh')
out.mkdir(parents=True)
loader = importlib.machinery.SourceFileLoader('subtitle_baseline', str(root / 'scripts/ui-baseline'))
spec = importlib.util.spec_from_loader(loader.name, loader)
baseline = importlib.util.module_from_spec(spec)
loader.exec_module(baseline)

# Reuse SelfHost's actual activation/recovery/seed/freeze lifecycle. Only the
# synthetic corpus and seed are narrowed; there is no golden capture sweep.
def media(directory, ffmpeg):
    movie=directory/'movies'/'Spoken Acceptance (2026).mp4'
    movie.parent.mkdir(parents=True)
    speech=directory/'speech.aiff'
    phrase='This is an offline subtitle test. The quiet library is ready for movie night.'
    subprocess.run(['/usr/bin/say','-o',str(speech),phrase],check=True,timeout=30)
    subprocess.run([str(ffmpeg),'-hide_banner','-loglevel','error','-nostdin','-y',
        '-f','lavfi','-i','color=c=black:s=320x180:r=24:d=20','-i',str(speech),
        '-map','0:v','-map','1:a','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',
        '-g','48','-c:a','aac','-af','apad=pad_dur=20','-metadata:s:a:0','language=eng','-t','20',str(movie)],check=True,timeout=40)
baseline.generate_media = media

class CaptionHost(baseline.SelfHost):
    def seed(self):
        self.token = baseline.api(self.base_url, '/setup', method='POST',
                                  body={'username': 'caption-fixture', 'password': 'caption-fixture-local'})['token']
        baseline.api(self.base_url, '/settings', self.token, 'PUT',
                     {'vod_index_mins': 0, 'cinema_remote_control': True})
        library = baseline.api(self.base_url, '/libraries', self.token, 'POST',
                               {'name': 'Caption fixture', 'kind': 'movies',
                                'paths': [str(self.media_dir / 'movies')], 'anime': False})
        self.libs = [library]
        deadline = time.monotonic() + 60
        while time.monotonic() < deadline:
            state = baseline.api(self.base_url, '/scan/status', self.token).get(str(library['id']))
            if state and not state['running'] and state.get('last_scan'):
                return
            time.sleep(.2)
        raise RuntimeError('single caption fixture did not scan')
    def discover(self):
        items = baseline.api(self.base_url, f"/libraries/{self.libs[0]['id']}/items?limit=10", self.token)['items']
        if len(items) != 1:
            raise RuntimeError(f'expected one synthetic title, got {len(items)}')
        self.item = items[0]

host = CaptionHost(SimpleNamespace(out=str(out), server_bin=str(args.server_bin.resolve()),
                                   ffmpeg=str(args.ffmpeg.resolve()), port=39347))
import hashlib
import sqlite3
receipt = {
    'source_commit': subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    'ffmpeg_sha256': hashlib.sha256(args.ffmpeg.resolve().read_bytes()).hexdigest(),
    'driver_sha256': hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
    'server_sha256': hashlib.sha256(args.server_bin.read_bytes()).hexdigest(),
    'whisper_sha256': hashlib.sha256(args.whisper.resolve().read_bytes()).hexdigest(),
    'model_sha256': hashlib.sha256(args.model.read_bytes()).hexdigest(),
    'job_observations': [], 'page_errors': [], 'subtitle_responses': [],
}
try:
    host.start()
    item_path = f"/items/{host.item['id']}"
    before = baseline.api(host.base_url,item_path,host.token)
    assert len(before['files'])==1
    file = before['files'][0]
    file_id = str(file.get('id_text') or file['id'])
    assert not file['subtitle_streams'], file['subtitle_streams']
    saved = baseline.api(host.base_url,'/subtitle-transcription',host.token,'PUT',
                         {'enabled':True,'interval_mins':0,'command':str(args.whisper.resolve()),
                          'model_path':str(args.model.resolve()),'language':'en'})
    assert saved['enabled'] and saved['readiness']['ready'], saved
    enqueue = baseline.api(host.base_url,f'/files/{file_id}/subtitles/transcribe',host.token,'POST',{})
    assert enqueue['outcome']=='accepted', enqueue
    job_id = enqueue['job_id']
    receipt['enqueue'] = enqueue
    deadline=time.monotonic()+180
    last_state=None
    while time.monotonic()<deadline:
        detail=baseline.api(host.base_url,f'/cluster/jobs/{job_id}',host.token)
        job=detail['job']
        if job['state']!=last_state:
            receipt['job_observations'].append({'state':job['state'],'kind':job['kind'],
                'file_id':job['file_id'],'error_code':job['error_code']})
            last_state=job['state']
        if job['state']=='succeeded':
            break
        if job['state'] in ['failed','cancelled']:
            raise RuntimeError('transcription settled without publication: '+json.dumps(detail))
        time.sleep(.25)
    else:
        raise RuntimeError('transcription did not settle inside180s')
    assert job['kind']=='subtitle_transcribe' and str(job['file_id'])==file_id
    after=baseline.api(host.base_url,item_path,host.token)
    generated=[s for s in after['files'][0]['subtitle_streams']
               if s.get('codec')=='webvtt' and s.get('title')=='Machine transcription (whisper.cpp)']
    assert len(generated)==1, after['files'][0]['subtitle_streams']
    track=generated[0]
    receipt['selectable_track']=track

    # Stop before reading fixture-only authority storage. No production DB is
    # opened, and the read-only URI cannot mutate this fixture DB either.
    host.stop()
    publication=None
    for db in host.data_dir.rglob('*.db'):
        try:
            connection=sqlite3.connect(db.resolve().as_uri()+'?mode=ro',uri=True)
            try:
                row=connection.execute('SELECT size,mtime,downloaded_subtitles FROM files WHERE id=?',(int(file_id),)).fetchone()
                if not row:continue
                captions=json.loads(row[2])
                for caption in captions:
                    provenance=caption.get('transcription')
                    if not provenance or provenance.get('model_sha256')!=receipt['model_sha256']:continue
                    assert caption['source_size']==row[0] and caption['source_mtime']==row[1]
                    assert caption['provider_file_id']==0 and provenance['adapter']=='whisper.cpp'
                    assert provenance['audio_index']==0 and len(provenance['artifact_key'])==64
                    stored=connection.execute('SELECT state,result_ref FROM background_jobs WHERE id=?',(job_id,)).fetchone()
                    assert stored==('succeeded',provenance['artifact_key']), stored
                    assert caption['vtt'].startswith('WEBVTT') and '-->' in caption['vtt']
                    assert 'offline subtitle' in caption['vtt'].lower(),caption['vtt']
                    publication={'authority_db':str(db.relative_to(host.data_dir)),
                        'provider_file_id':0,'source_size':row[0],'source_mtime':row[1],
                        'transcription':provenance,'vtt_sha256':hashlib.sha256(caption['vtt'].encode()).hexdigest(),
                        'vtt':caption['vtt'],'durable_job_state':stored[0]}
                    break
                if publication:break
            finally:
                connection.close()
        except sqlite3.OperationalError:
            continue
    assert publication, 'No matching durable generated-caption publication in fixture authority'
    receipt['publication']=publication
    (out/'generated.vtt').write_text(publication['vtt'])
    host.spawn()
    restarted=baseline.api(host.base_url,f'/cluster/jobs/{job_id}',host.token)
    assert restarted['job']['state']=='succeeded'
    restarted_file=baseline.api(host.base_url,item_path,host.token)['files'][0]
    assert any(s.get('title')=='Machine transcription (whisper.cpp)' for s in restarted_file['subtitle_streams'])
    receipt['survived_restart']=True

    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        browser=pw.chromium.launch(executable_path=str(args.browser),headless=True,
                                   args=['--autoplay-policy=no-user-gesture-required'])
        context=browser.new_context(viewport={'width':1280,'height':800})
        context.add_init_script('localStorage.setItem("plurx_token",'+json.dumps(host.token)+');localStorage.setItem("plurx_getapp_dismissed","1");localStorage.setItem("plurx_autoskip","0");')
        page=context.new_page()
        page.on('pageerror',lambda error:receipt['page_errors'].append(str(error)))
        def response(r):
            path=urlparse(r.url).path
            if '/subs/' in path or path.endswith('.vtt'):
                try:
                    body=r.text()
                    receipt['subtitle_responses'].append({'path':path,'status':r.status,
                       'webvtt':body.startswith('WEBVTT'),'offline_subtitle':'offline subtitle' in body.lower(),
                       'sha256':hashlib.sha256(body.encode()).hexdigest()})
                except Exception as error:
                    receipt['subtitle_responses'].append({'path':path,'status':r.status,'body_error':str(error)})
        page.on('response',response)
        page.goto(host.base_url+f"/#/item/{host.item['id']}")
        page.click('#main button.btnplay',timeout=45000)
        page.wait_for_function("() => {const v=document.getElementById('video');return v&&v.readyState>=3;}",timeout=45000)
        # Park the real video at0 before selecting: brief ASR cues must not
        # be missed because browser setup took longer than the spoken phrase.
        if not page.evaluate("() => document.getElementById('video').paused"):
            page.click('#pbplay')
        page.click('#pbback')
        page.wait_for_function("() => (PLAYER.offset||0)+document.getElementById('video').currentTime<0.5",timeout=20000)
        page.click('#pbsubs')
        page.click(f"#pmenu button[data-remote-track=\"{track['index']}\"]")
        # A real ASR cue may begin after0: loading its cue list is sufficient
        # while paused. Resume normally, then observe it become active in time.
        page.wait_for_function("""() => {const v=document.getElementById('video');return Array.from(v.textTracks).some(t=>t.mode==='showing' && Array.from(t.cues||[]).some(c=>c.text.toLowerCase().includes('offline subtitle')));} """,timeout=20000)
        if page.evaluate("() => document.getElementById('video').paused"):
            page.click('#pbplay')
        page.wait_for_function("""() => {const v=document.getElementById('video');return v.currentTime>0 && Array.from(v.textTracks).some(t=>t.mode==='showing' && Array.from(t.activeCues||[]).some(c=>c.text.toLowerCase().includes('offline subtitle')));} """,timeout=20000)
        receipt['rendered']=page.evaluate("""() => {const v=document.getElementById('video');return {file_id:PLAYER.fileId,sub:PLAYER.curSub,time:(PLAYER.offset||0)+v.currentTime,error:v.error&&v.error.code,cues:Array.from(v.textTracks).filter(t=>t.mode==='showing').flatMap(t=>Array.from(t.activeCues||[]).map(c=>c.text))};}""")
        page.screenshot(path=str(out/'generated-cue.png'))
        assert any(r.get('webvtt') and r.get('offline_subtitle') and r['status']==200 for r in receipt['subtitle_responses'])
        assert not receipt['page_errors'],receipt['page_errors']
        page.click('#pbclose')
        context.close();browser.close()
    receipt['pass']=True
finally:
    host.stop()
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
