#!/usr/bin/env python3
"""Check regenerated facts; do not reinterpret movie hashes as HTTP evidence."""
import argparse,json,pathlib,subprocess,hashlib
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--ffprobe',default='ffprobe');p.add_argument('--ffmpeg',default='ffmpeg');p.add_argument('--dovi-tool',required=True);a=p.parse_args();root=pathlib.Path(a.out);records={}
def run(args):return subprocess.check_output(args,stderr=subprocess.PIPE)
for movie in root.glob('*-AAC.mkv'):
 j=json.loads(run([a.ffprobe,'-v','error','-count_frames','-show_packets','-show_streams','-of','json',str(movie)]));v=next(x for x in j['streams'] if x['codec_type']=='video');audio=next(x for x in j['streams'] if x['codec_type']=='audio');packets=[x for x in j['packets'] if x['stream_index']==v['index']];ap=[x for x in j['packets'] if x['stream_index']==audio['index']];n=66 if movie.name.startswith('Late') else 144
 assert len(packets)==int(v['nb_read_frames'])==n and v['r_frame_rate']==v['avg_frame_rate']=='24/1';assert float(packets[0]['pts_time'])==0;assert all(abs(float(x['pts_time'])-i/24)<=.000501 for i,x in enumerate(packets));assert audio['codec_name']=='aac' and audio['sample_rate']=='48000' and float(ap[0]['pts_time'])==-.021;assert (v['pix_fmt'],v['color_transfer'],v['color_primaries'],v['color_space'])==('yuv420p10le','smpte2084','bt2020','bt2020nc')
 cfg=next(x for x in v['side_data_list']if x['side_data_type']=='DOVI configuration record');profile=cfg['dv_profile'];assert cfg['dv_bl_signal_compatibility_id']=={5:0,7:6,8:1}[profile] and cfg['el_present_flag']==int(profile==7)
 hevc=movie.with_suffix('.hevc');rpu=movie.with_suffix('.rpu');export=movie.with_suffix('.rpus.json')
 for cmd in [[a.ffmpeg,'-y','-v','error','-i',str(movie),'-map','0:v:0','-c:v','copy','-bsf:v','hevc_mp4toannexb','-f','hevc',str(hevc)],[a.dovi_tool,'extract-rpu','-i',str(hevc),'-o',str(rpu)],[a.dovi_tool,'export','-i',str(rpu),'--data','all='+str(export)]]:run(cmd)
 parsed=json.loads(export.read_text());assert len(parsed)==n and all(x['dovi_profile']==profile for x in parsed)
 if movie.name.startswith('Late') and v['height']==1080:
  def offsets(x):return next(z['Level5']for z in x['vdr_dm_data']['cmv29_metadata']['ext_metadata_blocks']if 'Level5'in z)
  assert all(offsets(x)['active_area_top_offset']+offsets(x)['active_area_bottom_offset']<1080 for x in parsed[:48]);assert all(offsets(x)['active_area_top_offset']+offsets(x)['active_area_bottom_offset']>=1080 for x in parsed[48:])
 records[movie.name]={'width':v['width'],'height':v['height'],'frames':n,'parsed_rpus':n,'profile':profile,'video_first_pts':'0','audio_first_pts':'-.021','r_frame_rate':'24/1','avg_frame_rate':'24/1','sha256':hashlib.sha256(movie.read_bytes()).hexdigest()}
assert records; (root/'verification.json').write_text(json.dumps(records,indent=2));print(json.dumps(records,indent=2))
