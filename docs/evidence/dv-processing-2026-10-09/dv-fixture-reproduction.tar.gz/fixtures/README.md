# DV fixtures — reproduce bounded source routing inputs

**Status:** fixture generation and independent parsing verified on 2026-10-09;
HTTP acceptance is recorded separately and is not asserted by this bundle.

This bundle reproduces synthetic P5, P7/FEL and P8 sources for isolated daemon
routing checks. The small variant is 256×144, the HDR variant is 1920×1080,
and the resource variant is 3840×2160. Generated movies are excluded; the
receipts retain their hashes and observed metadata. These patterns establish
source mechanics, not visual quality, FEL gain or ROG performance.

Read [dependency-identities.json](dependency-identities.json) for the selected
source revisions, then each variant's `fixture-receipt.json` for observations.
[manifest.json](manifest.json) inventories the delivered files and their hashes.

## Build dependencies and select the encoder

Use the repository's pinned Rust 1.97.1 and helper dependency build. The build
script fetches hash-checked public dependencies; this preparation did not
execute that build or fetch anything. Existing verified installations can be
reused. The fixture encoder must provide `libx265`, `lavfi` and AAC; it is
separate from the pinned static decoder libraries used to compile the muxer.

```bash
REPO=/path/to/plurx                        # Checkout containing pinned helpers.
DEPS=/absolute/path/to/dv-dependencies     # Helper dependency prefix.
sh "$REPO/tools/dv_processing/build-dependencies.sh" "$DEPS"
sh "$REPO/tools/dv_processing/build-bundle.sh" "$DEPS" /absolute/path/to/helper-bundle
```

The observed fixture encoder was FFmpeg 5.1.9 in the existing local image;
its identity is recorded in `dependency-identities.json`. Reproduction on
another encoder build must verify facts again; byte-identical movie hashes
are not promised across toolchains.

## Regenerate one variant in a new output directory

```bash
BUNDLE=/absolute/path/to/fixtures          # This directory.
OUTPUT=/absolute/path/to/new-output        # Must not already exist.
python3 "$BUNDLE/reproduce.py" 1080 \
  --out "$OUTPUT" --ffmpeg /path/to/ffmpeg \
  --ffmpeg-prefix "$DEPS/ffmpeg"
python3 "$BUNDLE/verify.py" --out "$OUTPUT" \
  --ffmpeg /path/to/ffmpeg --ffprobe /path/to/ffprobe \
  --dovi-tool /path/to/dovi_tool
```

Choose `small`, `1080` or `4k`. Set `CC` and `FFPROBE` in the environment when
those tools are not on PATH. Both layers use the same full raster, 144 frames
at 24 fps, 10-bit PQ/BT2020 NCL, x265 ultrafast, no B-frames, and keyframes
every 18 frames. All RPU bytes come from the frozen variant input directories.
Only P7 carries an enhancement-layer configuration.

**How to read the verification:** each supported movie must decode 144 frames
and parse 144 RPUs; the 1080 late case must contain 66 frames/RPUs. Video starts
at PTS 0, AAC starts at −21 ms because encoder priming is retained, and video
PTS follows `frame / 24` within 0.501 ms of Matroska's clock. Both nominal and
average frame rate must be `24/1`. Failed assertions invalidate that fixture.

## Preserve the timing correction and late refusal

`make_movie-pinned.c` is the recorded repository source. Each variant includes
its adapted C and a patch. The muxer preserves encoder packet timestamps and
copies the encoder stream's average and nominal frame rates. Omitting those
stream fields caused the earlier `293/12` rate; AAC muxing without disabling
negative-timestamp avoidance shifted video by +21 ms. The corrected recipe
uses `-copyts -avoid_negative_ts disabled` rather than rewriting picture PTS.

The 1080 late RPU changes after frame 48. Its Level 5 top/bottom offsets are
540/540, leaving no active 1080-line area. The frozen single-RPU input and
editor JSON reproduce that change with the recorded parser:

```bash
dovi_tool editor -i 1080/late-input-single.rpu \
  -j 1080/late-invalid-area-edit.json -o late-invalid-single.rpu
```

The editor emits start-code-prefixed RPU payloads. The stored `.nal` inputs
prepend the HEVC `7c 01` UNSPEC62 header instead; retain this framing distinction
when recreating inputs. Small inherited late metadata is not a qualified
late-refusal test. Use the verified 1080 late variant for that check.

## Layout and evidence limits

- `small/` · small P81 routing inputs, recipes and observed receipts.
- `1080/` · HDR source inputs and the verified late active-area refusal.
- `4k/` · synthetic resource and default-budget fallback input.
- `reproduce.py` · fresh source encoding and bounded compound muxing.
- `verify.py` · independent stream, timestamp and parsed-RPU checks.

No auth files, daemon settings, user movies or generated movie files are
included. A parsed RPU count does not prove per-picture route adoption by a
running daemon. That requires actual HTTP bytes, the fresh publication marker,
and the separate acceptance receipt. The 100 ms A/V tolerance used by that
HTTP analyzer is an acceptance bound, not a frame-perfect claim.
