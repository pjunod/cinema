#!/usr/bin/env python3
"""Regenerate synthetic sources in a fresh directory using selected tools."""
import argparse,json,pathlib,shutil,subprocess,os
p=argparse.ArgumentParser();p.add_argument('variant',choices=['small','1080','4k']);p.add_argument('--out',required=True);p.add_argument('--ffmpeg',default='ffmpeg');p.add_argument('--ffmpeg-prefix',required=True);a=p.parse_args();bundle=pathlib.Path(__file__).parent;src=bundle/a.variant;out=pathlib.Path(a.out).resolve();out.mkdir(parents=True,exist_ok=False)
for d in src.glob('*-rpus'):shutil.copytree(d,out/d.name)
shutil.copy(src/'make_movie.c',out/'make_movie.c');g=json.loads((src/'geometry.json').read_text());commands=[]
for layer in ['bl','el']:
 cmd=[a.ffmpeg,'-nostdin','-v','error','-f','lavfi','-i',f"testsrc2=size={g['width']}x{g['height']}:rate=24",'-frames:v','144','-pix_fmt','yuv420p10le','-color_primaries','bt2020','-color_trc','smpte2084','-colorspace','bt2020nc','-c:v','libx265','-preset','ultrafast','-x265-params','pools=1:frame-threads=1:bframes=0:keyint=18:min-keyint=18:scenecut=0:log-level=error',str(out/(layer+'.mkv'))];commands.append(cmd);subprocess.run(cmd,check=True)
env=dict(os.environ,PLURX_FIXTURE_FFMPEG_PREFIX=str(pathlib.Path(a.ffmpeg_prefix).resolve()),FFMPEG=a.ffmpeg);cmd=['sh',str(src/'regenerate.sh'),str(out)];commands.append(cmd);subprocess.run(cmd,check=True,env=env);(out/'reproduction-commands.json').write_text(json.dumps(commands,indent=2))
