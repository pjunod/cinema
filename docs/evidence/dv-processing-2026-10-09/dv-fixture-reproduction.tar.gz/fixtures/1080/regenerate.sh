#!/bin/sh
set -eu
fixture_dir=${1:?usage: regenerate.sh ABSOLUTE_OUTPUT_DIR}
ffmpeg_prefix=${PLURX_FIXTURE_FFMPEG_PREFIX:?select pinned FFmpeg static prefix}
cd "$fixture_dir"
flags=$(PKG_CONFIG_PATH=$ffmpeg_prefix/lib/pkgconfig pkg-config --static --cflags --libs libavformat libavcodec libavutil)
"${CC:-cc}" -std=c11 -Wall -Wextra -Werror make_movie.c -o make_movie $flags -lm -lpthread -ldl
for profile in 7 5 8; do
 [ -d p${profile}-rpus ] || continue
 FIXTURE_PROFILE=$profile ./make_movie bl.mkv el.mkv p${profile}-rpus supported-p${profile}-video.mkv normal > supported-p${profile}-mux.jsonl
 "${FFMPEG:-ffmpeg}" -nostdin -v error -copyts -i supported-p${profile}-video.mkv -f lavfi -i 'sine=frequency=440:sample_rate=48000' -map 0:v -map 1:a -c:v copy -c:a aac -t 6 -avoid_negative_ts disabled -y Supported-P${profile}-AAC.mkv
 "${FFPROBE:-ffprobe}" -v error -count_frames -show_streams -show_packets -of json Supported-P${profile}-AAC.mkv > Supported-P${profile}-AAC.ffprobe.json
done
if [ -d late-rpus ]; then
 "${CC:-cc}" -std=c11 -Wall -Wextra -Werror -DFIXTURE_COUNT=66 make_movie.c -o make_movie66 $flags -lm -lpthread -ldl
 for layer in bl el; do "${FFMPEG:-ffmpeg}" -nostdin -v error -i "$layer.mkv" -map 0:v -c copy -frames:v 66 -y "${layer}66.mkv"; done
 ./make_movie66 bl66.mkv el66.mkv late-rpus late-p7-video.mkv normal > late-p7-mux.jsonl
 "${FFMPEG:-ffmpeg}" -nostdin -v error -copyts -i late-p7-video.mkv -f lavfi -i 'sine=frequency=440:sample_rate=48000' -map 0:v -map 1:a -c:v copy -c:a aac -t 2.75 -avoid_negative_ts disabled -y Late-Unsupported-P7-AAC.mkv
 "${FFPROBE:-ffprobe}" -v error -count_frames -show_streams -show_packets -of json Late-Unsupported-P7-AAC.mkv > Late-Unsupported-P7-AAC.ffprobe.json
fi
