mod macos_wasm;
use std::{fs::{self,File}, sync::{Arc,atomic::AtomicBool}, time::{Instant,Duration}};
fn main() -> Result<(), Box<dyn std::error::Error>> {
 let args:Vec<String>=std::env::args().collect();
 let image=fs::read(&args[1])?;
 let start=Instant::now();let parser=macos_wasm::Parser::new(&image)?;
 println!("compile_ms={:.3}",start.elapsed().as_secs_f64()*1000.0);
 for (name,source,argv,seconds) in [
  ("version",None,vec!["-version"],5),
  ("metadata",Some(Arc::new(File::open(&args[3])?)),vec!["-v","error","-show_format","-show_streams","-of","json","/dev/fd/3"],10),
  ("packets",Some(Arc::new(File::open(&args[3])?)),vec!["-v","error","-select_streams","v:0","-show_packets","-show_entries","packet=pts,dts,duration,size,flags","-of","json","/dev/fd/3"],10),
 ] {
  let start=Instant::now(); let output=parser.run(source,argv.into_iter().map(str::to_owned).collect(),(256*1024,16*1024),Instant::now()+Duration::from_secs(seconds),Arc::new(AtomicBool::new(false)));
  match output { Ok(out)=>{println!("{} elapsed_ms={:.3} status={} stdout_bytes={} stderr_bytes={}",name,start.elapsed().as_secs_f64()*1000.0,out.status,out.stdout.len(),out.stderr.len());fs::write(format!("{}-{}.json",args[4],name),&out.stdout)?;}, Err(e)=>println!("{} elapsed_ms={:.3} error={}",name,start.elapsed().as_secs_f64()*1000.0,e) }
 }
 Ok(())
}
